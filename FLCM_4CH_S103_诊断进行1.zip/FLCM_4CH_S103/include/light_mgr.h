/*
 * light_mgr.h
 *
 *  Created on: 2024年3月17日
 *      Author: Administrator
 */

#ifndef LIGHT_MGR_H_
#define LIGHT_MGR_H_

typedef enum {
    LIGHT_CONTROL_DIS = 0,  // 灯控制禁止
    LIGHT_CONTROL_EN = 1    // 灯控制允许
} m_LAMP_CON_STA;

typedef struct {
    m_LAMP_CON_STA binControl;   // BIN相关控制状态
    m_LAMP_CON_STA btnControl;   // 硬线相关控制状态
    m_LAMP_CON_STA voltageControl; // 电压相关控制状态
    m_LAMP_CON_STA faultControl; // 故障相关控制状态
} m_LAMP_CON_CONFIG;

typedef struct {
    m_LAMP_CON_CONFIG highBeam;     // 远光灯控制状态
    m_LAMP_CON_CONFIG lowBeam;      // 近光灯控制状态
    m_LAMP_CON_CONFIG daytime;      // 日行灯控制状态
    m_LAMP_CON_CONFIG turn;         // 转向灯控制状态
    m_LAMP_CON_CONFIG position;     // 位置灯控制状态
} m_LAMP_CONTROL;

extern m_LAMP_CONTROL e_LAMP_CMD; // 声明结构体实例可供外部使用
#endif /* LIGHT_MGR_H_ */
