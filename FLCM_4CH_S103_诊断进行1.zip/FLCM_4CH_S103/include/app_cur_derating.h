/*
 * app_cur_derating.h
 *
 *  Created on: 2023��11��10��
 *      Author: gz06488
 */

#ifndef APP_CUR_DERATING_H_
#define APP_CUR_DERATING_H_

#include "stdint.h"

#define BASETIME   20
#define DYTIME_MS  100
typedef struct
{
        uint8_t  new;
        uint8_t  old;
        uint8_t  num;
}s_STATE_STRUCT, *ps_STATE_STRUCT;

typedef struct
{
        uint8_t  addr;
        uint16_t data;
}s_wCMD_STRUCT, *ps_wCMD_STRUCT;

typedef struct {
	 uint16_t  device_step;
	 uint16_t  device_Time;
	 s_wCMD_STRUCT  buck_Cmd;
}LIGHT_PIXEL_LIST_t,*pLIGHT_PIXEL_LIST_t;

extern uint8_t send_level_num1_A;
extern uint8_t send_level_num2_A;
extern uint8_t send_level_num3_A;


extern s_STATE_STRUCT s_state_struct;
extern s_STATE_STRUCT s_state_num1;
extern s_STATE_STRUCT s_state_num2;
extern s_STATE_STRUCT s_state_num3;
extern uint8_t sl_cur_derating_fun(uint8_t CC_type,uint8_t level,const  uint16_t Data_lb_arr[][8],uint8_t flag);
//extern uint8_t lld_cur_derating_fun(uint8_t CC_type,const  uint16_t Data_lb_arr[][8]);
extern void LLD_PixelDarsing(uint8_t CC_type,uint8_t num_legth,const  uint16_t Data_lb_arr[][8]);
extern void sl_Light_PixelDarsing(uint8_t derat_step,uint8_t CC_type,const uint16_t Data_lb_arr[][8]);
extern void sl_curC_A_fun(uint8_t CC_type,uint8_t num,const  uint16_t Data_lb_arr[][8]);
extern uint8_t sl_cur_fun(uint8_t CC_type,uint8_t status,const  uint16_t Data_lb_arr[][8]);
#endif /* APP_CUR_DERATING_H_ */
