/*
 * data.h
 *
 *  Created on: 2023年11月13日
 *      Author: gz06488
 */

#ifndef DATA_H_
#define DATA_H_

#include "stdint.h"
#include "MPQ7210_driver.h"

extern const uint16_t Data_test_arr[82][8];
extern const uint16_t Data_test_arr1[17][8];
extern const uint16_t Data_test_arr2[18][8];
extern const uint16_t Data_test_arr11[1][8];
extern const uint16_t Data_test_arr22[1][8];
extern const uint16_t HB_Data_dera_arr[50][8];
extern const uint16_t LB_Data_dera_arr[50][8];
extern const uint16_t DRL_Data_dera_arr[50][8];
extern const uint16_t TI_Data_dera_arr[50][8];

//**A09**//
extern const uint16_t Data_958_one_dera_arr[50][8];
extern const uint16_t Data_919_one_dera_arr[50][8];
extern const uint16_t Data_878_one_dera_arr[50][8];
extern const uint16_t Data_805_two_dera_arr[50][8];
extern const uint16_t Data_855_two_dera_arr[50][8];
extern const uint16_t Data_900_two_dera_arr[50][8];
extern const uint16_t Data_950_two_dera_arr[50][8];


extern const uint16_t Data_1000_one_dera_arr[50][8];
extern const uint16_t Data_1000_two_dera_arr[50][8];
extern const uint16_t Data_900_one_dera_arr[50][8];
extern const uint16_t Data_900_two_dera_arr[50][8];
extern const uint16_t Data_800_one_dera_arr[50][8];
extern const uint16_t Data_800_two_dera_arr[50][8];
extern const uint16_t Data_700_one_dera_arr[50][8];
extern const uint16_t Data_700_two_dera_arr[50][8];
extern const uint16_t Data_600_one_dera_arr[50][8];
extern const uint16_t Data_600_two_dera_arr[50][8];
extern const uint16_t Data_500_one_dera_arr[50][8];
extern const uint16_t Data_500_two_dera_arr[50][8];
extern const uint16_t Data_200_one_dera_arr[50][8];
extern const uint16_t Data_200_two_dera_arr[50][8];
extern const uint16_t Data_180_one_dera_arr[50][8];
extern const uint16_t Data_180_two_dera_arr[50][8];
extern const uint16_t Data_160_one_dera_arr[50][8];
extern const uint16_t Data_160_two_dera_arr[50][8];
extern const uint16_t Data_140_one_dera_arr[50][8];
extern const uint16_t Data_140_two_dera_arr[50][8];
extern const uint16_t Data_120_one_dera_arr[50][8];
extern const uint16_t Data_120_two_dera_arr[50][8];

extern sMPQ7210_wCMD_STRUCT PL_normalCC2_MPQ7210_CmdTable[];
extern sMPQ7210_wCMD_STRUCT TI_normalCC1_MPQ7210_CmdTable[];

extern uint8_t HB_norma_length;
extern uint8_t LB_norma_length;
extern uint8_t DRL_norma_length;
extern uint8_t PL_norma_length;
extern uint8_t TI_norma_length;

#endif /* DATA_H_ */
