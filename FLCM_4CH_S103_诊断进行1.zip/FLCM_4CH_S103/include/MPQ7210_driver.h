/*
 * MPQ7210_driver.h
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 */

#ifndef MPQ7210_DRIVER_H_
#define MPQ7210_DRIVER_H_

#include "al_light_function.h"
#include "spi_pal_cfg.h"
#include <stddef.h>  // For NULL, size_t, ptrdiff_t, etc.
#include <math.h>

//由于使用MSB模式故数据高位与低位相反

/**
 * SPI通讯用传递参数
*/
#define SPI_BUFFER_SIZE  (10)
#define TIME_OUT_1MS     (1)
#define INDATALenght     (32)
#define U1_MPQ7210       (0)
#define U2_MPQ7210       (1)
#define READ_BIT         (1)
#define WRITE_BIT        (0)
#define  MPQ7210x_DEVICE_MAX   (20)

/**
 * 计算MPQ7210回读的ADC值用的参数
*/
#define MPQ_ADC_CYC        (8)
#define delta_Buck         (3) //▲buck:即BOOST和BUCK的压差为3V
#define mpq7210_uv_value   (2.3) //buck欠压阈值2.3V
/*! Buck 1 ID. */
#define BUCK1	0
/*! Buck 2 ID. */
#define BUCK2	1
/*! Buck 1 ch_ID. */
#define BUCK_CH1	0
/*! Buck 2 ch_ID. */
#define BUCK_CH2	1
/*! Buck 2 ch_ID. */
#define BUCK_CH3	2
/*! Buck 3 ch_ID. */
#define BUCK_CH4	3
//实际使用buck颗数
#define APP_NUM_OF_BUCK     2
//每个buck通道数
#define AL_CHANNEL_OF_BUCK  2

/**
 * ADC寄存器BUCK_ADC_CH指向的位置
 */
#define BUCK1VIN            0
#define BUCK1VOUT           1
#define BUCK2VIN            2
#define BUCK2VOUT           3
#define BUCKVCC             4
#define BUCKTEMP            5
#define ADC_CHANNEL_COUNT   6
#define ADC_DATAGET_CYC     8

/**
 * 所有寄存器地址信息
*/
#define SIL_REV_ADDR            0x01 // 硅片修订和OTP状态
#define DEV_CFG_ADDR            0x03 // 设备配置和PWM调光模式
#define PWM_DIM1_ADDR           0x04 // Buck 1的PWM调光占空比
#define PWM_DIM2_ADDR           0x05 // Buck 2的PWM调光占空比
#define ANA_DIM1_ADDR           0x06 // Buck 1的模拟调光
#define ANA_DIM2_ADDR           0x07 // Buck 2的模拟调光
#define INT_ALL_ADDR            0x08 // 全局中断状态
#define INT_CFG_ADDR            0x09 // 中断配置
#define FS_INT_STATUS_ADDR      0x0A // 中断状态寄存器
#define FS_INT_RAW_STATUS_ADDR  0x0B // 原始中断状态
#define FS_INT_EN_ADDR          0x0C // 中断使能
#define FS_INT_MASK_EN_ADDR     0x0D // 中断屏蔽
#define FS_INT_RT_STATUS_ADDR   0x0E // 实时中断状态
#define BUCK1_CFG_ADDR          0x10 // Buck 1配置
#define BUCK2_CFG_ADDR          0x11 // Buck 2配置
#define ADC_CTRL_ADDR           0x12 // ADC控制
#define ADC_DATA_ADDR           0x13 // ADC数据
#define OTP_STATUS_ADDR         0x15 // OTP状态
#define BUCK_EN_ADDR            0x20 // Buck使能控制

/**
 * DEV_CFG_ADDR寄存器信息
*/
#define DP_DIM3_125HZ 0x5000 // 双相，DIM1和DIM2模式3，频率125Hz
#define DP_DIM3_250HZ 0x5500 // 双相，DIM1和DIM2模式3，频率250Hz
#define DP_DIM3_500HZ 0x5A00 // 双相，DIM1和DIM2模式3，频率500Hz
#define DP_DIM3_1KHZ  0x5F00 // 双相，DIM1和DIM2模式3，频率1kHz

/**
 * PWM_DIM_ADDR寄存器信息
*/
#define PWM_DIM_0_PERCENT    0x0000 // 0% 占空比
#define PWM_DIM_5_PERCENT    0xCC00 // 5% 占空比
#define PWM_DIM_10_PERCENT   0x9901 // 10% 占空比
#define PWM_DIM_12_PERCENT   0xF301 // 12% 占空比
#define PWM_DIM_15_PERCENT   0x6602 // 15% 占空比
#define PWM_DIM_20_PERCENT   0x3303 // 20% 占空比
#define PWM_DIM_25_PERCENT   0xFF03 // 25% 占空比
#define PWM_DIM_30_PERCENT   0xCC04 // 30% 占空比
#define PWM_DIM_35_PERCENT   0x9905 // 35% 占空比
#define PWM_DIM_40_PERCENT   0x6606 // 40% 占空比
#define PWM_DIM_45_PERCENT   0x3207 // 45% 占空比
#define PWM_DIM_50_PERCENT   0xFF07 // 50% 占空比
#define PWM_DIM_55_PERCENT   0xCC08 // 55% 占空比
#define PWM_DIM_60_PERCENT   0x9909 // 60% 占空比
#define PWM_DIM_65_PERCENT   0x650A // 65% 占空比
#define PWM_DIM_70_PERCENT   0x320B // 70% 占空比
#define PWM_DIM_75_PERCENT   0xFF0B // 75% 占空比
#define PWM_DIM_80_PERCENT   0xCC0C // 80% 占空比
#define PWM_DIM_85_PERCENT   0x980D // 85% 占空比
#define PWM_DIM_90_PERCENT   0x650E // 90% 占空比
#define PWM_DIM_95_PERCENT   0x320F // 95% 占空比
#define PWM_DIM_100_PERCENT  0xFF0F // 100% 占空比

//计算电阻R上的电压V
//采样电阻为0.13Ω，V = 0.1A * 0.13ohm = 0.013V
//N = (0.013V / 200mV) * 200 = 13 (即0x0D)
#define ANA_CUR_100MA         0x0D00 // 100mA
#define ANA_CUR_120MA         0x0F00 // 120mA
#define ANA_CUR_140MA         0x1200 // 140mA
#define ANA_CUR_160MA         0x1400 // 160mA
#define ANA_CUR_180MA         0x1700 // 180mA
#define ANA_CUR_200MA         0x1A00 // 200mA
#define ANA_CUR_300MA         0x2700 // 300mA
#define ANA_CUR_400MA         0x3400 // 400mA
#define ANA_CUR_500MA         0x4100 // 500mA
#define ANA_CUR_600MA         0x4E00 // 600mA
#define ANA_CUR_700MA         0x5B00 // 700mA
#define ANA_CUR_800MA         0x6800 // 800mA
#define ANA_CUR_900MA         0x7500 // 900mA
#define ANA_CUR_1000MA        0x8200 // 1000mA
#define ANA_CUR_1100MA        0x8F00 // 1100mA
#define ANA_CUR_1200MA        0x9C00 // 1200mA
#define ANA_CUR_1300MA        0xA900 // 1300mA
#define ANA_CUR_1400MA        0xB600 // 1400mA
#define ANA_CUR_1500MA        0xC300 // 1500mA

#define ANA_CUR_958MA         0x7C00 // 958mA
#define ANA_CUR_919MA         0x7700 // 919mA
#define ANA_CUR_878MA         0x7200 // 878mA
#define ANA_CUR_855MA         0x6F00 // 855mA
#define ANA_CUR_805MA         0x6800 // 805mA

// 在启动ovp之前需要关闭所有hiccup模式
#define  INT_CFG_ALLNOACT                0x53FF//全无动作
#define  INT_CFG_ALLOFF                  0x0050//全锁
#define  INT_CFG_ONLY_TSD_HICCUP         0x5100//过温关断做打嗝，其他UV,OV闩锁
#define  INT_CFG_OCP_TSD_HICCUP          0x5250//UVP-OFF,OCP-hc,OTP-hc
#define  INT_CFG_ALL_HICCUP              0x5255//all-hc
#define  INT_CFG_ALL_OFF                 0x5200//all-off
#define  INT_CFG_DEFAULT                 0x5155//全部故障做打嗝处理
#define  INT_CFG_DESIGN                  0x50AA//过热打嗝，其他保持输出

#define  CLR_ALL_INT_FLAG                0xFCB7//清除所有故障flag
#define  CLR_BUCK1_OCP_FLAG              0x0080//清除buck1过流flag
#define  CLR_BUCK1_UVP_FLAG              0x0020//清除buck1欠压flag
#define  CLR_BUCK2_OCP_FLAG              0x0010//清除buck2过流flag
#define  CLR_BUCK2_UVP_FLAG              0x0004//清除buck2欠压flag
#define  CLR_PHASE_ERR_FLAG              0x0002//清除相控制安全错误flag
#define  CLR_THERM_WAR_FLAG              0x0001//清除过温警告flag
#define  CLR_THERM_STD_FLAG              0x8000//清除过温关断flag
#define  CLR_BST1_UV_FLAG                0x4000//清除buck1 boot 无用flag
#define  CLR_BST2_UV_FLAG                0x2000//清除buck2 boot 无用flag
#define  CLR_OTP_ERR_FLAG                0x0800//清除OTP故障flag
#define  CLR_OTP_PERR_FLAG               0x0400//清除OTP编程后故障flag
#define  CLR_OTP_CRC_FLAG                0x0200//清除OTP-CRC故障flag

#define FS_TEMP_CTRL            0xB7FE//临时验证
#define FS_EN_ALL_CTRL          0xFCB7//all en
#define FS_EN_NOR_CTRL          0xE0B5//phase dis&otp dis
#define FS_DIS_ALL_CTRL         0x0000//all dis
#define FS_EN_OCP_CTRL          0x0090//OCP EN
#define FS_EN_UVP_CTRL          0x0024//UVP EN
#define FS_EN_TW_CTRL           0x0001//TW EN
#define FS_EN_TSD_CTRL          0x8000//TSD EN
#define FS_EN_BST1_CTRL         0x4000//BST1 UV EN
#define FS_EN_BST2_CTRL         0x2000//BST2 UV EN
#define FS_EN_OTPERR_CTRL       0x1000//OTP INT EN
#define FS_EN_OTPPERR_CTRL      0x0800//OTP PROG EN
#define FS_EN_CRC_CTRL          0x0400//OTP CRC EN
#define FS_EN_DESIGN            0xE0B5//开启常规功能，以上均为术语，如果不懂，中文注释还是会不懂，不用挣扎

#define MASK_EN_ALL_CTRL          0xFCB7//all en
#define MASK_EN_NOR_CTRL          0xE0B5//phase dis&otp dis
#define MASK_DIS_ALL_CTRL         0x0000//all dis
#define MASK_EN_OCP_CTRL          0x0090//OCP EN
#define MASK_EN_UVP_CTRL          0x0024//UVP EN
#define MASK_EN_TW_CTRL           0x0001//TW EN
#define MASK_EN_TSD_CTRL          0x8000//TSD EN
#define MASK_EN_BST1_CTRL         0x4000//BST1 UV EN
#define MASK_EN_BST2_CTRL         0x2000//BST2 UV EN
#define MASK_EN_OTPERR_CTRL       0x1000//OTP INT EN
#define MASK_EN_OTPPERR_CTRL      0x0800//OTP PROG EN
#define MASK_EN_CRC_CTRL          0x0400//OTP CRC EN
#define MASK_EN_DESIGN            0xE0B5//将没开启的功能屏蔽

#define BOOST1VIN_ADC_CTRL      0x0800//BUCK1 INPUT
#define BOOST1VOUT_ADC_CTRL     0x0900//BUCK1 OUTPUT
#define BOOST2VIN_ADC_CTRL      0x0A00//BUCK2 INPUT
#define BOOST2VOUT_ADC_CTRL     0x0B00//BUCK2 OUTPUT

#define BUCK1VIN_ADC_CTRL       0x0800 // 指向buck1的输入电压即boost的输出电压
#define BUCK1VOUT_ADC_CTRL      0x0900 // 指向buck1的输出电压即cc1或cc3的输出电压
#define BUCK2VIN_ADC_CTRL       0x0A00 // 指向buck2的输入电压即boost的输出电压
#define BUCK2VOUT_ADC_CTRL      0x0B00 // 指向buck2的输出电压即cc2或cc4的输出电压
#define BUCKVCC_ADC_CTRL        0x0C00 // 指向vcc vin即MPQ7210的LDO供电
#define BUCKTEMP_ADC_CTRL       0x0D00 // 指向MPQ7210温度TJ

/*禁止使能CC的时候超过10ms控制该寄存器拉低*/

#define BUCK1_EN_CTRL           0x8000//BUCK1 EN
#define BUCK2_EN_CTRL           0x0800//BUCK2 EN
#define BUCK_EN_CTRL            0x8800//BUCK1&2 EN
#define BUCK_DIS_CTRL           0x0000//BUCK1&2 DIS

// 用来存放寄存器数据
typedef struct {
    float buck_value_sum[6]; // 用来存放滤波运算的平均值
    float real_buck_value[6]; // 用于存放对应读数的实际值
    uint16_t hexResult[6]; // 用来存放DataBuf转换成的16进制结果
    uint8_t  DataBuf[6][3]; // 存储来自0x13寄存器的数据
    float buck1_vin_value[6][8]; // 用于存放buck 1输入: VIN1的值
    float buck1_vout_value[6][8]; // 用于存放buck 1输出: VOUT1的值
    float buck2_vin_value[6][8]; // 用于存放buck 2输入: VIN2的值
    float buck2_vout_value[6][8]; // 用于存放buck 2输出: VOUT2的值
    float buck_vcc_value[6][8]; // 用于存放VCC电压: VCC的值
    float buck_temp_value[6][8]; // 用于存放部件温度: TJ的值
    // 000: CH1, buck 1输入: VIN1
    // 001: CH2, buck 1输出: VOUT1
    // 010: CH3, buck 2输入: VIN2
    // 011: CH4, buck 2输出: VOUT2
    // 100: CH5, VCC电压: VCC
    // 101: 部件温度: TJ
} MPQ_ADC_Config_t;

// SIL_REV (0x01)
typedef struct {
	uint16_t silicon_info : 8;    // 硅片修订信息（位D[7:0]）
	uint16_t reserved1    : 7;    // 保留位（位D[14:8]）
    uint16_t otp_complete : 1;    // OTP完成标志（位D15）
} SIL_REV_Reg_t;

// DEV_CFG (0x03)
typedef struct {
    uint16_t dim2_freq   : 2;    // Buck 2的调光频率（位D[1:0]）
    uint16_t dim1_freq   : 2;    // Buck 1的调光频率（位D[3:2]）
    uint16_t dim2_mode   : 2;    // Buck 2的调光模式（位D[5:4]）
    uint16_t dim1_mode   : 2;    // Buck 1的调光模式（位D[7:6]）
    uint16_t phase       : 2;    // 相位选择（位D[9:8]）
    uint16_t reserved2   : 6;    // 保留位（位D[15:10]）
} DEV_CFG_Reg_t;

// PWM_DIM1 (0x04)
typedef struct {
	uint16_t pwm_dim1_duty : 12; // Buck 1的PWM调光占空比（位D[11:0]）
    uint16_t reserved3   : 4;    // 保留位（位D[15:12]）
} PWM_DIM1_Reg_t;

// PWM_DIM2 (0x05)
typedef struct {
	uint16_t pwm_dim2_duty : 12; // Buck 2的PWM调光占空比（位D[11:0]）
    uint16_t reserved4   : 4;    // 保留位（位D[15:12]）
} PWM_DIM2_Reg_t;

// ANA_DIM1 (0x06)
typedef struct {
	uint16_t ana_dim1    : 8;    // Buck 1的模拟调光设置（位D[7:0]）
    uint16_t reserved5   : 8;    // 保留位（位D[15:8]）
} ANA_DIM1_Reg_t;

// ANA_DIM2 (0x07)
typedef struct {
	uint16_t ana_dim2    : 8;    // Buck 2的模拟调光设置（位D[7:0]）
    uint16_t reserved6   : 8;    // 保留位（位D[15:8]）
} ANA_DIM2_Reg_t;

// INT_ALL (0x08)
typedef struct {
	uint16_t int_status  : 1;    // 中断状态（位D0）
    uint16_t reserved7   : 15;   // 保留位（位D[15:1]）ss
} INT_ALL_Reg_t;

// INT_CFG (0x09)
typedef struct {
	uint16_t reserved9     : 2;  // 保留位（位D[1:0]）
	uint16_t tsd           : 2;  // 热关机响应（位D[3:2]）
	uint16_t reserved8     : 4;  // 保留位（位D[7:4]）
	uint16_t buck2_uvp_act : 2;  // Buck 2的欠压保护响应（位D[9:8]）
	uint16_t buck1_uvp_act : 2;  // Buck 1的欠压保护响应（位D[11:10]）
	uint16_t buck2_ocp_act : 2;  // Buck 2的过电流保护响应（位D[13:12]）
    uint16_t buck1_ocp_act : 2;  // Buck 1的过电流保护响应（位D[15:14]）
} INT_CFG_Reg_t;

// FS_INT_STATUS (0x0A) int_status == 0意味着没有触发，为1是有故障且此时FS引脚会拉低，故障消失后写1会清除flag
typedef struct {
	uint16_t reserved12           : 2;  // 保留位（位D[1:0]）
	uint16_t otp_crc_fail_int_status : 1;  // OTP CRC失败中断状态（位D2）
	uint16_t otp_prog_fail_int_status : 1;  // OTP编程失败中断状态（位D3）
	uint16_t otp_ind_fail_int_status : 1;  // OTP指示故障中断状态（位D4）
	uint16_t bst2_uv_int_status   : 1;  // Buck 2引导电压中断状态（位D5）
	uint16_t bst1_uv_int_status   : 1;  // Buck 1引导电压中断状态（位D6）
	uint16_t tsd_int_status       : 1;  // 热关机中断状态（位D7）
	uint16_t twn_int_status       : 1;  // 温度警告中断状态（位D8）
	uint16_t phase_int_status     : 1;  // 相位控制安全错误中断状态（位D9）
	uint16_t buck2_uvp_int_status : 1;  // Buck 2欠压中断状态（位D10）
	uint16_t reserved11           : 1;  // 保留位（位D11）
	uint16_t buck2_ocp_int_status : 1;  // Buck 2过电流中断状态（位D12）
	uint16_t buck1_uvp_int_status : 1;  // Buck 1欠压中断状态（位D13）
	uint16_t reserved10           : 1;  // 保留位（位D14）
    uint16_t buck1_ocp_int_status : 1;  // Buck 1过电流中断状态（位D15）
} FS_INT_STATUS_Reg_t;

// FS_INT_RAW_STATUS (0x0B)
typedef struct {
	uint16_t reserved1 : 2;                    // 锟斤拷锟斤拷 (D[1:0])
    uint16_t otp_crc_fail_int_raw_status : 1;  // OTP CRC锟斤拷锟斤拷原�?�锟�??讹拷状�? (D[2])
    uint16_t otp_prog_fail_int_raw_status : 1; // OTP锟斤拷锟绞э拷锟皆硷拷卸锟阶刺� (D[3])
    uint16_t otp_ind_fail_int_raw_status : 1;  // OTP指示失锟斤拷原�?�锟�??讹拷状�? (D[4])
    uint16_t bst2_uv_int_raw_status : 1;       // Buck 2 BST UV原�?�锟�??讹拷状�? (D[5])
    uint16_t bst1_uv_int_raw_status : 1;       // Buck 1 BST UV原�?�锟�??讹拷状�? (D[6])
    uint16_t tsd_int_raw_status : 1;           // 锟饺关伙拷原始锟�??讹拷状�? (D[7])
    uint16_t twn_int_raw_status : 1;           // 锟铰度撅拷锟斤拷原�?�锟�??讹拷状�? (D[8])
    uint16_t phase_int_raw_status : 1;         // 锟斤拷位锟斤拷锟狡帮拷全锟斤拷锟斤拷原�?�锟�??讹拷状�? (D[9])
    uint16_t reserved2 : 1;                    // 锟斤拷锟斤拷 (D[10])
    uint16_t buck2_uvp_int_raw_status : 1;     // Buck 2 欠压锟斤拷锟斤拷原�?�锟�??讹拷状�? (D[11])
    uint16_t reserved3 : 1;                    // 锟斤拷锟斤拷 (D[12])
    uint16_t buck1_uvp_int_raw_status : 1;     // Buck 1 欠压锟斤拷锟斤拷原�?�锟�??讹拷状�? (D[13])
    uint16_t reserved4 : 1;                    // 锟斤拷锟斤拷 (D[14])
    uint16_t buck1_ocp_int_raw_status : 1;     // Buck 1 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷原始锟�??讹拷状�? (D[15])
} FS_INT_RAW_STATUS_Reg_t;

// FS_INT_EN (0x0C)
typedef struct {
	uint16_t reserved1 : 2;           // 保留 (D[1:0])
    uint16_t otp_crc_fail_en : 1;     // OTP CRC失败中断使能 (D[2])
    uint16_t otp_prog_fail_en : 1;    // OTP编程失败中断使能 (D[3])
    uint16_t otp_ind_fail_en : 1;     // OTP指示失败中断使能 (D[4])
    uint16_t bst2_uv_en : 1;          // Buck 2 BST UV中断使能 (D[5])
    uint16_t bst1_uv_en : 1;          // Buck 1 BST UV中断使能 (D[6])
    uint16_t tsd_en : 1;              // 热关机中断使能 (D[7])
    uint16_t twn_en : 1;              // 温度警告中断使能 (D[8])
    uint16_t phase_en : 1;            // 相位控制安全错误中断使能 (D[9])
    uint16_t reserved2 : 1;           // 保留 (D[10])
    uint16_t buck2_uvp_en : 1;        // Buck 2 欠压保护中断使能 (D[11])
    uint16_t reserved3 : 1;           // 保留 (D[12])
    uint16_t buck1_uvp_en : 1;        // Buck 1 欠压保护中断使能 (D[13])
    uint16_t reserved4 : 1;           // 保留 (D[14])
    uint16_t buck1_ocp_en : 1;        // Buck 1 过电流保护中断使能 (D[15])
} FS_INT_EN_Reg_t;

//FS_INT_MASK_EN (0x0D)
typedef struct {
	uint16_t reserved1 : 2;                    // 保留 (D[1:0])
    uint16_t otp_crc_fail_int_mask_en : 1;     // OTP CRC失败中断屏蔽 (D[2])
    uint16_t otp_prog_fail_int_mask_en : 1;    // OTP编程失败中断屏蔽 (D[3])
    uint16_t otp_ind_fail_int_mask_en : 1;     // OTP指示失败中断屏蔽 (D[4])
    uint16_t bst2_uv_int_mask_en : 1;          // Buck 2 BST UV中断屏蔽 (D[5])
    uint16_t bst1_uv_int_mask_en : 1;          // Buck 1 BST UV中断屏蔽 (D[6])
    uint16_t tsd_int_mask_en : 1;              // 热关机中断屏蔽 (D[7])
    uint16_t tw_int_mask_en : 1;               // 温度警告中断屏蔽 (D[8])
    uint16_t phase_int_mask_en : 1;            // 相位控制安全错误中断屏蔽 (D[9])
    uint16_t reserved32 : 1;                    // 保留 (D[10])
    uint16_t buck2_uvp_int_mask_en : 1;        // Buck 2 欠压保护中断屏蔽 (D[11])
    uint16_t reserved3 : 1;                    // 保留 (D[12])
    uint16_t buck1_uvp_int_mask_en : 1;        // Buck 1 欠压保护中断屏蔽 (D[13])
    uint16_t reserved4 : 1;                    // 保留 (D[14])
    uint16_t buck1_ocp_int_mask_en : 1;        // Buck 1 过电流保护中断屏蔽 (D[15])
} FS_INT_MASK_EN_Reg_t;

//FS_INT_REAL_TIME_STATUS (0x0E)
typedef struct {
    uint16_t reserved1 : 8;           // 保留位 (D[7:0])
    uint16_t tsd_status : 1;           // 实时热关机状态 (D[8])
    uint16_t tw_status : 1;            // 实时温度警告状态 (D[9])
    uint16_t buck2_uvp_status : 1;     // Buck 2 实时欠压保护状态 (D[10])
    uint16_t reserved2 : 1;            // 保留位 (D[11])
    uint16_t buck2_ocp_status : 1;     // Buck 2 实时过电流保护状态 (D[12])
    uint16_t buck1_uvp_status : 1;     // Buck 1 实时欠压保护状态 (D[13])
    uint16_t reserved3 : 1;            // 保留位 (D[14])
    uint16_t buck1_ocp_status : 1;     // Buck 1 实时过电流保护状态 (D[15])
} FS_INT_REAL_TIME_STATUS_Reg_t;

// BUCK1_CFG (0x10)
typedef struct {
    uint16_t buck1_ocp_sel : 3;       // 设置Buck 1的高侧电流限制 (D[2:0])
                                      // 000: 500mA, 001: 1A, 010: 1.5A, 011: 2A,
                                      // 100: 2.5A, 101: 3A, 110: 3.5A, 111: 4A
    uint16_t buck1_fss_en : 1;        // 启用频率扩展 (D[3])
                                      // 0: 禁用, 1: 启用
    uint16_t buck1_freq_sel : 2;      // 设置Buck 1的开关频率选择 (D[5:4])
                                      // 00: 220kHz, 01: 420kHz, 10: 1.1MHz, 11: 2.3MHz
    uint16_t reserved : 10;           // 保留位 (D[15:6])
} BUCK1_CFG_Reg_t;

// BUCK2_CFG (0x11)
typedef struct {
    uint16_t buck2_ocp_sel : 3;       // 设置Buck 2的高侧电流限制 (D[2:0])
                                      // 000: 500mA, 001: 1A, 010: 1.5A, 011: 2A,
                                      // 100: 2.5A, 101: 3A, 110: 3.5A, 111: 4A
    uint16_t buck2_fss_en : 1;        // 启用Buck 2的频率扩展 (D[3])
                                      // 0: 禁用, 1: 启用
    uint16_t buck2_freq_sel : 2;      // 设置Buck 2的开关频率选择 (D[5:4])
                                      // 00: 220kHz, 01: 420kHz, 10: 1.1MHz, 11: 2.3MHz
    uint16_t reserved : 10;           // 保留位 (D[15:6])
} BUCK2_CFG_Reg_t;

// ADC_CTRL (0x12)
typedef struct {
    uint16_t adc_inmux : 3;           // ADC输入多路选择器 (D[2:0])
                                      // 000: CH1, Buck 1输入: VIN1
                                      // 001: CH2, Buck 1输出: VOUT1
                                      // 010: CH3, Buck 2输入: VIN2
                                      // 011: CH4, Buck 2输出: VOUT2
                                      // 100: CH5, VCC电压: VCC
                                      // 101: 部件温度: TJ
                                      // 110, 111: 未使用
    uint16_t trig_adc_read : 1;       // 触发ADC读取 (D[3])
                                      // 写1开始ADC读取，读取结束后自动归0
    uint16_t adc_ready : 1;           // ADC可读就绪信号 (D[4])
                                      // 1: ADC准备就绪或可读取ADC值
                                      // 0: ADC忙
    uint16_t cur_stored_ch : 3;       // 当前存储的ADC感应通道 (D[7:5])
                                      // 记录当前设置的ADC感应通道
    uint16_t reserved : 8;            // 保留位 (D[15:8])
} ADC_CTRL_Reg_t;

// ADC_OUT (0x13)
typedef struct {
	uint16_t no_use   : 2;     // ADC数据最后2位，精度不够丢弃（位D[1:0]）
	uint16_t adc_data   : 8;     // ADC数据用于运算得数据（位D[9:2]）
    uint16_t reserved16 : 6;      // 保留位（位D[15:10]）
} ADC_OUT_Reg_t;

// OTP_STATUS (0x15)
typedef struct {
    uint16_t reserved1 : 10;          // 保留位 (D[10:0])
    uint16_t user_page_crc_err_flag : 1; // 用户页面OTP CRC错误标志 (D[11])
                                        // 1: 存在用户页面OTP CRC错误
                                        // 0: 无用户页面OTP CRC错误
    uint16_t trim_page_crc_err_flag : 1; // 修剪页面OTP CRC错误标志 (D[12])
                                        // 1: 存在修剪页面OTP CRC错误
                                        // 0: 无修剪页面OTP CRC错误
    uint16_t otp_crc_err_flag : 1;     // OTP CRC错误标志 (D[13])
                                       // 1: OTP CRC错误
                                       // 0: 无OTP CRC错误
    uint16_t da_otp_rdy : 1;           // OTP数字读取完成标志 (D[14])
                                       // 1: OTP数字读取完成
                                       // 0: OTP数字读取未完成
    uint16_t reserved2 : 1;            // 保留位 (D[15])
} OTP_STATUS_Reg_t;

// BUCK_EN (0x20)
typedef struct {
    uint16_t reserved1 : 3;          // 保留位 (D[2:0])
    uint16_t buck2_en : 1;           // Buck 2使能控制 (D[3])
                                     // 0: 启用, 1: 禁用
    uint16_t reserved2 : 3;          // 保留位 (D[6:4])
    uint16_t buck1_en : 1;           // Buck 1使能控制 (D[7])
                                     // 0: 启用, 1: 禁用
    uint16_t reserved3 : 8;          // 保留位 (D[15:8])
} BUCK_EN_Reg_t;

typedef enum
{
	eMPQ7210x_INIT,
	eMPQ7210x_MODIF_ADDR,
	eMPQ7210x_LED_CONTROL,
	eMPQ7210x_GET_ADC,
}eMPQ7210x_WORK_STATE_t;

typedef struct
{
	eMPQ7210x_WORK_STATE_t WorkMode;
	uint8_t  InitOperIndex;
	uint8_t  LookDeviceTimes;
	uint8_t  bOnLine[MPQ7210x_DEVICE_MAX];
	uint16_t Chx_State[MPQ7210x_DEVICE_MAX];
}sMPQ7210x_DEVICE_STATE_t,*psMPQ7210x_DEVICE_STATE_t;

typedef struct
{
	uint8_t  addr;
	uint16_t data;
}sMPQ7210_wCMD_STRUCT, *psMPQ7210_wCMD_STRUCT;

//extern uint8_t diagnosticFlag;//诊断标志变量，用来限制adc平均值转�??

extern uint8_t data_length;
extern uint8_t normal_length;
extern uint8_t ADC_length;
extern uint8_t HBLB_length;
extern uint8_t LB_length;
extern uint8_t HB_length;
extern uint8_t DRL_length;
extern uint8_t PL_length;
extern uint8_t TI_length;
extern uint8_t DRL_TICm_length;


extern sMPQ7210_wCMD_STRUCT MPQ7210_NORMAL_CmdTable[];
extern sMPQ7210_wCMD_STRUCT ADC_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two500_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one958_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two958_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one919_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one878_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two855_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two805_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one100_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two100_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one90_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two90_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one80_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_onetest_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two80_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one70_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two70_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one60_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two60_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one50_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two50_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one90_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two90_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one80_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two80_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one70_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two70_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one60_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two60_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one50_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two50_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one200_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two200_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one180_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two180_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one160_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two160_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one100_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two100_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_one20_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DS_two10_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one180_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two180_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one160_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two160_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one140_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two140_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_one120_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_AS_two120_CmdTable[];


extern sMPQ7210_wCMD_STRUCT MPQ7210_InitCmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DRL_TICmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable80[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable80[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_30_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_30_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_40_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_40_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_50_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_50_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_60_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_60_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_70_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_70_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_80_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_80_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_90_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_90_two_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_100_One_CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_100_two_CmdTable[];

extern sMPQ7210_wCMD_STRUCT MPQ7210_30_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_30_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_40_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_40_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_50_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_50_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_60_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_60_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_70_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_70_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_80_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_80_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_90_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_90_two_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_100_One_200CmdTable[];
extern sMPQ7210_wCMD_STRUCT MPQ7210_100_two_200CmdTable[];
// 定义一个结构体数组，用于存储所有BUCK_ADC通道的数值
extern MPQ_ADC_Config_t MPQ7210_ADC_Registers[];


extern void Sl_MPQ7210_16bit_receive(uint8_t DevType, uint8_t *Read_AddrCmdTable,uint8_t *Readdata);
extern void LLD_MPQ7210_Oper(uint8_t DevType, uint8_t bWR, uint8_t addr, uint8_t *pInData, uint8_t *pOutData,  uint8_t dlen);
//extern void Sl_MPQ7210_driver(uint8_t DevType,uint8_t status,sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length);
extern void Sl_MPQ7210_receive(uint8_t DevType,uint8_t *MPQ7210_AddrCmdTable);
extern void MPQ7210x_ControlLED_Process(void);
extern void Flash_send_fun(uint8_t DevType,uint8_t status,uint16_t *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length);
extern uint8_t LLD_MPQ7210_rxtxOper(uint8_t DevType, uint8_t bWR, uint8_t addr, uint8_t* pInData, uint8_t * pOutData, uint8_t dlen);
void SPI_CS_DEAL(uint8_t DevType);
extern void SPI_CS_CLR(void);



extern void Sl_MPQ7210_send(uint8_t DevType,uint8_t status,sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length);
extern void MPQ7210_adc_send(uint8_t DevType, uint8_t status, sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable, MPQ_ADC_Config_t *adcDataStr, uint8_t Length);
extern void Flash_send_fun(uint8_t DevType,uint8_t status,uint16_t *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length);
extern void app_spi_part(void);
extern void app_spi90_part(void);
extern void app_spi85_part(void);
extern void app_spi80_part(void);
extern void app_spi70_part(void);
extern void app_spi60_part(void);
extern void app_spi50_part(void);
extern void app_spi0_part(void);
#endif /* MPQ7210_DRIVER_H_ */
