/******************************************************************************
*
*   COPYRIGHT       : Ternary 
*   FILENAME        : $Source: _Rtos.c $
*   COMPILER        : IAR IDE  9.40.1
*   PROCESSOR       : YTM32B1ME0
*
*   DATE OF CREATION: 10.03.2024
*   LAST REVISION   : $Date  : 10.03.2024 $
*                     $Author:        $
*
******************************************************************************/

 
 /* ========= File define =================================================== */
#define _Rtos_c

/* ========== Includes ====================================================== */
#include "_Rtos.h"
#include "_Tasks.h"
//#include "Mcal.h"
#include "FreeRTimer.h"

uint32_t _rtos_slice=0;
uint32_t _sys_tick=0;
uint16_t _sch_procedure_period=0;
/* ========== Local Defines, Enumerations, Type Definitions ================= */

/* ========== Local Function Prototypes ===================================== */

/* ========== Local Macros ================================================== */

/* ========== Local Variables =============================================== */
#define NULL_PTR  ((void *)0)

/*                          rate_mask,         compare_val    *next,         task_id  */
TASK task_9_def  = {(1000 / SYS_TICK),   63,  NULL_PTR,         TASK_1000_MS};
TASK task_8_def  = { (500 / SYS_TICK),   29, &task_9_def,   TASK_500_MS};
TASK task_7_def  = { (250 / SYS_TICK),   21, &task_8_def,   TASK_250_MS};
TASK task_6_def  = { (100 / SYS_TICK),   13, &task_7_def,   TASK_100_MS};
TASK task_5_def  = {  (50 / SYS_TICK),   7,  &task_6_def,   TASK_50_MS};
TASK task_4_def  = {  (20 / SYS_TICK),   3,  &task_5_def,   TASK_20_MS_B};
TASK task_3_def  = {  (20 / SYS_TICK),   1,  &task_4_def,   TASK_20_MS_A};
TASK task_2_def  = {  (10 / SYS_TICK),   0,  &task_3_def,   TASK_10_MS};
TASK task_1_def  = {   (5 / SYS_TICK),   0,  &task_2_def,   TASK_5_MS};

TASK *task_table_head = &task_1_def;


/* ========== Local Functions =============================================== */

/* ========== Global Functions ============================================== */

/* ************************************************************************** */
/*!
 * @fn         void _Rtos_Init(void)
 * @brief      Rtos Init
 * @details    none
 */
/* ************************************************************************** */
void _Rtos_Init(void)
{ 
  _rtos_slice = 0;
  _sys_tick = 0;
}

 /* ************************************************************************** */
 /*!
  * @fn         void _Rtos_Task(void)
  * @brief      Rtos Task
  * @details    none
  */
 /* ************************************************************************** */
 void _Rtos_Task(void)
{
  _rtos_slice = _sys_tick;
  for(;;) 
  {
    if(_rtos_slice != _sys_tick)
    {
      break;
    }
  }
  _sys_tick = 0;
  _rtos_slice = _sys_tick;
  //__RESET_WATCHDOG();	/* feeds the dog */
  for(;;)
  {

    task_table_head = &task_1_def;		
    _Check_Tasks(task_table_head);
    while (_rtos_slice == _sys_tick)
    {
    }
    // __RESET_WATCHDOG();	/* feeds the dog */
    _rtos_slice++;
  }
}

 /* ************************************************************************** */
 /*!
  * @fn         _Check_Tasks( TASK *current_task)
  * @brief      Check Task
  * @details    none
  */
 /* ************************************************************************** */
 void _Check_Tasks( TASK *current_task)
{
  while (current_task != NULL_PTR)
  {
    if ((_rtos_slice%current_task->rate_mask) == current_task->compare_value)
    {
      _sch_procedure_period=current_task->rate_mask;
      _Exec_Routines(current_task->task_id);
    }
    current_task = current_task->next;
  }
}

/* ************************************************************************** */
/*!
 * @fn         _Exec_Routines(TASK_ID task_id)
 * @brief      Exe Task
 * @details    none
 */
/* ************************************************************************** */
void _Exec_Routines(TASK_ID task_id)
{
  switch (task_id)
  {
    case TASK_5_MS:

      _5msTask();

    break;

    case TASK_10_MS:

      _10ms_Task();

    break;
  
    case TASK_20_MS_A:

      _20ms_A_Task();

    break;

    case TASK_20_MS_B:

      _20ms_B_Task();

    break;
    case TASK_50_MS:

      _50msTask();

    break;

    case TASK_100_MS:

      _100msTask();

    break;
	case TASK_250_MS:
	
	 _250msTask();
	
	   break;

    case TASK_500_MS:

      _500msTask();

    break;

    case TASK_1000_MS: 

      _1000msTask();

    break;

    default:
    break;
  }
}
   

void Gpt_Notification_GptChannelConfiguration_lptmr(void)
{

    static  uint8_t tick = 0;
    Run_msCounter();
    tick++;
    if( tick > 4)
    {
      tick = 0;
      _sys_tick++;
    }
}

void _Sys_Test(void)
{
  static  int temp =0;
  if(temp == 0)
  {
      temp = 1;
     // Dio_WriteChannel(DioConf_DioChannel_EN_PMOS_MCU_P, STD_HIGH);
  }
  else
  {
    temp = 0;
   // Dio_WriteChannel(DioConf_DioChannel_EN_PMOS_MCU_P, STD_LOW);
  }
}
