/*============================================================================*/
/*  Copyright (C) 2009-2018, iSOFT INFRASTRUCTURE SOFTWARE CO.,LTD.
 *
 *  All rights reserved. This software is iSOFT property. Duplication
 *  or disclosure without iSOFT written authorization is prohibited.
 *
 *  file       < FreeRTimer.c>
 *  brief      < FreeRTimer module file >
 *
 *  < Compiler:S32DS for ARM 2018.R1     MCU:S32K144/S32K146 >
 *
 *  author     < yongxing.jia >
 *  date       < 2018-12-12 >
 */
/*============================================================================*/
/******************************* references ************************************/
#include "FreeRTimer.h"

/****************************** implementations ********************************/
uint32 msCounter = 0;
void Run_msCounter(void)
{
	msCounter++;
}

Std_ReturnType FreeRtimer_GetCounterValue(uint16 id, TickType* tick)
{
	*tick = msCounter;
	return E_OK;
}

uint32 Frt_ReadOutMS(void)
{
	uint32  CurMs;
    (void)FreeRtimer_GetCounterValue(0, &CurMs);

	return(CurMs);
}

uint32 Frt_CalculateElapsedMS(uint32 OldCurMs)
{
	uint32  ElapsedMs = 0;

	if(OldCurMs <= msCounter)
	{
	    ElapsedMs = msCounter - OldCurMs;
	}
	else
	{
		ElapsedMs = (0xFFFFFFFF - OldCurMs) + msCounter;
	}

    return(ElapsedMs);
}
