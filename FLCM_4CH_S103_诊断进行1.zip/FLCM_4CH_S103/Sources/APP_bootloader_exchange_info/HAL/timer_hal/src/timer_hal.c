/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
/*!
 * @file timer_hal.c
 *
 * @brief: Add your description here for this file.
 *
 * @page misra_violations MISRA-C:2012 violations
 *
 * @section Rule_X-Y Rule: X.Y (Advisory/Required)
 * Violates MISRA 2012 Advisory Rule X.Y, Rule description here.
 *
 * @par Version Histroy
<pre><b>
Version:   Author:       Date&&Time:      Revision Log: </b>
 V1.0.0  Tomlin Tang  2019-01-17 15:30:01  First Creat
When you update, please do not forgot to del me and add your info at here.
</pre>
 */

#include "timer_hal.h"
#include "LLD_Config.h"
#include "sl_softtimer.h"
#include "al_light_function.h"
#include "_Rtos.h"
#include "Diagnostic_fault.h"

/*******************************************************************************
 * User Include
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
static uint16 gs_1msCnt = 0u;
static uint16 gs_100msCnt = 0u;

/**
 * @brief LPTMR中断服务函数
 *
 * 当LPTMR定时器触发中断时，该函数会被调用。
 * 该函数会清除LPTMR定时器的比较标志位，调用TIMER_HAL_1msPeriod函数处理1ms定时事件，
 * 调用sl_TimeBase1msProcess函数处理时间基准事件。
 * 如果bool_TL_state为真，则将ti_offtimer设置为600。
 * 如果ti_offtimer大于0，则将其减1。
 */
void LPTmr_ISR(void)
{
	// 清除LPTMR1的比较标志位
	LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
	static  uint8_t tick = 0;
	    //Run_msCounter();
	    tick++;
	    if( tick > 4)
	    {
	      tick = 0;
	      _sys_tick++;
	    }
	// 定时器得1ms基准
	TIMER_HAL_1msPeriod();

	// 软时钟得1ms基准
	sl_TimeBase1msProcess();

	if(e_MPQ7210_ERR.e_lamp.lhb.err_start_timer_flag)
	{
		e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_cnt++;
	}
	if(e_MPQ7210_ERR.e_lamp.lhb.recov_start_timer_flag)
	{
		e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_dec++;
	}
	if(e_MPQ7210_ERR.e_lamp.lb.err_start_timer_flag)
	{
		e_MPQ7210_ERR.e_lamp.lb.counter_500ms_cnt++;
	}
	if(e_MPQ7210_ERR.e_lamp.lb.recov_start_timer_flag)
	{
		e_MPQ7210_ERR.e_lamp.lb.counter_500ms_dec++;
	}
	// 如果转向灯点亮
	if(bool_TL_state)
	{
		// 将ti_offtimer设置为600ms
		ti_offtimer=600;
	}
	// 如果ti_offtimer大于0
	if(ti_offtimer > 0)
	{
		// 将ti_offtimer减1
		ti_offtimer--;
	}
}


/**
 * @brief 初始化定时器硬件抽象层
 *
 * 初始化定时器硬件抽象层，用于管理定时器相关的操作。
 */
void TIMER_HAL_Init(void)
{
	// 初始化LPTMR1驱动，使用lpTmr1_config0作为配置参数，并设置禁用中断
	LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0, false);

	// 安装LPTMR0中断处理程序，处理程序为LPTmr_ISR，无参数
	INT_SYS_InstallHandler(LPTMR0_IRQn, &LPTmr_ISR, NULL_PTR);

	// 启用LPTMR0中断
	INT_SYS_EnableIRQ(LPTMR0_IRQn);

	// 启用全局中断
	INT_SYS_EnableIRQGlobal();

	// 启动LPTMR1计数器
	LPTMR_DRV_StartCounter(INST_LPTMR1);
}

/*Timer 1ms period called*/
void TIMER_HAL_1msPeriod(void)
{
    uint16 cntTmp = 0u;

    // 只是为了检查时间是否溢出？
    /*Just for check time overflow or not?*/
    cntTmp = gs_1msCnt + 1u;
    if(0u != cntTmp)
    {
        gs_1msCnt++;
    }

    // 检查100ms计数是否溢出
    cntTmp = gs_100msCnt + 1u;
    if(0u != cntTmp)
    {
        gs_100msCnt++;
    }
}


/**
 * @brief 判断1ms计时器是否超时
 *
 * 判断全局变量gs_1msCnt是否非零，若为非零则表示1ms计时器超时，返回TRUE；否则返回FALSE。
 *
 * @return 如果1ms计时器超时，则返回TRUE；否则返回FALSE。
 */
boolean  TIMER_HAL_Is1msTickTimeout(void)
{
    // 初始化结果变量为FALSE
    boolean result = FALSE;

    // 如果全局变量gs_1msCnt不为0
    if(gs_1msCnt)
    {
        // 将结果变量设置为TRUE
        result = TRUE;

        // 将全局变量gs_1msCnt减1
        gs_1msCnt--;
    }

    // 返回结果变量
    return result;
}


/**
 * @brief 判断是否达到100ms计时超时
 *
 * 检查全局变量gs_100msCnt是否大于等于100，如果是，则将gs_100msCnt减去100，
 * 并返回TRUE，表示100ms计时超时；否则返回FALSE，表示未超时。
 *
 * @return 如果100ms计时超时，则返回TRUE；否则返回FALSE。
 */
boolean TIMER_HAL_Is100msTickTimeout(void)
{
    boolean result = FALSE;

    // 判断100ms计数器是否达到或超过100
    if(gs_100msCnt >= 100u)
    {
        // 如果达到或超过100，则设置result为TRUE
        result = TRUE;

        // 将100ms计数器减去100
        gs_100msCnt -= 100u;
    }

    // 返回result的值
    return result;
}

/**
 * @brief 获取定时器滴答计数器
 *
 * 获取定时器滴答计数器的值。
 *
 * @return 定时器滴答计数器的值
 */
uint32 TIMER_HAL_GetTimerTickCnt(void)
{
	// 这两个变量在使用前未初始化，因为它们用于生成随机数
	/*This two variables not init before used, because it used for generate random*/
	uint32 hardwareTimerTickCnt;
	uint32 timerTickCnt;

#if 0
	// 对于 S32K1xx 获取定时器计数器（LPTIMER），获取定时器计数会导致周期不正确。
	/*For S32K1xx get timer counter(LPTIMER), get timer count will trigger the period incorrect.*/
	hardwareTimerTickCnt = LPTMR_DRV_GetCounterValueByCount(INST_LPTMR1);
#endif

	// 将 hardwareTimerTickCnt 的低 16 位与 timerTickCnt 的高 16 位组合起来
	timerTickCnt = ((hardwareTimerTickCnt & 0xFFFFu)) | (timerTickCnt << 16u);

	return timerTickCnt;
}

/**
 * @brief 定时器硬件抽象层去初始化
 *
 * 此函数用于定时器硬件抽象层的去初始化操作。
 */
void TIMER_HAL_Deinit(void)
{


}
/******************************************************************************
 * EOF
 *****************************************************************************/
