/*
 * LLD_config.c
 *
 *  Created on: 2023年12月20日
 *      Author: gz06488
 */

#include "LLD_config.h"
#include "MPQ7210_driver.h"

/**
 * @brief 初始化引脚状态
 *
 * 此函数用于初始化引脚状态，包括 LDO 的使能引脚、SPI 设备的选择、PMOS 输入的使能等。
 *
 * @return 无返回值
 */

volatile uint32_t t_1ms_testcount = 2260;

void delay_1ms(uint32_t time)
{
	for(uint32_t j=0; j < (t_1ms_testcount*time); j++)
	{
		__asm("nop");
	}
}

void Pin_state_init(void)
{
	// 使能 LDO5VOUT 的 LDO_EN 引脚
	EN_LDO5VOUT_LDO_ENABLE;   // 启用 LDO_EN

	// 使能 BVCK5V_MCU 的 LDO_EN 引脚
	EN_BVCK5V_MCU_LDO_ENABLE; // 启用 LDO_EN

	// 初始化需要延时3ms，等待SPI稳定后再进行后续操作
	EN_IC1_CV_DISABLE; // 禁用 BOOST1_EN
	EN_IC2_CV_DISABLE; // 禁用 BOOST2_EN

	// 清除 SPI_CS 引脚，选择 SPI 设备
	SPI_CS_CLR(); // SPI片选信号清零

	// 使能 PMOS 输入
	Open_PMOS_Input_ENABLE; // 启用 PMOS 输入

	// 注释掉的部分是 PWM_IC2_DIM1 的禁用，因为 PWM 初始化时不需要 MPQ7210 DIM 功能，默认模式为3，默认值为0
	//Open_PWM_IC2_DIM1_DISABLE; // 禁用 PWM_IC2_DIM1

	// 禁用相关反馈引脚
	D1_EN_FB1_LB_FB_DISABLE;
	E11_EN_FB2_HB_FB_DISABLE;
	D0_EN_FB3_TL_FB_DISABLE;
	E10_EN_FB_DRL_PL_DISABLE; // 禁用相关反馈引脚

	// 禁用 BUCK 相关控制引脚
	Open_IC_CC1_EN1_DISABLE; // 禁用 BUCK1 的相关控制引脚
	Open_IC_CC2_EN2_DISABLE; // 禁用 BUCK2 的相关控制引脚
	Open_IC_CC3_EN1_DISABLE;
	Open_IC_CC4_EN2_DISABLE; // 禁用相关控制引脚

	// 禁用 LED 相关引脚
	B12_EN_LED1_HB_DISABLE;
	B13_EN_LED2_LB_DISABLE; // LED1 和 LED2 同时使用 EN 作为高边和低边的控制引脚
	A11_EN_LED5_TL_DISABLE;
	A12_EN_LED6_DRL_PL_DISABLE; // 禁用相关 LED 控制引脚

	// 禁用 BUCK CV 的相关控制引脚
	EN_IC3_4_DISABLE;  // 禁用 BUCK CV 的相关控制引脚
}
