/*
#include "Mcal.h"
#include "EcuM.h"
#include "BswM.h"
#include "_AD_Handler.h"

The software result FIFO for all Adc group
Adc_ValueGroupType Adc0_Group0RstFIFO[Adc0Group_0_CHANNEL_NUMBER];
Adc_ValueGroupType Adc1_Group0RstFIFO[Adc1Group_0_CHANNEL_NUMBER];
Adc_ValueGroupType Adc1_Group1RstFIFO[Adc1Group_1_CHANNEL_NUMBER];
uint16 Adc0_Group0RseultPhys[Adc0Group_0_CHANNEL_NUMBER];
uint16 Adc1_Group0RseultPhys[Adc1Group_0_CHANNEL_NUMBER];
uint16 Adc1_Group1RseultPhys[Adc1Group_1_CHANNEL_NUMBER];

uint16 g_u16AdVal[ADC_CHL_MAX];

void ADC_Configuration(void)
{
    Adc_SetupResultBuffer(AdcConf_AdcConfigSet_Adc0Group_0, Adc0_Group0RstFIFO);
    Adc_SetupResultBuffer(AdcConf_AdcConfigSet_Adc1Group_0, Adc1_Group0RstFIFO);
    Adc_SetupResultBuffer(AdcConf_AdcConfigSet_Adc1Group_1, Adc1_Group1RstFIFO);

    Adc_StartGroupConversion(AdcConf_AdcConfigSet_Adc0Group_0);
    Adc_StartGroupConversion(AdcConf_AdcConfigSet_Adc1Group_0);
    Adc_StartGroupConversion(AdcConf_AdcConfigSet_Adc1Group_1);
}



!
 * @brief ADC0_Group0 Channel Mapping Description, ADC result unit:mV
 * Adc0_Group0RseultPhys[0] = ADC_RBIN3_MCU_S
 * Adc0_Group0RseultPhys[1] = ADC_RBIN4_MCU_S
 * Adc0_Group0RseultPhys[2] = ADC_RBIN5_MCU_S
 * Adc0_Group0RseultPhys[3] = ADC_CV2_CV_MCU

void ADC0_Group0_Start(void)
{
    Adc_StartGroupConversion(AdcConf_AdcConfigSet_Adc0Group_0);
    while (Adc_GetGroupStatus(AdcConf_AdcConfigSet_Adc0Group_0) == ADC_BUSY){    }
    if(Adc_ReadGroup(AdcConf_AdcConfigSet_Adc0Group_0, Adc0_Group0RseultPhys) == E_OK)
    {
        for(uint8 i = 0; i < Adc0Group_0_CHANNEL_NUMBER; i++)
        {
            //Adc0_Group0RseultPhys[i] = (uint32)Adc0_Group0RseultPhys[i]*5000/4096;
            g_u16AdVal[i] = Adc0_Group0RseultPhys[i];
        }
    }
	for(Adc0_Buff_cnt = 0; Adc0_Buff_cnt < ADC0_BUFF_SIZE; Adc0_Buff_cnt++)
	{
		// 配置ADC通道以进行测量
		ADC_DRV_ConfigChan(Adc0_ChannelList[channel].instance, Adc0_ChannelList[channel].ch_index, Adc0_ChannelList[channel].ch_cfg);
		// 等待ADC转换完成
		ADC_DRV_WaitConvDone(Adc0_ChannelList[channel].instance);
		{   // 获取ADC测量结果并存储在缓存区中
			ADC_DRV_GetChanResult(Adc0_ChannelList[channel].instance, Adc0_ChannelList[channel].ch_index, &Adc0_TempBuff[channel][Adc0_Buff_cnt]);
		}
	}

}

!
 * @brief ADC1_Group0 Channel Mapping Description, ADC result unit:mV
 * Adc1_Group0RseultPhys[0] = ADC_NTC1_MCU_S
 * Adc1_Group0RseultPhys[1] = ADC_NTC2_MCU_S
 * Adc1_Group0RseultPhys[2] = ADC_NTC3_MCU_S
 * Adc1_Group0RseultPhys[3] = ADC_NTC4_MCU_S
 * Adc1_Group0RseultPhys[4] = ADC_NTC5_MCU_S
 * Adc1_Group0RseultPhys[5] = ADC_RBIN1_MCU_S
 * Adc1_Group0RseultPhys[6] = ADC_RBIN2_MCU_S

void ADC_GroupStart(void)
{
	ADC0_Group0_Start();
}*/

