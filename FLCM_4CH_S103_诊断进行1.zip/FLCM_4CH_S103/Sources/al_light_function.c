/*
 * al_light_function.c
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 */

#include "al_light_function.h"
#include "app_bin.h"
#include "data.h"
#include "MPQ7210_driver.h"
#include "app_cur_derating.h"
#include "LLD_config.h"
#include "app_signal_check.h"
#include "Diagnostic_fault.h"
#include "boost3910.h"
#include "light_mgr.h"
#include "osif.h"
#include "sl_softtimer.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define TEST_FILTER_TIME1  1000
uint32_t Test_Filer1 = 0;

#define TEST_FILTER_TIME  500
uint32_t Test_Filer = 0;

uint8_t INT_ALL_ARR[1] = {INT_ALL_ADDR}; // 将宏的值赋给一个变量
uint8_t INT_CFG_ARR[1] = {INT_CFG_ADDR}; // 将宏的值赋给一个变量
uint8_t FS_INT_STATUS_ARR[1] = {FS_INT_STATUS_ADDR}; // 将宏的值赋给一个变量
uint8_t FS_INT_EN_ARR[1] = {FS_INT_EN_ADDR}; // 将宏的值赋给一个变量
uint8_t FS_INT_MASK_EN_ARR[1] = {FS_INT_MASK_EN_ADDR}; // 将宏的值赋给一个变量
uint8_t FS_INT_RT_STATUS_ARR[1] = {FS_INT_RT_STATUS_ADDR}; // 将宏的值赋给一个变量
 
uint8_t FS_INT_EN_temp[3] = {0};//新建一个数组用于存放ADC控制指令的buf，用来评估是否写入成功


uint8_t buff_state = 1;
uint8_t DRL_derating_arr[4]={1,1,1,1,};
 uint8_t send_level_num1 = 0;
 uint8_t send_level_num2 = 0;
 uint8_t send_level_num3 = 0;
uint8_t LightShowMode = LIGHT_SHOW_MODE_NORMAL;
uint8_t flagHB = 0;
uint8_t flagLB = 0;
uint8_t flagDRL = 0;
uint8_t flagPL = 0;
uint8_t flagTI = 0;
uint8_t leding_flag = 0;//用于判断�??�??否�?�于点亮期间

uint8_t flagC_A_lb = 0;
uint8_t flagC_A_hb = 0;
uint8_t flagC_A_drl = 0;

volatile uint16_t ti_offtimer = 0;
uint8_t flag = 0;
uint8_t V_flag = 0;
uint8_t eprom_Bindata[BIN_COUNTNUM] = {0};
uint16_t gU16_7V_Timer = 0;

Light_Status_flag_t v_lampsta =
{
    .lampstatus_old = 0,
    .lampstatus_new = 0,
	.lamplb_sta = 0,
	.lamphb_sta = 0,
	.lampdrl_sta = 0,
	.lamppl_sta = 0,
	.lamptl_sta = 0,
};//定义一�??结构体变量用来查看新老点�??变化  0�??�??�??�?? 1�??点灯

const sMPQ7210_wCMD_STRUCT adc_anly_arr[6] =
{
	{ADC_CTRL_ADDR, BUCK1VIN_ADC_CTRL},//通过MPQ7210读取buck1的输入电压即boost的输出电�??
	{ADC_CTRL_ADDR, BUCK1VOUT_ADC_CTRL},//通过MPQ7210读取buck1的输出电压即cc1或cc3的输出电�??
	{ADC_CTRL_ADDR, BUCK2VIN_ADC_CTRL},//通过MPQ7210读取buck2的输入电压即boost的输出电�??
	{ADC_CTRL_ADDR, BUCK2VOUT_ADC_CTRL},//通过MPQ7210读取buck2的输出电压即cc2或cc4的输出电�??
	{ADC_CTRL_ADDR, BUCKVCC_ADC_CTRL},//通过MPQ7210读取vcc vin即MPQ7210的LDO供电
	{ADC_CTRL_ADDR, BUCKTEMP_ADC_CTRL},//通过MPQ7210读取MPQ7210温度TJ
};

void App_command_fun(uint8_t V_state, const uint8_t *state, mAPP_DIAG Str);
void BTNControDIS(void);
void VolControDIS(void);
void VolControEN(void);

void Test_time_init(void)
{
	Test_Filer =sl_BaseTimer_GreatSoftTimer();
	sl_SetTimerPeriod(Test_Filer, TEST_FILTER_TIME);
	Test_Filer1 =sl_BaseTimer_GreatSoftTimer();
	sl_SetTimerPeriod(Test_Filer1, TEST_FILTER_TIME1);
}

void EN_IOable(void)
{
	Open_PMOS_Input_ENABLE;
	EN_IC1_CV_ENABLE;
    EN_IC2_CV_ENABLE;
    Open_IC_CC1_EN1_ENABLE;
    Open_IC_CC2_EN2_ENABLE;
    Open_IC_CC3_EN1_ENABLE;
    Open_IC_CC4_EN2_ENABLE;
    //Open_PWM_IC2_DIM1_DISABLE;
    leding_flag = 1;
    v_lampsta.lampstatus_new = 1;
}

void nEN_IOable(void)
{
	VolControDIS();
	Open_PMOS_Input_ENABLE;
	Open_IC_CC1_EN1_DISABLE;
	Open_IC_CC2_EN2_DISABLE;
	Open_IC_CC3_EN1_DISABLE;
	Open_IC_CC4_EN2_DISABLE;
	//DisABLE_ON_LH_MCU_S;
	//ENABLE_OFF_LH_MCU_S;
	leding_flag = 0;
	v_lampsta.lampstatus_new = 0;
	v_lampsta.lamplb_sta = 0;
	v_lampsta.lamphb_sta = 0;
	v_lampsta.lamppl_sta = 0;
	v_lampsta.lampdrl_sta = 0;
	v_lampsta.lamptl_sta = 0;
}

#ifdef GAC_A09
void BTN_command_funMode(void)
{


	BTNControDIS();

	if(Input_key_arr[K_HB] == CH_HB_ON)
	{
		e_LAMP_CMD.highBeam.btnControl = LIGHT_CONTROL_EN;
	}
	if(Input_key_arr[K_LB] == CH_LB_ON)
	{
		e_LAMP_CMD.lowBeam.btnControl = LIGHT_CONTROL_EN;
	}
	if(Input_key_arr[K_PL] == CH_PL_ON)
	{
		e_LAMP_CMD.position.btnControl = LIGHT_CONTROL_EN;
	}
	if(Input_key_arr[K_DRL] == CH_DRL_ON)
	{
		e_LAMP_CMD.daytime.btnControl = LIGHT_CONTROL_EN;
	}
	if(Input_key_arr[K_TL] == CH_TL_ON)
	{
		e_LAMP_CMD.turn.btnControl = LIGHT_CONTROL_EN;
	}
}
#endif

#ifdef GAC_A09
void App_command_funMode(void)
{
	send_level_num1 = Curve_fun_process(n_NTC2);//LB
	send_level_num2 = Curve_fun_process(n_NTC1);//DRL
	send_level_num3 = Curve_fun_process(n_NTC3);//HB.

	if(Input_key_arr[K_HB] == CH_HB_OFF && Input_key_arr[K_LB] == CH_LB_OFF)
	{
		//leding_flag = 0;
		v_lampsta.lamphb_sta = 0;
		v_lampsta.lamplb_sta = 0;
		B12_EN_LED1_HB_DISABLE;//HB - OFF
		B13_EN_LED2_LB_DISABLE;//LB - OFF
		Open_IC_CC3_EN1_DISABLE;//BUCK3 LB & HB - OFF
		//flagLB = 0;
	}

	if(Input_key_arr[K_HB] == CH_HB_ON && Input_key_arr[K_LB] == CH_LB_ON)
	{
		//ENABLE_ON_LH_MCU_S;
		//DisABLE_OFF_LH_MCU_S;
		leding_flag = 1;
		v_lampsta.lampstatus_new = 1;

		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_DISABLE;//HB - ON
		B13_EN_LED2_LB_DISABLE;//LB - ON
		//照明灯BUCK�??用前。MOS需要开�??

		v_lampsta.lamplb_sta = 1;
		v_lampsta.lamphb_sta = 1;
		//照明�??,点灯SPI必须滞后于MOS
		if(flagLB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN2])//Bin2 NTC3
			{
				flagLB = 1;
				case LEVEL1:
				if(send_level_num1 == A_LEVEL) //NTC3
				{
					//send_level_num1=0;
					Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_DS_one100_CmdTable, NULL, data_length);//cc3
					Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
					flagLB = 0;
					s_state_struct.old = 0;
				}
				if(send_level_num1 == B_LEVEL) //NTC3
				{
					//send_level_num1 = 1;
					sl_cur_derating_fun(U2_MPQ7210, send_level_num1, Data_1000_one_dera_arr);
				}
				if(send_level_num1 == C_LEVEL) //NTC3
				{
					//send_level_num1 =2;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
				}
				if(send_level_num1 == D_LEVEL) //NTC3
				{
					//send_level_num1 =5;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
				}
				break;
				case LEVEL2:
				if(send_level_num1 == A_LEVEL) //NTC3
				{
					//send_level_num1=0;
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one958_CmdTable,NULL,data_length);
					flagLB = 0;
					s_state_struct.old=0;
				}
				if(send_level_num1 == B_LEVEL) //NTC3
				{
					//send_level_num1 = 1;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
				}
				if(send_level_num1 == C_LEVEL) //NTC3
				{
					send_level_num1 =2;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
				}
				if(send_level_num1 == D_LEVEL) //NTC3
				{
					//send_level_num1 =5;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
				}
				break;
				case LEVEL3:
				if(send_level_num1 == A_LEVEL) //NTC3
				{
					//send_level_num1=0;
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one919_CmdTable,NULL,data_length);
					flagLB = 0;
					s_state_struct.old=0;
				}
				if(send_level_num1 == B_LEVEL) //NTC3
				{
					//send_level_num1 = 1;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
				}
				if(send_level_num1 == C_LEVEL) //NTC3
				{
					//send_level_num1 =2;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
				}
				if(send_level_num1 == D_LEVEL) //NTC3
				{
					//send_level_num1 =5;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
				}
				break;
				case LEVEL4:
				if(send_level_num1 == A_LEVEL) //NTC3
				{
					//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
					//send_level_num1=0;
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one878_CmdTable,NULL,data_length);
					flagLB = 0;
					s_state_struct.old=0;
				}
				if(send_level_num1 == B_LEVEL) //NTC3
				{
					//send_level_num1 = 1;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
				}
				if(send_level_num1 == C_LEVEL) //NTC2
				{
					//send_level_num1 =2;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
				}
				if(send_level_num1 == D_LEVEL) //NTC2
				{
					//send_level_num1 =5;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
				}
				break;
				case LEVEL5:
				if(send_level_num1 == A_LEVEL) //NTC3
				{
					//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
					//send_level_num1=0;
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
					flagLB = 0;
					s_state_struct.old=0;
				}
				if(send_level_num1 == B_LEVEL) //NTC3
				{
					//send_level_num1 = 1;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
				}
				if(send_level_num1 == C_LEVEL) //NTC3
				{
					//send_level_num1 =2;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
				}
				if(send_level_num1 == D_LEVEL) //NTC3
				{
					//send_level_num1 =5;
					sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
				}
				break;
				default:
				/*if(mApp_diag.U8_BIN[n_BIN2].U8_short_VOL ==true) //BIN short
				{
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
				}
				if(mApp_diag.U8_BIN[n_BIN2].U8_open_VOL ==true) //BIN open
				{
					Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
				}*/
				break;
			}
		}
	}
	if((Input_key_arr[K_HB] == CH_HB_ON) && (Input_key_arr[K_LB] == CH_LB_OFF))////�?? �?? HB
	{
		leding_flag = 1;
		v_lampsta.lamplb_sta = 0;
		v_lampsta.lamphb_sta = 1;
		v_lampsta.lampstatus_new = 1;
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_ENABLE;//HB - ON
		//B13_EN_LED2_LB_DISABLE;
		//照明�??,点灯SPI必须滞后于MOS
		if(flagHB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN3])//Bin3
			{
				flagHB = 1;
				case LEVEL1:
					if(send_level_num3 == A_LEVEL) //NTC3
					{
						send_level_num3 = 0;
						Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_DS_one100_CmdTable, NULL, data_length);
						Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
						flagHB = 0;
						s_state_struct.old = 0;
					}
					if(send_level_num3 == B_LEVEL) //NTC3
					{
						send_level_num3 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					if(send_level_num3 == C_LEVEL) //NTC3
					{
						send_level_num3 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					if(send_level_num3 == D_LEVEL) //NTC3
					{
						send_level_num3 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					break;
				case LEVEL2:
					if(send_level_num3 == A_LEVEL) //NTC3
					{
						send_level_num3=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one958_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num3 == B_LEVEL) //NTC3
					{
						send_level_num3 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_958_one_dera_arr);
					}
					if(send_level_num3 == C_LEVEL) //NTC2
					{
						send_level_num3 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_958_one_dera_arr);
					}
					if(send_level_num3 == D_LEVEL) //NTC3
					{
						send_level_num3 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_958_one_dera_arr);
					}
					break;
				case LEVEL3:
					if(send_level_num3 == A_LEVEL) //NTC3
					{
						send_level_num3=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one919_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num3 == B_LEVEL) //NTC3
					{
						send_level_num3 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_919_one_dera_arr);
					}
					if(send_level_num3 == C_LEVEL) //NTC3
					{
						send_level_num3 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_919_one_dera_arr);
					}
					if(send_level_num3 == D_LEVEL) //NTC3
					{
						send_level_num3 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_919_one_dera_arr);
					}
					break;
				case LEVEL4:
					if(send_level_num3 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						send_level_num3=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one878_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num3 == B_LEVEL) //NTC3
					{
						send_level_num3 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_878_one_dera_arr);
					}
					if(send_level_num3 == C_LEVEL) //NTC3
					{
						send_level_num3 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_878_one_dera_arr);
					}
					if(send_level_num3 == D_LEVEL) //NTC3
					{
						send_level_num3 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_878_one_dera_arr);
					}
					break;
				case LEVEL5:
					if(send_level_num3 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						send_level_num3 = 0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old = 0;
					}
					if(send_level_num3 == B_LEVEL) //NTC3
					{
						send_level_num3 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					if(send_level_num3 == C_LEVEL) //NTC3
					{
						send_level_num3 = 2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					if(send_level_num3 == D_LEVEL) //NTC3
					{
						send_level_num3 = 5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num3,Data_1000_one_dera_arr);
					}
					break;
				default:
					/*if(mApp_diag.U8_BIN[n_BIN2].U8_short_VOL == true) //BIN short
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_two80_CmdTable,NULL,data_length);
						Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
					}
					if(mApp_diag.U8_BIN[n_BIN2].U8_open_VOL == true) //BIN open
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
						Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
					}*/
					break;
			}
		}
	}
	if((Input_key_arr[K_HB] == CH_HB_OFF) && (Input_key_arr[K_LB] == CH_LB_ON))//点灯  LB
	{
		leding_flag = 1;
		v_lampsta.lampstatus_new = 1;
		v_lampsta.lamphb_sta = 0;
		v_lampsta.lamplb_sta = 1;
		//ENABLE_ON_LH_MCU_S;
		//DisABLE_OFF_LH_MCU_S;
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB
		B13_EN_LED2_LB_ENABLE;//LB - ON
		if(flagLB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN2])//Bin2 NTC2
			{
				flagLB = 1;
				case LEVEL1:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					break;
				case LEVEL2:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one958_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_958_one_dera_arr);
					}
					break;
				case LEVEL3:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one919_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_919_one_dera_arr);
					}
					break;
				case LEVEL4:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one878_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_878_one_dera_arr);
					}
					break;
				case LEVEL5:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					break;
				default:
					/*if(mApp_diag.U8_BIN[n_BIN2].U8_short_VOL ==true) //BIN short  /////璁板綍鏁呴�?�鎶ラ敊
					{
						//Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					}
					if(mApp_diag.U8_BIN[n_BIN2].U8_open_VOL ==true) //BIN open  /////璁板綍鏁呴�?�鎶ラ敊
					{
						//Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					}*/
					break;
			}

		}

	}
    /*
	if(Input_key_arr[K_HB] == CH_HB_OFF)
	{
		flagHB = 0;//清空入口，允许重新进入降额函�??
		//照明�??，关灯MOS需要优先于SPI
		B12_EN_LED1_HB_DISABLE;//HB - Off
	}

	if(Input_key_arr[K_LB] == CH_LB_OFF)
	{
		flagLB = 0;
		B13_EN_LED2_LB_DISABLE;//LB - OFF
	}
	*/
	if((Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) && (Input_key_arr[K_TL] == CH_TL_OFF))
	{
		//leding_flag = 0;
		//信号�??�??�??如果不是全灭，关�??顺序应�?�是先改SPI再改mos
		v_lampsta.lampdrl_sta = 0;
		v_lampsta.lamppl_sta = 0;
		v_lampsta.lamptl_sta = 0;
		Open_IC_CC2_EN2_DISABLE;//BUCK2 DRL/PL/TL - off
		A11_EN_LED5_TL_DISABLE;
		A12_EN_LED6_DRL_PL_DISABLE;
		flagDRL = 0;
	}
	if((Input_key_arr[K_TL] == CH_TL_OFF) && (ti_offtimer ==0) && ((Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_DRL] == CH_DRL_ON)) )
	{
		leding_flag = 1;
		v_lampsta.lamptl_sta = 0;
		v_lampsta.lampstatus_new = 1;
		if(Input_key_arr[K_DRL] == CH_DRL_OFF && Input_key_arr[K_PL] == CH_PL_OFF )
		{
			v_lampsta.lampdrl_sta = 0;
			v_lampsta.lamppl_sta = 0;
			A12_EN_LED6_DRL_PL_DISABLE;
			flagDRL = 0;
		}
		else if(Input_key_arr[K_PL] == CH_PL_ON && Input_key_arr[K_DRL] == CH_DRL_OFF)//点灯 PL
		{
			v_lampsta.lampdrl_sta = 0;
			v_lampsta.lamppl_sta = 1;
			Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
			Sl_MPQ7210_send(U1_MPQ7210, WRITE_BIT, MPQ7210_DS_two10_CmdTable, NULL, data_length);
			Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
			//信号灯SPI必须先于MOS
			A12_EN_LED6_DRL_PL_ENABLE;
			A11_EN_LED5_TL_DISABLE;
		}
		else//点灯DRL
		{
			v_lampsta.lampdrl_sta = 1;
			v_lampsta.lamppl_sta = 0;
			Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
			if(flagDRL == 0)
			{
				A12_EN_LED6_DRL_PL_ENABLE;
				A11_EN_LED5_TL_DISABLE;
				switch(mApp_diag.gU16_BIN_Value_normal[n_BIN1])//Bin1 NTC2
				{
					flagDRL = 1;
					
					case LEVEL1:
						if(send_level_num2 == A_LEVEL) //NTC2
						{
							//send_level_num1=0;
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two958_CmdTable,NULL,data_length);
							Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
							flagDRL = 0;
							s_state_struct.old=0;
						}
						if(send_level_num2 == B_LEVEL) //NTC2
						{
							//send_level_num1 = 1;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						if(send_level_num2 == C_LEVEL) //NTC2
						{
							//send_level_num1 =2;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						if(send_level_num2 == D_LEVEL) //NTC2
						{
							//send_level_num1 =5;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						break;
					case LEVEL2:
						if(send_level_num2 == A_LEVEL) //NTC2
						{
							//send_level_num1=0;
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two90_CmdTable,NULL,data_length);
							flagDRL = 0;
							s_state_struct.old=0;
						}
						if(send_level_num2 == B_LEVEL) //NTC2
						{
							//send_level_num1 = 1;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_900_two_dera_arr);
						}
						if(send_level_num2 == C_LEVEL) //NTC2
						{
							//send_level_num1 =2;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_900_two_dera_arr);
						}
						if(send_level_num2 == D_LEVEL) //NTC2
						{
							//send_level_num1 =5;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_900_two_dera_arr);
						}
						break;
					case LEVEL3:
						if(send_level_num2 == A_LEVEL) //NTC2
						{
							//send_level_num1=0;
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two855_CmdTable,NULL,data_length);
							flagDRL = 0;
							s_state_struct.old=0;
						}
						if(send_level_num2 == B_LEVEL) //NTC2
						{
							//send_level_num1 = 1;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_855_two_dera_arr);
						}
						if(send_level_num2 == C_LEVEL) //NTC2
						{
							//send_level_num1 =2;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_855_two_dera_arr);
						}
						if(send_level_num2 == D_LEVEL) //NTC2
						{
							//send_level_num1 =5;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_855_two_dera_arr);
						}
						break;
					case LEVEL4:
						if(send_level_num2 == A_LEVEL) //NTC2
						{
							//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
							//send_level_num1=0;
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two805_CmdTable,NULL,data_length);
							flagDRL = 0;
							s_state_struct.old=0;
						}
						if(send_level_num2 == B_LEVEL) //NTC2
						{
							//send_level_num1 = 1;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_805_two_dera_arr);
						}
						if(send_level_num2 == C_LEVEL) //NTC2
						{
							//send_level_num1 =2;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_805_two_dera_arr);
						}
						if(send_level_num2 == D_LEVEL) //NTC2
						{
							//send_level_num1 =5;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_805_two_dera_arr);
						}
						break;
					case LEVEL5:
						if(send_level_num2 == A_LEVEL) //NTC2
						{
							//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
							//send_level_num1=0;
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two958_CmdTable,NULL,data_length);
							flagDRL = 0;
							s_state_struct.old=0;
						}
						if(send_level_num2 == B_LEVEL) //NTC2
						{
							//send_level_num1 = 1;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						if(send_level_num2 == C_LEVEL) //NTC2
						{
							//send_level_num1 =2;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						if(send_level_num2 == D_LEVEL) //NTC2
						{
							//send_level_num1 =5;
							sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_950_two_dera_arr);
						}
						break;
					default:
						
						break;
				}
				//信号灯SPI必须优先于MOS
				
		  }
		}
	}
	if(Input_key_arr[K_TL] == CH_TL_OFF)
	{
		A11_EN_LED5_TL_DISABLE;
		v_lampsta.lamptl_sta = 0;
		//leding_flag = 0;
	}
	if(Input_key_arr[K_TL] == CH_TL_ON)//点灯TL
	{
		Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
		leding_flag = 1;
		v_lampsta.lamptl_sta = 1;
		v_lampsta.lampstatus_new = 1;
	
		A12_EN_LED6_DRL_PL_DISABLE;
		A11_EN_LED5_TL_ENABLE;
		Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_two100_CmdTable,NULL,data_length);
		Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);
		
	}
	if((Input_key_arr[K_LB] == CH_LB_OFF) && (Input_key_arr[K_HB] == CH_HB_OFF) && (Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) && (Input_key_arr[K_TL] == CH_TL_OFF))
	{
		leding_flag = 0;
		v_lampsta.lampstatus_new = 0;
		v_lampsta.lampdrl_sta = 0;
		v_lampsta.lamphb_sta = 0;
		v_lampsta.lamplb_sta = 0;
		v_lampsta.lamppl_sta = 0;
		v_lampsta.lamptl_sta = 0;
	}
}
#elseif
void App_command_funMode(void)
{
	send_level_num1 = Curve_fun_process(n_NTC1);//HB LB
	send_level_num2 = Curve_fun_process(n_NTC2);
	send_level_num3 = Curve_fun_process(n_NTC3);

	if(Input_key_arr[K_HB] == CH_HB_OFF && Input_key_arr[K_LB] == CH_LB_OFF )
	{
		B12_EN_LED1_HB_DISABLE;//HB - OFF
		B13_EN_LED2_LB_DISABLE;//LB - OFF
		//照明�??，关灯MOS需要优先于SPI
		Open_IC_CC3_EN1_DISABLE;//BUCK3 LB & HB - OFF
	}
	if(Input_key_arr[K_HB] == CH_HB_ON && Input_key_arr[K_LB] == CH_LB_ON)
	{
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_ENABLE;//HB - ON
		B13_EN_LED2_LB_ENABLE;//LB - ON
		//照明�??,点灯SPI必须滞后于MOS
	}
	if(Input_key_arr[K_HB] == CH_HB_OFF)
	{
		flagHB = 0;//清空入口，允许重新进入降额函�??
		//照明�??，关灯MOS需要优先于SPI
		B12_EN_LED1_HB_DISABLE;//HB - Off
	}
	if(Input_key_arr[K_HB] == CH_HB_ON)////�?? �?? HB
	{
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_ENABLE;//HB - ON
		//照明�??,点灯SPI必须滞后于MOS
		if(flagHB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN3])//Bin3
			{
				flagHB = 1;
				case LEVEL1:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						send_level_num1 = 0;
						Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_DS_two100_CmdTable, NULL, data_length);
						flagHB = 0;
						s_state_struct.old = 0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_two_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_two_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_two_dera_arr);
					}
					break;
				case LEVEL2:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_two90_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_two_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC2
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_two_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_two_dera_arr);
					}
					break;
				case LEVEL3:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_two80_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_two_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_two_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_two_dera_arr);
					}
					break;
				case LEVEL4:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_two70_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_two_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_two_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_two_dera_arr);
					}
					break;
				case LEVEL5:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						send_level_num1 = 0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_two60_CmdTable,NULL,data_length);
						flagHB = 0;
						s_state_struct.old = 0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_two_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 = 2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_two_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						send_level_num1 = 5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_two_dera_arr);
					}
					break;
				default:
					if(mApp_diag.U8_BIN[n_BIN2].U8_short_VOL == true) //BIN short
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_two80_CmdTable,NULL,data_length);
					}
					if(mApp_diag.U8_BIN[n_BIN2].U8_open_VOL == true) //BIN open
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_two80_CmdTable,NULL,data_length);
					}
					break;
			}
		}
	}
	if(Input_key_arr[K_LB] == CH_LB_OFF)
	{
		flagLB = 0;
		B13_EN_LED2_LB_DISABLE;//LB - OFF
	}
	if(Input_key_arr[K_LB] == CH_LB_ON)//点灯  LB
	{
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB
		B13_EN_LED2_LB_ENABLE;//LB - ON
		if(flagLB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN2])//Bin2 NTC3
			{
				flagLB = 1;
				case LEVEL1:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one100_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_1000_one_dera_arr);
					}
					break;
				case LEVEL2:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one90_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_900_one_dera_arr);
					}
					break;
				case LEVEL3:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one80_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_800_one_dera_arr);
					}
					break;
				case LEVEL4:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one70_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_700_one_dera_arr);
					}
					break;
				case LEVEL5:
					if(send_level_num1 == A_LEVEL) //NTC3
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_AS_one60_CmdTable,NULL,data_length);
						flagLB = 0;
						s_state_struct.old=0;
					}
					if(send_level_num1 == B_LEVEL) //NTC3
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_one_dera_arr);
					}
					if(send_level_num1 == C_LEVEL) //NTC3
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_one_dera_arr);
					}
					if(send_level_num1 == D_LEVEL) //NTC3
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U2_MPQ7210,send_level_num1,Data_600_one_dera_arr);
					}
					break;
				default:
					if(mApp_diag.U8_BIN[n_BIN2].U8_short_VOL ==true) //BIN short  /////璁板綍鏁呴�?�鎶ラ敊
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					}
					if(mApp_diag.U8_BIN[n_BIN2].U8_open_VOL ==true) //BIN open  /////璁板綍鏁呴�?�鎶ラ敊
					{
						Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_DS_one80_CmdTable,NULL,data_length);
					}
					break;
			}

		}
	}
	if(Input_key_arr[K_DRL] == CH_DRL_OFF && Input_key_arr[K_PL] == CH_PL_OFF && Input_key_arr[K_TL] == CH_TL_OFF)
	{
		//信号�??�??�??如果不是全灭，关�??顺序应�?�是先改SPI再改mos
		Open_IC_CC2_EN2_DISABLE;//BUCK2 DRL/PL/TL - off
		A11_EN_LED5_TL_DISABLE;
		A12_EN_LED6_DRL_PL_DISABLE;
		flagDRL = 0;
	}
	if(Input_key_arr[K_DRL] == CH_DRL_OFF && Input_key_arr[K_PL] == CH_PL_OFF )
	{
		A12_EN_LED6_DRL_PL_DISABLE;
		flagDRL = 0;
	}
	else if(Input_key_arr[K_PL] == CH_PL_ON && Input_key_arr[K_DRL] == CH_DRL_OFF)//点灯 PL
	{
		Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
		Sl_MPQ7210_send(U1_MPQ7210, WRITE_BIT, MPQ7210_DS_two10_CmdTable, NULL,data_length);
		//信号灯SPI必须先于MOS
		A12_EN_LED6_DRL_PL_ENABLE;
		A11_EN_LED5_TL_DISABLE;
	}
	else//点灯DRL
	{
		Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
		if(flagDRL == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN1])//Bin1 NTC2
			{
				flagDRL = 1;
				case LEVEL1:
					if(send_level_num2 == A_LEVEL) //NTC2
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_two200_CmdTable,NULL,data_length);
						flagDRL = 0;
						s_state_struct.old=0;
					}
					if(send_level_num2 == B_LEVEL) //NTC2
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_200_two_dera_arr);
					}
					if(send_level_num2 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_200_two_dera_arr);
					}
					if(send_level_num2 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_200_two_dera_arr);
					}
					break;
				case LEVEL2:
					if(send_level_num2 == A_LEVEL) //NTC2
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two180_CmdTable,NULL,data_length);
						flagDRL = 0;
						s_state_struct.old=0;
					}
					if(send_level_num2 == B_LEVEL) //NTC2
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_180_two_dera_arr);
					}
					if(send_level_num2 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_180_two_dera_arr);
					}
					if(send_level_num2 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_180_two_dera_arr);
					}
					break;
				case LEVEL3:
					if(send_level_num2 == A_LEVEL) //NTC2
					{
						//send_level_num1=0;
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two160_CmdTable,NULL,data_length);
						flagDRL = 0;
						s_state_struct.old=0;
					}
					if(send_level_num2 == B_LEVEL) //NTC2
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_160_two_dera_arr);
					}
					if(send_level_num2 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_160_two_dera_arr);
					}
					if(send_level_num2 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_160_two_dera_arr);
					}
					break;
				case LEVEL4:
					if(send_level_num2 == A_LEVEL) //NTC2
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two140_CmdTable,NULL,data_length);
						flagDRL = 0;
						s_state_struct.old=0;
					}
					if(send_level_num2 == B_LEVEL) //NTC2
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_140_two_dera_arr);
					}
					if(send_level_num2 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_140_two_dera_arr);
					}
					if(send_level_num2 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_140_two_dera_arr);
					}
					break;
				case LEVEL5:
					if(send_level_num2 == A_LEVEL) //NTC2
					{
						//LLD_PixelDarsing(U2_MPQ7210,49,Data_1000_two_dera_arr);
						//send_level_num1=0;
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two120_CmdTable,NULL,data_length);
						flagDRL = 0;
						s_state_struct.old=0;
					}
					if(send_level_num2 == B_LEVEL) //NTC2
					{
						//send_level_num1 = 1;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_120_two_dera_arr);
					}
					if(send_level_num2 == C_LEVEL) //NTC2
					{
						//send_level_num1 =2;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_120_two_dera_arr);
					}
					if(send_level_num2 == D_LEVEL) //NTC2
					{
						//send_level_num1 =5;
						sl_cur_derating_fun(U1_MPQ7210,send_level_num1,Data_120_two_dera_arr);
					}
					break;
				default:
					if(mApp_diag.U8_BIN[n_BIN1].U8_short_VOL ==true) //BIN short  /////璁板綍鏁呴�?�鎶ラ敊
					{
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_two160_CmdTable,NULL,data_length);
					}
					if(mApp_diag.U8_BIN[n_BIN1].U8_open_VOL ==true) //BIN open  /////璁板綍鏁呴�?�鎶ラ敊
					{
						Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_two160_CmdTable,NULL,data_length);
					}
					break;
			}
			//信号灯SPI必须优先于MOS
			A12_EN_LED6_DRL_PL_ENABLE;
			A11_EN_LED5_TL_DISABLE;
		}
	}
	if(Input_key_arr[K_TL] == CH_TL_OFF)
	{
		A11_EN_LED5_TL_DISABLE;
	}
	if(Input_key_arr[K_TL] == CH_TL_ON)//点灯TL
	{
		Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
		switch(mApp_diag.gU16_BIN_Value_normal[n_BIN3])//Bin3 NTC1
		{
			case LEVEL1:
				Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_one200_CmdTable,NULL,data_length);
				break;
			case LEVEL2:
				Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_one180_CmdTable,NULL,data_length);
				break;
			case LEVEL3:
				Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_one160_CmdTable,NULL,data_length);
				break;
			case LEVEL4:
				Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_one140_CmdTable,NULL,data_length);
				break;
			case LEVEL5:
				Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_one120_CmdTable,NULL,data_length);
				break;
			default:
				if(mApp_diag.U8_BIN[n_BIN3].U8_short_VOL ==true) //BIN short  /////璁板綍鏁呴�?�鎶ラ敊
				{
					Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_one180_CmdTable,NULL,data_length);
				}
				if(mApp_diag.U8_BIN[n_BIN3].U8_open_VOL ==true) //BIN open  /////璁板綍鏁呴�?�鎶ラ敊
				{
					Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_one180_CmdTable,NULL,data_length);
				}
				break;
		}
		A12_EN_LED6_DRL_PL_DISABLE;
		A11_EN_LED5_TL_ENABLE;
	}
}
#endif

void LightFunctionProcess(void)
{
	al_Bin_value_funtion();
	switch(Get_mode_KL30Sts())
	{
		case KL30_7_0todonw:
			nEN_IOable();
			break;
		case KL30_7_0to18_5V:
			CheckLampConSta();
			break;
		case KL30_18_5V_up:
			nEN_IOable();
			break;
		default:
			break;
	}
}
static uint8_t num1_derating_fun( uint8_t LEVEL_num, sMPQ7210_wCMD_STRUCT *data_arr,const uint16_t data_derating_arr[][8])
{
	if((send_level_num1_A == 0)  || (s_state_num1.old == s_state_num1.new))
	{
		s_state_num1.new = LEVEL_num;
		if(s_state_num1.old == s_state_num1.new )
		{
			sl_cur_fun(U2_MPQ7210,s_state_num1.new,data_derating_arr);
		}
	} 
	
	if((send_level_num1_A==1) || (s_state_num1.old != s_state_num1.new))
	{
		if(s_state_num1.old != s_state_num1.new) 
		{
			if((s_state_num1.new == A_LEVEL) )
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num1.new,data_derating_arr,1);
				//Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,data_arr,NULL,data_length);
				//Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
				flagDRL = 0;
				//s_state_struct.old=0;

				//s_state_num1.old =s_state_num1.new;
			}
			if((s_state_num1.new == B_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num1.new,data_derating_arr,1);
			}
			if((s_state_num1.new == C_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num1.new,data_derating_arr,1);
			}
			if((s_state_num1.new == D_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num1.new,data_derating_arr,1);
			}
		}
	}
	return 0;
}
static uint8_t num2_derating_fun( uint8_t LEVEL_num, sMPQ7210_wCMD_STRUCT *data_arr,const uint16_t data_derating_arr[][8])
{
	if((send_level_num2_A == 0)  || (s_state_num2.old == s_state_num2.new))
	{
		s_state_num2.new = LEVEL_num;
		if(s_state_num2.old == s_state_num2.new )
		{
			sl_cur_fun(U1_MPQ7210,s_state_num2.new,data_derating_arr);
		}
	} 

	if((send_level_num2_A==1) || (s_state_num2.old != s_state_num2.new))
	{
		if(s_state_num2.old != s_state_num2.new) 
		{
				if((s_state_num2.new == A_LEVEL) )
			{
				sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,data_derating_arr,2);
				//Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,data_arr,NULL,data_length);
				//Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
				flagDRL = 0;
				//s_state_struct.old=0;

				//s_state_num2.old =s_state_num2.new;
			}
			if((s_state_num2.new == B_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,data_derating_arr,2);
			}
			if((s_state_num2.new == C_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,data_derating_arr,2);
			}
			if((s_state_num2.new == D_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,data_derating_arr,2);
			}
		}
	}
	return 0;
}
static uint8_t num3_derating_fun( uint8_t LEVEL_num, sMPQ7210_wCMD_STRUCT *data_arr,const uint16_t data_derating_arr[][8])
{
	if((send_level_num3_A == 0)  || (s_state_num3.old == s_state_num3.new))
	{
		s_state_num3.new = LEVEL_num;
		if(s_state_num3.old == s_state_num3.new )
		{
			sl_cur_fun(U2_MPQ7210,s_state_num3.new,data_derating_arr);
		}
	} 
	
	if((send_level_num3_A==1) || (s_state_num3.old != s_state_num3.new))
	{
		if(s_state_num3.old != s_state_num3.new) 
		{
			if((s_state_num3.new == A_LEVEL) )
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num3.new,data_derating_arr,3);
				//Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,data_arr,NULL,data_length);
				//Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
				//flagDRL = 0;
				//s_state_struct.old=0;

				//s_state_num3.old =s_state_num3.new;
			}
			if((s_state_num3.new == B_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num3.new,data_derating_arr,3);
			}
			if((s_state_num3.new == C_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num3.new,data_derating_arr,3);
			}
			if((s_state_num3.new == D_LEVEL) ) //NTC2
			{
				sl_cur_derating_fun(U2_MPQ7210,s_state_num3.new,data_derating_arr,3);
			}
		}
	}
	return 0;
}
void CheckLampConSta(void) 
{
	send_level_num1 = Curve_fun_process(n_NTC2);//LB
    send_level_num2 = Curve_fun_process(n_NTC1);//DRL
	send_level_num3 = Curve_fun_process(n_NTC3);//HB


	if(Input_key_arr[K_HB] == CH_HB_OFF && Input_key_arr[K_LB] == CH_LB_OFF)
	{
		Open_IC_CC3_EN1_DISABLE;//BUCK3 LB & HB - OFF
		B12_EN_LED1_HB_DISABLE;//HB - OFF
		B13_EN_LED2_LB_DISABLE;//LB - OFF
	}

	if(Input_key_arr[K_HB] == CH_HB_ON && Input_key_arr[K_LB] == CH_LB_ON)
	{
		//ENABLE_ON_LH_MCU_S;
		//DisABLE_OFF_LH_MCU_S;
		leding_flag = 1;
		v_lampsta.lampstatus_new = 1;

		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_DISABLE;//HB - ON
		B13_EN_LED2_LB_DISABLE;//LB - ON
		//if(flagLB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN2])//Bin2 NTC3
			{
				//flagLB = 1;
			case LEVEL1:
			num1_derating_fun(send_level_num1, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);
							
			break;
			case LEVEL2:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one958_CmdTable,Data_958_one_dera_arr);
							
			break;
			case LEVEL3:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one919_CmdTable,Data_919_one_dera_arr);
			
			break;
			case LEVEL4:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one878_CmdTable,Data_878_one_dera_arr);
			
			break;
			case LEVEL5:
			num1_derating_fun(send_level_num1, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);

			break;

			default:

			break;
			}
		}
	}
	if((Input_key_arr[K_HB] == CH_HB_ON) && (Input_key_arr[K_LB] == CH_LB_OFF))////�?? �?? HB
	{
		leding_flag = 1;
		v_lampsta.lamplb_sta = 0;
		v_lampsta.lamphb_sta = 1;
		v_lampsta.lampstatus_new = 1;
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB - ON
		B12_EN_LED1_HB_ENABLE;//HB - ON
		//B13_EN_LED2_LB_DISABLE;
		//照明�??,点灯SPI必须滞后于MOS
		//if(flagHB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN3])//Bin3
			{
				//flagHB = 1;
				case LEVEL1:
				num3_derating_fun(send_level_num3, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);
					
				break;
				case LEVEL2:
				num3_derating_fun(send_level_num3, MPQ7210_AS_one958_CmdTable,Data_958_one_dera_arr);
					
				break;
				case LEVEL3:
				num3_derating_fun(send_level_num3, MPQ7210_AS_one919_CmdTable,Data_919_one_dera_arr);
				
					break;
				case LEVEL4:
				num3_derating_fun(send_level_num3, MPQ7210_AS_one878_CmdTable,Data_878_one_dera_arr);
				
					break;
				case LEVEL5:
				num3_derating_fun(send_level_num3, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);
					break;
				default:
					break;
			}
		}
	}
	if((Input_key_arr[K_HB] == CH_HB_OFF) && (Input_key_arr[K_LB] == CH_LB_ON))//点灯  LB
	{
		leding_flag = 1;
		v_lampsta.lampstatus_new = 1;
		v_lampsta.lamphb_sta = 0;
		v_lampsta.lamplb_sta = 1;
		//ENABLE_ON_LH_MCU_S;
		//DisABLE_OFF_LH_MCU_S;
		Open_IC_CC3_EN1_ENABLE;//BUCK3 LB & HB
		B13_EN_LED2_LB_ENABLE;//LB - ON
		//if(flagLB == 0)
		{
			switch(mApp_diag.gU16_BIN_Value_normal[n_BIN2])//Bin2 NTC2
			{
				//flagLB = 1;
			case LEVEL1:
			num1_derating_fun(send_level_num1, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);
							
			break;
			case LEVEL2:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one958_CmdTable,Data_958_one_dera_arr);
							
			break;
			case LEVEL3:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one919_CmdTable,Data_919_one_dera_arr);
			
			break;
			case LEVEL4:
			num1_derating_fun(send_level_num1, MPQ7210_AS_one878_CmdTable,Data_878_one_dera_arr);
			
			break;
			case LEVEL5:
			num1_derating_fun(send_level_num1, MPQ7210_DS_one100_CmdTable,Data_1000_one_dera_arr);
			
			break;
				default:
					break;
			}

		}

	}
	if((Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) && (Input_key_arr[K_TL] == CH_TL_OFF))
	{
		v_lampsta.lampdrl_sta = 0;
		v_lampsta.lamppl_sta = 0;
		v_lampsta.lamptl_sta = 0;
		Open_IC_CC2_EN2_DISABLE;//BUCK2 DRL/PL/TL - off
		A11_EN_LED5_TL_DISABLE;
		A12_EN_LED6_DRL_PL_DISABLE;
		flagDRL = 0;
	}
	if((Input_key_arr[K_TL] == CH_TL_OFF) && (ti_offtimer ==0) && ((Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_DRL] == CH_DRL_ON)) )
	{
		leding_flag = 1;
		v_lampsta.lamptl_sta = 0;
		v_lampsta.lampstatus_new = 1;
		if(Input_key_arr[K_DRL] == CH_DRL_OFF && Input_key_arr[K_PL] == CH_PL_OFF )
		{
			v_lampsta.lampdrl_sta = 0;
			v_lampsta.lamppl_sta = 0;
			A12_EN_LED6_DRL_PL_DISABLE;
			flagDRL = 0;
		}
		else if(Input_key_arr[K_PL] == CH_PL_ON && Input_key_arr[K_DRL] == CH_DRL_OFF)//点灯 PL
		{
			v_lampsta.lampdrl_sta = 0;
			v_lampsta.lamppl_sta = 1;
			Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
			Sl_MPQ7210_send(U1_MPQ7210, WRITE_BIT, MPQ7210_DS_two10_CmdTable, NULL, data_length);
			Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
			//信号灯SPI必须先于MOS
			A12_EN_LED6_DRL_PL_ENABLE;
			A11_EN_LED5_TL_DISABLE;
		}
		else//点灯DRL
		{
			Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
			if(flagDRL == 0)
			{
				A11_EN_LED5_TL_DISABLE;
				A12_EN_LED6_DRL_PL_ENABLE;
				switch(mApp_diag.gU16_BIN_Value_normal[n_BIN1])//Bin1 NTC2
				{
					flagDRL = 1;
					
					case LEVEL1:
						num2_derating_fun(send_level_num2, MPQ7210_AS_two958_CmdTable,Data_950_two_dera_arr);
						/* if(send_level_num2_A == 0  || s_state_num2.old == s_state_num2.new)
						{
							s_state_num2.new = send_level_num2;
							if(s_state_num2.old == s_state_num2.new )
							{
								sl_cur_fun(U1_MPQ7210,s_state_num2.new,Data_950_two_dera_arr);
							}
							
						} 
						if((s_state_num2.new == A_LEVEL) )
						{
							Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_AS_two958_CmdTable,NULL,data_length);
							//Sl_MPQ7210_send(U2_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);//常�?�配�??
							flagDRL = 0;
							s_state_struct.old=0;

							s_state_num2.old =s_state_num2.new;
						}
						if(send_level_num2_A==1 || s_state_num2.old != s_state_num2.new)
						{
							if(s_state_num2.old != s_state_num2.new) 
							{
								if((s_state_num2.new == B_LEVEL) ) //NTC2
								{
									sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,Data_950_two_dera_arr);
								}
								if((s_state_num2.new == C_LEVEL) ) //NTC2
								{
									sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,Data_950_two_dera_arr);
								}
								if((s_state_num2.new == D_LEVEL) ) //NTC2
								{
									sl_cur_derating_fun(U1_MPQ7210,s_state_num2.new,Data_950_two_dera_arr);
								}
							}
						} */ 
						break;
					case LEVEL2:
						num2_derating_fun(send_level_num2,MPQ7210_AS_two90_CmdTable,Data_900_two_dera_arr);
						
						break;
					case LEVEL3:
						num2_derating_fun(send_level_num2,MPQ7210_AS_two855_CmdTable,Data_855_two_dera_arr);
						
						break;
					case LEVEL4:
					    num2_derating_fun(send_level_num2,MPQ7210_AS_two805_CmdTable,Data_805_two_dera_arr);
						
						break;
					case LEVEL5:
				    	num2_derating_fun(send_level_num2,MPQ7210_AS_two500_CmdTable,Data_500_two_dera_arr);
						
						break;
					default:
						
						break;
				}
				//信号灯SPI必须优先于MOS
				
		  }
		}
	}
	if(Input_key_arr[K_TL] == CH_TL_OFF)
	{
		A11_EN_LED5_TL_DISABLE;
		v_lampsta.lamptl_sta = 0;
		//leding_flag = 0;
	}
	if(Input_key_arr[K_TL] == CH_TL_ON)//点灯TL
	{
	
		Open_IC_CC2_EN2_ENABLE;//BUCK2 DRL/PL/TL - ON
		leding_flag = 1;
		v_lampsta.lamptl_sta = 1;
		v_lampsta.lampstatus_new = 1;
		A12_EN_LED6_DRL_PL_DISABLE;
		A11_EN_LED5_TL_ENABLE;
		Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DS_two100_CmdTable,NULL,data_length);
		Sl_MPQ7210_send(U1_MPQ7210, WRITE_BIT, MPQ7210_NORMAL_CmdTable, NULL, normal_length);
		//Sl_MPQ7210_16bit_receive(U1_MPQ7210, FS_INT_EN_ARR, FS_INT_EN_temp);//SPI读取<ADC控制寄存器>内容

	}
	if((Input_key_arr[K_LB] == CH_LB_OFF) && (Input_key_arr[K_HB] == CH_HB_OFF) && (Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) && (Input_key_arr[K_TL] == CH_TL_OFF))
	{
		leding_flag = 0;
		v_lampsta.lampstatus_new = 0;
		v_lampsta.lampdrl_sta = 0;
		v_lampsta.lamphb_sta = 0;
		v_lampsta.lamplb_sta = 0;
		v_lampsta.lamppl_sta = 0;
		v_lampsta.lamptl_sta = 0;
	}
	
}



void BTNControDIS(void)
{
	e_LAMP_CMD.highBeam.btnControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.lowBeam.btnControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.daytime.btnControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.position.btnControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.turn.btnControl = LIGHT_CONTROL_DIS;
}

void VolControDIS(void)
{
	e_LAMP_CMD.highBeam.voltageControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.lowBeam.voltageControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.daytime.voltageControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.position.voltageControl = LIGHT_CONTROL_DIS;
	e_LAMP_CMD.turn.voltageControl = LIGHT_CONTROL_DIS;
}

void VolControEN(void)
{
	e_LAMP_CMD.highBeam.voltageControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.lowBeam.voltageControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.daytime.voltageControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.position.voltageControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.turn.voltageControl = LIGHT_CONTROL_EN;
}
