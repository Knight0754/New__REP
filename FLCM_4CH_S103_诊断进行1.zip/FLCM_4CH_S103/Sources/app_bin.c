/*
 * app_bin.c
 *
 *  Created on: 2023年11月9日
 *      Author: gz06488
 */

#include "app_bin.h"
#include "al_light_function.h"
#include "app_signal_check.h"
#include "light_mgr.h"

uint8_t cunt_ad=0;
uint8_t cnt_adc = 0; // ADC的采集圈数
uint8_t Adc_Scan_Setp = 0; // ADC采集的圈数标志
uint8_t gU8_BIN_Sample_Flag = 0; // 定义初始采集bin值的flag
static sstTimerIndex_t ADC_Filer = 0; // 初始化ADC时钟索引
uint8_t Adc0_Buff_cnt = 0; // 计数变量，用于LLD_ADC0_MeasureProcess，作为采集次数标志
uint16_t KL30_buff = 0; // 定义一个变量用于存放KL30的电压值

// 建一个二维数组作为ADC缓存区，有10个ADC检查口，各有10次采集数据
uint16_t Adc0_TempBuff[ADC0_CHANNEL_NUMBER][ADC0_BUFF_SIZE];
uint16_t Adc0_TempBuff_ten[ADC0_CHANNEL_NUMBER]={0};
// 定义一个数组存放ADC的用户配置信息
const ADC_SCAN_INFO Adc0_ChannelList[ADC0_CHANNEL_NUMBER] =
{
    { INST_ADCONV1, 0, &ADC_ECU_NTC_OUT},
    { INST_ADCONV1, 0, &ADC_CV2_OUT},
    { INST_ADCONV1, 0, &ADC_RBIN3_OUT},
    { INST_ADCONV1, 0, &ADC_RBIN2_OUT},
    { INST_ADCONV1, 0, &ADC_KL30_OUT},
    { INST_ADCONV1, 0, &ADC_NTC1_OUT},
    { INST_ADCONV1, 0, &ADC_RBIN1_OUT},
    { INST_ADCONV1, 0, &ADC_NTC3_OUT},
    { INST_ADCONV1, 0, &ADC_NTC2_OUT},
    { INST_ADCONV1, 0, &ADC_CV1_OUT},
};
// 定义一个数组用来存放ADC的转换结果
static float Adc0_Channel_Result[ADC0_CHANNEL_NUMBER] = {0.0f};
// 定义一个数组用于存放ADC值
uint16_t Adc0_Result[ADC0_CHANNEL_NUMBER] = {0};
// 定义一个数组用于降噪的等级
uint8_t gu8_curve_max[CURVE_LEVELmode] = {0, 0, 0};
// 定义一个结构体存放bin值和温度值
mCONVERT_INFO mconvert_sta;
// 定义一个结构体存放NTC的等级
mCURVE_STA curve_sta;
// 定义一个结构体存放一些ADC的信息
mADC_STA  adc_sta;
// 定义一个结构体存放ADC的NTC结果
mADC_INFO  adc_info;
// 定义一个结构体存放NTC结果
mCOMBINE_NTCBIN  ntcbin_sta;
mADC_buff mADC_BF;

void BINControEN(void);

/**
 * @brief 初始化ADC
 *
 * 使用memset函数初始化结构体，均初始化为0。
 * 获取单一通道滤波后的ADC值。
 * 初始化ADC周期调度，周期为10ms。
 */
void sl_adc_init(void)
{
    // 使用memset函数初始化结构体，均初始化为0

	memset(&mADC_BF, 0, sizeof(mADC_buff));
    memset(&adc_info, 0, sizeof(adc_info));
    memset(&curve_sta, 0, sizeof(curve_sta));
    memset(&adc_sta, 0, sizeof(adc_sta));
    memset(&adc_info, 0, sizeof(adc_info));
    memset(&ntcbin_sta, 0, sizeof(ntcbin_sta));
    memset(&meeprom, 0, sizeof(mEEPROM_STA));

}


//冒泡排序
/**
 * @brief 冒泡排序
 *
 * 使用冒泡排序算法对给定的数组进行排序。
 *
 * @param a 数组指针
 * @param n 数组元素个数
 */
#ifdef ADC_SEC
void BubbleSort( uint16_t *a, uint8_t n)
{
    // 临时变量，用于交换元素
    uint16_t temp;
    // 外层循环变量，控制排序的轮数
    unsigned char i,j;

    // 外层循环，共进行 n-1 轮排序
    for(i =0 ; i< n-1; ++i)
    {
        // 内层循环，每轮排序中，将最大的元素交换到最右边
        for(j = 0; j < n-i-1; ++j)
        {
            // 如果当前元素比后一个元素大
            if(a[j] > a[j+1])
            {
                // 交换当前元素和后一个元素的位置
                temp = a[j];
                a[j]  = a[j+1];
                a[j+1] = temp;
            }
        }
    }
}
#else
uint16_t BubbleSort( uint16_t *a, uint8_t n)
{
	uint16_t sum=0;
	uint16_t max;
	uint16_t min;
	uint16_t aver_val=0;
	max=a[0];
	min=a[0];
	for(uint8_t i=0;i<n;i++)
	{
		if(max < a[i])
		{
			max=a[i];
		}
		if(min > a[i])
		{
			min =a[i];
		}
		sum +=a[i];
	}
	aver_val = (sum -max -min) / (n-2);
	return aver_val;
}
#endif
/**
 * @brief ADC0 测量处理函数
 *
 * 对指定的 ADC 通道进行测量，并将测量结果存储在缓存区中。
 *
 * @param channel ADC 通道号
 *
 * @return 返回值为 0
 */
#ifdef ADC_SEC
uint8_t LLD_ADC0_MeasureProcess(uint8_t channel)
{
	for(Adc0_Buff_cnt = 0; Adc0_Buff_cnt < ADC0_BUFF_SIZE; Adc0_Buff_cnt++)
	{
		// 配置ADC通道以进行测量
		ADC_DRV_ConfigChan(Adc0_ChannelList[channel].instance, Adc0_ChannelList[channel].ch_index, Adc0_ChannelList[channel].ch_cfg);
		// 等待ADC转换完成
		ADC_DRV_WaitConvDone(Adc0_ChannelList[channel].instance);
		{   // 获取ADC测量结果并存储在缓存区中
			ADC_DRV_GetChanResult(Adc0_ChannelList[channel].instance, Adc0_ChannelList[channel].ch_index, &Adc0_TempBuff[channel][Adc0_Buff_cnt]);
		}
	}
	// 如果Adc0_Buff_cnt大于等于10，则清空标志并执行排序操作
	if(Adc0_Buff_cnt >= ADC0_BUFF_SIZE)
	{
		Adc0_Buff_cnt = 0;
		BubbleSort(Adc0_TempBuff[channel], ADC0_BUFF_SIZE);
	}
	return 0;
}
#else
uint8_t LLD_ADC0_MeasureProcess(void)
{
	for(uint8_t adcch = 0; adcch < (ADC0_CHANNEL_NUMBER); adcch++)
	{
		ADC_DRV_ConfigChan(Adc0_ChannelList[adcch].instance, Adc0_ChannelList[adcch].ch_index, Adc0_ChannelList[adcch].ch_cfg);
		// 等待ADC转换完成
		ADC_DRV_WaitConvDone(Adc0_ChannelList[adcch].instance);
		{   // 获取ADC测量结果并存储在缓存区中
			ADC_DRV_GetChanResult(Adc0_ChannelList[adcch].instance, Adc0_ChannelList[adcch].ch_index, &Adc0_TempBuff_ten[adcch]);
		}
	}
	return 1;
}

#endif
/**
 * @brief 获取ADC信息
 *
 * 该函数用于获取各种ADC结果，包括KL30、ECU NTC、CV1、CV2、BIN1、BIN2、BIN3、NTC1、NTC2和NTC3的ADC结果。
 */
void m_adc_info(void)
{
	// 获取KL30的ADC结果
	adc_info.GetKL30_Result = BubbleSort(mADC_BF.ADC_KL30, ADC0_BUFF_SIZE);
	// 获取ECU NTC的ADC结果
	adc_info.GetECUNTC_Result = BubbleSort(mADC_BF.ADC_ECU_NTC, ADC0_BUFF_SIZE);
	// 获取CV1的ADC结果
	adc_info.GetCV_Result[n_CV1] = BubbleSort(mADC_BF.ADC_CV1_CV, ADC0_BUFF_SIZE);
	// 获取CV2的ADC结果
	adc_info.GetCV_Result[n_CV2] = BubbleSort(mADC_BF.ADC_CV2_CV, ADC0_BUFF_SIZE);
	// 获取BIN1的ADC结果
	adc_info.GetBIN_Result[n_BIN1] = BubbleSort(mADC_BF.ADC_RBIN1, ADC0_BUFF_SIZE);
	// 获取BIN2的ADC结果
	adc_info.GetBIN_Result[n_BIN2] = BubbleSort(mADC_BF.ADC_RBIN2, ADC0_BUFF_SIZE);
	// 获取BIN3的ADC结果
	adc_info.GetBIN_Result[n_BIN3] = BubbleSort(mADC_BF.ADC_RBIN3, ADC0_BUFF_SIZE);
	// 获取NTC1的ADC结果
	adc_info.GetNTC_Result[n_NTC1] = BubbleSort(mADC_BF.ADC_NTC1, ADC0_BUFF_SIZE);
	// 获取NTC2的ADC结果
	adc_info.GetNTC_Result[n_NTC2] = BubbleSort(mADC_BF.ADC_NTC2, ADC0_BUFF_SIZE);
	// 获取NTC3的ADC结果
	adc_info.GetNTC_Result[n_NTC3] = BubbleSort(mADC_BF.ADC_NTC3, ADC0_BUFF_SIZE);
}
/**
 * @brief 获取ADC0通道的值
 *
 * 根据指定的通道号，执行ADC测量过程，并返回测量结果。
 *
 * @param channel 通道号
 *
 * @return 如果通道号有效，则返回true；否则返回false
 */
#ifdef ADC_SEC
uint8_t SL_ADC0_GetChannelVal(uint8_t channel)
{
	uint16_t Temp_ADC0 = 0;

	// 执行ADC测量过程并进行冒泡排序
	LLD_ADC0_MeasureProcess(channel);

	if(channel < ADC0_CHANNEL_NUMBER)
	{
		// 去掉最大值和最小值
		for(uint8_t i = 1; i < (ADC0_BUFF_SIZE - 1); i++)
		{
			// 将ADC测量结果累加
			Temp_ADC0 += Adc0_TempBuff[channel][i];
		}

		// 计算平均值 Temp_ADC0的/8
		Adc0_Result[channel] = Temp_ADC0 >> 3;

		// 计算通道结果，将结果映射到ADC参考电压范围
		Adc0_Channel_Result[channel] = (float)( (float)(Temp_ADC0 >> 3) / adcMax) * (ADC_VREFH - ADC_VREFL);

		return true;
	}
	else
	{
		return false;
	}
}
#else
void _app_SignalFilt10msTask(uint8_t ad_cunt_num)
{
	for(uint8_t i=0;i < ADC0_BUFF_SIZE;i++)
	{
		for(uint8_t j=ad_cunt_num-1; j < ad_cunt_num; j++)
		{
			Adc0_TempBuff[i][j] =Adc0_TempBuff_ten[i];
		}
	}
	if(ad_cunt_num == ADC0_BUFF_SIZE)
	{
		for(uint8_t k = 0; k < ADC0_BUFF_SIZE; k++)
		{
			mADC_BF.ADC_ECU_NTC[k]=Adc0_TempBuff[0][k];
			mADC_BF.ADC_CV2_CV[k] =Adc0_TempBuff[1][k];
			mADC_BF.ADC_RBIN3[k]  =Adc0_TempBuff[2][k];
			mADC_BF.ADC_RBIN2[k]  =Adc0_TempBuff[3][k];
			mADC_BF.ADC_KL30[k]   =Adc0_TempBuff[4][k];
			mADC_BF.ADC_NTC1[k]	  =Adc0_TempBuff[5][k];
			mADC_BF.ADC_RBIN1[k]  =Adc0_TempBuff[6][k];
			mADC_BF.ADC_NTC3[k]   =Adc0_TempBuff[7][k];
			mADC_BF.ADC_NTC2[k]   =Adc0_TempBuff[8][k];
			mADC_BF.ADC_CV1_CV[k] =Adc0_TempBuff[9][k];
	    }
		m_adc_info();
	}

}

void ADManage_Tesk()
{

	if(1 == LLD_ADC0_MeasureProcess())
	{
		cunt_ad++;
		_app_SignalFilt10msTask(cunt_ad);
		if(cunt_ad == ADC0_BUFF_SIZE)
		{
			cunt_ad = 0;
			get_BIN_Val();
		}
	}
}
#endif



/**
 * @brief 获取等级值
 *
 * 根据给定的二进制计数值，获取相应的等级值。
 *
 * @param BIN_count 二进制计数值
 */
static void get_level_value(uint8_t BIN_count) 
{
	// gU16_BinValue_level --> 0:level1  1:level2  2:level3  3:level4  4:level5  5:短路   6:开路
    uint16_t value = adc_sta.gU16_BinValue[BIN_count];
    adc_sta.gU16_Bin_Dig[BIN_count] = 0; // 默认为正常情况
    adc_sta.gU16_BinValue_Leve5_eeprom[BIN_count] = 0; // 默认非LEVEL5

    if (value <= BINshort) 
	{
        adc_sta.gU16_Bin_Dig[BIN_count] = 1; // 短路
    } 
	else if (value >= BINOpen) 
	{
        adc_sta.gU16_Bin_Dig[BIN_count] = 2; // 开路
    } 
	else if (value <= BINLeve1_H) 
	{
        adc_sta.gU16_BinValue_eeprom[BIN_count] = LEVEL1;
    } 
	else if (value <= BINLeve2_H) 
	{
        adc_sta.gU16_BinValue_eeprom[BIN_count] = LEVEL2;
    } 
	else if (value <= BINLeve3_H) 
	{
        adc_sta.gU16_BinValue_eeprom[BIN_count] = LEVEL3;
    } 
	else if (value <= BINLeve4_H) 
	{
        adc_sta.gU16_BinValue_eeprom[BIN_count] = LEVEL4;
    } 
	else 
	{
        adc_sta.gU16_BinValue_Leve5_eeprom[BIN_count] = LEVEL5;
    }
}

/**
 * @brief 获取二进制状态
 *
 * 遍历每个BIN通道，将BIN测量结果存储到adc_sta结构体中，并根据BIN值转化成对应档位。
 *
 * @return 返回一个8位无符号整数，表示函数执行成功
 */
uint8_t GetBinSts(void)
{
	uint8_t  BIN_count = 0;
	// 初始采样标志位为0，表示需要进行采样
	if(gU8_BIN_Sample_Flag == 0)
	{
		// 遍历每个BIN通道
		for(BIN_count = 0; BIN_count < BIN_COUNTNUM; BIN_count++)
		{
			// 将BIN测量结果存储到adc_sta结构体中
			adc_sta.gU16_BinValue[BIN_count] = adc_info.GetBIN_Result[BIN_count];
			get_level_value(BIN_count);
		}
		// 设置采样标志位为1，表示已经完成采样，不再进行采样
		gU8_BIN_Sample_Flag = 1;//禁用BIN值再采集
	}
	// 返回0，表示函数执行成功
	return 0;
}

/**
 * @brief 清除ackl30
 *
 * 将adc_sta结构体中的KL30_Level数组的所有元素设置为0，以清除ackl30状态。
 */
void clear_ackl30(void)
{
	// 定义一个8位无符号整型变量i，并初始化为0
	uint8_t  i = 0;
	// 循环从0开始，直到KL30LEVEL的值
	for(i = 0; i < KL30LEVEL; i++)
	{
	    // 将adc_sta结构体中的KL30_Level数组的第i个元素设置为0
	    adc_sta.KL30_Level[i] = 0;
	}
}

//获取电压降额曲线
uint8_t Get_LEVEL_KL30Sts(void)
{
	adc_sta.gU16_KL30Value = adc_info.GetKL30_Result;
	if((adc_sta.gU16_KL30Value >= 0) && (adc_sta.gU16_KL30Value < (VOL_7_0V_UP )))
	{
		curve_sta.Vin_level = 100;
		return 0;
	}
	if((adc_sta.gU16_KL30Value >= (VOL_7_0V_UP +15)) && (adc_sta.gU16_KL30Value < (VOL_18_5V_DOWN-15)))
	{
		if((adc_sta.gU16_KL30Value >= (VOL_7_0V_UP +10)) && (adc_sta.gU16_KL30Value < (VOL_8_0V_AD -10)))
		{
			curve_sta.Vin_level = D_LEVEL;
		}
		if((adc_sta.gU16_KL30Value >= (VOL_8_0V_AD +15)) && (adc_sta.gU16_KL30Value < (VOL_9_0V_AD -10)))
		{
			curve_sta.Vin_level = C_LEVEL;
		}
		if((adc_sta.gU16_KL30Value >= (VOL_9_0V_AD +15)) && (adc_sta.gU16_KL30Value < (VOL_10_0V_AD -10)))
		{
			curve_sta.Vin_level = B_LEVEL;
		}
		if((adc_sta.gU16_KL30Value >= (VOL_10_0V_AD  +15)) && (adc_sta.gU16_KL30Value < (VOL_18_5V_DOWN - 15)))
		{
			curve_sta.Vin_level=A_LEVEL;  //A 100%  B 90%  C 80%  D 50%
		}
		return 0;
	}
	if((adc_sta.gU16_KL30Value >= VOL_18_5V_DOWN) && (adc_sta.gU16_KL30Value < 4096))
	{
		curve_sta.Vin_level = 200;
		return 0;
	}
	return 0;
}


/**
 * @brief 获取 KL30 状态
 *
 * 从 adc_info 中获取 KL30 的 ADC 结果，并根据结果返回 KL30 的状态。
 *
 * @return uint8_t KL30 的状态，0 表示未知状态
 */
uint8_t Get_mode_KL30Sts(void)
{
	adc_sta.gU16_KL30Value = adc_info.GetKL30_Result;
	if((adc_sta.gU16_KL30Value >= 0) && (adc_sta.gU16_KL30Value < (VOL_7_0V_UP )))
	{
		return KL30_7_0todonw;
	}
	if((adc_sta.gU16_KL30Value >= (VOL_7_0V_UP +15)) && (adc_sta.gU16_KL30Value < (VOL_18_5V_DOWN - 15)))
	{
		return KL30_7_0to18_5V;
	}
	if((adc_sta.gU16_KL30Value >= VOL_18_5V_DOWN+20) && (adc_sta.gU16_KL30Value < 4096))
	{
		return KL30_18_5V_up;
	}
	return 0;
}

//获取NTC降额曲线
uint8_t Get_mode_InternalNTC_Sts(void)
{
	adc_sta.gU16_NTC_inner_Value = (uint16_t) adc_info.GetECUNTC_Result;
	if((adc_sta.gU16_NTC_inner_Value < NTC_30_AD) && (adc_sta.gU16_KL30Value >= NTC100_AD +230))
	{
		curve_sta.InternalNTC[0].NTC_uvp = 0;
		curve_sta.InternalNTC[0].NTC_ovp = 0;
		curve_sta.InternalNTC_level = A_LEVEL;//A 100%  B 90%  C 80%  D 50%
	}
	if((adc_sta.gU16_NTC_inner_Value < (NTC100_AD + 50)) && (adc_sta.gU16_NTC_inner_Value >= NTC110_AD))
	{
		curve_sta.InternalNTC[0].NTC_uvp = 0;
		curve_sta.InternalNTC[0].NTC_ovp = 0;
		curve_sta.InternalNTC_level = C_LEVEL;//A 100%  B 90%  C 80%  D 50%
	}
	if((adc_sta.gU16_NTC_inner_Value < (NTC110_AD + 50)) && (adc_sta.gU16_NTC_inner_Value >= NTC150_AD))
	{ 
		curve_sta.InternalNTC[0].NTC_uvp = 0;
		curve_sta.InternalNTC[0].NTC_ovp = 0;
		curve_sta.InternalNTC_level = D_LEVEL; //A 100%  B 90%  C 80%  D 50%
	}
    if((adc_sta.gU16_NTC_inner_Value < NTC150_AD+50)) // 过压
    {
         curve_sta.InternalNTC[0].NTC_ovp = 1;
         curve_sta.InternalNTC[0].NTC_uvp = 0;
         curve_sta.InternalNTC_level = C_LEVEL; // 过压时，状态为80%电量
    }
     if((adc_sta.gU16_NTC_inner_Value > (NTC_30_AD + 50)) ) // 开路
    {
         curve_sta.InternalNTC[0].NTC_uvp=1;
         curve_sta.InternalNTC[0].NTC_ovp=0;
         curve_sta.InternalNTC_level = C_LEVEL; // 开路时，状态为80%电量
    }
    return curve_sta.InternalNTC_level;

}


/**
 * @brief 获取外部 NTC 状态
 *
 * 根据给定的 NTC 编号，获取外部 NTC 的状态，包括过压、欠压和电量级别。
 *
 * @param NTC_num NTC 编号
 *
 * @return 返回电量级别
 */
uint8_t Get_ExternalNTC_Sts(uint8_t NTC_num)
{
		adc_sta.NTC_Level[NTC_num] = adc_info.GetNTC_Result[NTC_num];
	    if((adc_sta.NTC_Level[NTC_num] < NTC_30_AD) && (adc_sta.NTC_Level[NTC_num] >= NTC110_AD+400))
		{
	    	curve_sta.ExternalNTC[NTC_num].NTC_ovp=0;
	    	curve_sta.ExternalNTC[NTC_num].NTC_uvp=0;
	    	curve_sta.ExternalNTC_level[NTC_num] = A_LEVEL; //A 100%  B 90%  C 80%  D 50%
		}
	    if((adc_sta.NTC_Level[NTC_num] < (NTC110_AD+15)) && (adc_sta.NTC_Level[NTC_num] >= NTC120_AD))
		{
	    	curve_sta.ExternalNTC[NTC_num].NTC_ovp=0;
	    	curve_sta.ExternalNTC[NTC_num].NTC_uvp=0;
	    	curve_sta.ExternalNTC_level[NTC_num] = B_LEVEL;//A 100%  B 90%  C 80%  D 50%
		}
	    if((adc_sta.NTC_Level[NTC_num] < (NTC120_AD+15)) && (adc_sta.NTC_Level[NTC_num] >= NTC125_AD))
		{
	    	curve_sta.ExternalNTC[NTC_num].NTC_ovp=0;
	    	curve_sta.ExternalNTC[NTC_num].NTC_uvp=0;
			curve_sta.ExternalNTC_level[NTC_num]=C_LEVEL;//A 100%  B 90%  C 80%  D 50%
		}
	    if((adc_sta.NTC_Level[NTC_num] < (NTC125_AD+20)) && (adc_sta.NTC_Level[NTC_num] >= NTC150_AD))
		{
			curve_sta.ExternalNTC[NTC_num].NTC_ovp=0;
			curve_sta.ExternalNTC[NTC_num].NTC_uvp=0;
			curve_sta.ExternalNTC_level[NTC_num]=D_LEVEL;//A 100%  B 90%  C 80%  D 50%
		}
		if((adc_sta.NTC_Level[NTC_num] < NTC150_AD+15)) // 过压
		{
			curve_sta.ExternalNTC[NTC_num].NTC_ovp=1;
			curve_sta.ExternalNTC[NTC_num].NTC_uvp=0; // 过压时，状态为80%电量
			curve_sta.ExternalNTC_level[NTC_num]=C_LEVEL; // A 100%  B 90%  C 80%  D 50%
		}
		if((adc_sta.NTC_Level[NTC_num] > (NTC_30_AD+15))) // 开路
		{
			curve_sta.ExternalNTC[NTC_num].NTC_uvp=1;
			curve_sta.ExternalNTC[NTC_num].NTC_ovp=0; // 开路时，状态为80%电量
			curve_sta.ExternalNTC_level[NTC_num]=C_LEVEL; // A 100%  B 90%  C 80%  D 50%
		}
		return curve_sta.ExternalNTC_level[NTC_num];
}


/**
 * @brief 处理曲线函数
 *
 * 根据传入的 NTC 编号，获取 KL30 电压等级状态、内部 NTC 等级状态和外部 NTC 等级状态，
 * 并计算得到最大等级值。
 *
 * @param NTC_num NTC 编号
 *
 * @return 最大等级值
 */
uint8_t Curve_fun_process(uint8_t NTC_num)
{
	// 获取KL30电压等级状态
	Get_LEVEL_KL30Sts();
	// 获取内部NTC的等级状态
	Get_mode_InternalNTC_Sts();
	// 获取外部NTC的等级状态
	Get_ExternalNTC_Sts(NTC_num);
	gu8_curve_max[NTC_num] = curve_sta.Vin_level;
	if(gu8_curve_max[NTC_num] <= curve_sta.InternalNTC_level)
	{
		gu8_curve_max[NTC_num] = curve_sta.InternalNTC_level;
	}
	if(gu8_curve_max[NTC_num] <= curve_sta.ExternalNTC_level[NTC_num])
	{
		gu8_curve_max[NTC_num] = curve_sta.ExternalNTC_level[NTC_num];
	}
	return gu8_curve_max[NTC_num];
}

/**
 * @brief 获取KL30电压状态
 *
 * 根据KL30电压值，获取其对应的电压状态。
 *
 * @return uint8_t 电压状态码
 */
uint8_t Get_KL30Sts(void)
{
    adc_sta.gU16_KL30Value = adc_info.GetKL30_Result;
    // 如果KL30电压值在0到(VOL_7_0V_UP-20)之间
    if((adc_sta.gU16_KL30Value >= 0) && (adc_sta.gU16_KL30Value < (VOL_7_0V_UP-20)))
    {
        clear_ackl30(); // 清除KL30等级信息
        return KL30_7_0todonw; // 返回7V以下的状态码
    }
    // 如果KL30电压值在(VOL_7_0V_UP+20)到(VOL_10_0V_DOWN-30)之间
    if((adc_sta.gU16_KL30Value >= (VOL_7_0V_UP+20)) && (adc_sta.gU16_KL30Value < VOL_10_0V_DOWN-30))
    {
        clear_ackl30(); // 清除KL30等级信息
        adc_sta.KL30_Level[0] = 1;
        KL30_buff = adc_sta.gU16_KL30Value; // 更新KL30缓冲值
        return KL30_7_0to10_0V; // 返回7V到10V的状态码
    }
    // 如果KL30电压值在(VOL_10_0V_DOWN+20)到(VOL_18_5V_DOWN-35)之间
    if((adc_sta.gU16_KL30Value >= VOL_10_0V_DOWN+20) && (adc_sta.gU16_KL30Value < VOL_18_5V_DOWN-35))
    {
        clear_ackl30(); // 清除KL30等级信息
        adc_sta.KL30_Level[1] = 1;
        return KL30_10_0to18_5V; // 返回10V到18.5V的状态码
    }
    // 如果KL30电压值在VOL_18_5V_DOWN以上
    if((adc_sta.gU16_KL30Value >= VOL_18_5V_DOWN) && (adc_sta.gU16_KL30Value < 4096))
    {
        clear_ackl30(); // 清除KL30等级信息
        adc_sta.KL30_Level[2] = 1;
        return KL30_18_5V_up; // 返回18.5V以上的状态码
    }

    return 0; // 默认返回0
}

// 根据ADC测量结果来判断NTC（热敏电阻）的状态
/**
 * @brief 获取 NTC 状态
 *
 * 根据 NTC 的测量结果，判断其温度范围，并将结果存储到 adc_sta 结构体中。
 *
 * @param void
 *
 * @return void
 */
void Get_NTCSts(void) // NTC_Value_Level-->0:小于130°C  1:大于130°C
{
    uint8_t i = 0;
    // 将ECU NTC测量结果存储到adc_sta结构体中
    adc_sta.gU16_NTC_inner_Value = (uint16_t)adc_info.GetECUNTC_Result;
    for(i = 0; i < NTC_NUM; i++)
    {
        adc_sta.NTC_Level[i] = adc_info.GetNTC_Result[i];
        if((adc_sta.NTC_Level[i] >= 0) && (adc_sta.NTC_Level[i] < NTC130_UP))
        {
            adc_sta.NTC_Value_Level[i][0] = 0; // 无效状态
            adc_sta.NTC_Value_Level[i][1] = 1; // 1:大于130°C
        }
        if((adc_sta.NTC_Level[i] >= NTC130_DOWN))
        {
            adc_sta.NTC_Value_Level[i][0] = 1; // 0:小于130°C
            adc_sta.NTC_Value_Level[i][1] = 0; // 无效状态
        }
    }
}

/**
 * @brief BIN值函数
 *
 * 根据EEPROM中的诊断读取BIN值，更新正常BIN值，并根据BIN值的状态设置对应的功能。
 */
void al_Bin_value_funtion(void)
{
    uint8_t i = 0;
	//BINControEN();
    for(i = 0; i < BIN_COUNTNUM; i++)
    {
        // 如果EEPROM中的诊断读取BIN值为0，则将EEPROM读取的BIN值更新为正常的BIN值
        if(meeprom.gU16_EEPROM_Diag_read_Bin[i] == 0)
        {
            mApp_diag.gU16_BIN_Value_normal[i] = meeprom.gU16_EEPROM_read_Bin[i];
        }

        // 如果EEPROM中的读取BIN值为1, 2, 3, 4，则正常的BIN值，将其进行更新。
        if((meeprom.gU16_EEPROM_read_Bin[i] == 1) || (meeprom.gU16_EEPROM_read_Bin[i] == 2) || (meeprom.gU16_EEPROM_read_Bin[i] == 3) || (meeprom.gU16_EEPROM_read_Bin[i] == 4))
        {
            mApp_diag.gU16_BIN_Value_normal[i] = meeprom.gU16_EEPROM_read_Bin[i];
        }
        // 如果ADC测量的BIN等级为LEVEL5，则将当前的BIN值设置为LEVEL5
        if(adc_sta.gU16_BinValue_Leve5_eeprom[i] == LEVEL5) 
		{
			mApp_diag.gU16_BIN_Value_normal[i] = LEVEL5;
		}
            
        // 如果EEPROM中的诊断读取BIN值为1，则设置相应BIN为短路状态
        if(meeprom.gU16_EEPROM_Diag_read_Bin[i] == 1)
        {
            mApp_diag.U8_BIN[i].U8_short_VOL = true;
            
            // 如果BIN值为1到4，则更新为正常BIN值，否则设置为0
            if((meeprom.gU16_EEPROM_read_Bin[i] == 1) || (meeprom.gU16_EEPROM_read_Bin[i] == 2) || (meeprom.gU16_EEPROM_read_Bin[i] == 3) || (meeprom.gU16_EEPROM_read_Bin[i] == 4))
            {
                mApp_diag.gU16_BIN_Value_normal[i] = meeprom.gU16_EEPROM_read_Bin[i];
            }
            else 
            {
                mApp_diag.gU16_BIN_Value_normal[i] = 0;

                // 根据具体按键状态禁用对应的功能
                if((Input_key_arr[0] == CH_HB_ON) && (i == 2)) // 远光灯
                {
                	e_LAMP_CMD.highBeam.binControl = LIGHT_CONTROL_DIS;
                }

                if((Input_key_arr[1] == CH_LB_ON) && (i == 1))  // 近光灯
                {
                	e_LAMP_CMD.lowBeam.binControl = LIGHT_CONTROL_DIS;
                }

                if(((Input_key_arr[2] == CH_DRL_ON) || (Input_key_arr[3] == CH_PL_ON) ) && (i == 0)) // 日间行车灯和位置灯
                {
                	e_LAMP_CMD.position.binControl = LIGHT_CONTROL_DIS;
                	e_LAMP_CMD.daytime.binControl = LIGHT_CONTROL_DIS;
                }
            }
        }

        // 如果EEPROM中的诊断读取BIN值为2，则设置相应BIN为开路状态
        if((meeprom.gU16_EEPROM_Diag_read_Bin[i] == 2))
        {
            mApp_diag.U8_BIN[i].U8_open_VOL = true;

            // 如果BIN值为1到4，则更新为正常BIN值，否则设置为0
            if((meeprom.gU16_EEPROM_read_Bin[i] == 1) || (meeprom.gU16_EEPROM_read_Bin[i] == 2) || (meeprom.gU16_EEPROM_read_Bin[i] == 3) || (meeprom.gU16_EEPROM_read_Bin[i] == 4))
            {
                mApp_diag.gU16_BIN_Value_normal[i] = meeprom.gU16_EEPROM_read_Bin[i];
            }
            else 
            {
                mApp_diag.gU16_BIN_Value_normal[i]=0;

                // 根据具体按键状态禁用对应的功能
                if((Input_key_arr[0] == CH_HB_ON) && (i == 2)) // 远光灯
                {
                	e_LAMP_CMD.highBeam.binControl = LIGHT_CONTROL_DIS;
                }

                if((Input_key_arr[1] == CH_LB_ON) && (i == 1))  // 近光灯
                {
                	e_LAMP_CMD.lowBeam.binControl = LIGHT_CONTROL_DIS;
                }

                if(((Input_key_arr[2] == CH_DRL_ON) || (Input_key_arr[3] == CH_PL_ON) ) && (i == 0)) // 日间行车灯和位置灯
                {
                	e_LAMP_CMD.daytime.binControl = LIGHT_CONTROL_DIS;
                	e_LAMP_CMD.position.binControl = LIGHT_CONTROL_DIS;
                }
            }
        }
    }
}


void BINControEN(void)
{
	e_LAMP_CMD.highBeam.binControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.lowBeam.binControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.daytime.binControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.position.binControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.turn.binControl = LIGHT_CONTROL_EN;
}

/**
 * @brief NTC值处理函数
 *
 * 根据ECU和BIN1、BIN2、BIN3的NTC值，在指定范围内设置内部温度和NTC_Value_normal数组的值。
 */
void al_NTC_value_funtion(void)
{
	// 判断ECU NTC值是否在范围内
	if((adc_info.GetECUNTC_Result >= 0) && (adc_info.GetECUNTC_Result < NTC130_UP))
	{
		// 如果在范围内，则设置内部温度为NTC_set130_up
		mApp_diag.U8_Internal_temperature = NTC_set130_up;
	}
	else
	{
		// 如果不在范围内，则设置内部温度为NTC_set130_down
		mApp_diag.U8_Internal_temperature = NTC_set130_down;
	}

    // 判断BIN1 NTC值是否在范围内
    if((adc_info.GetBIN_Result[n_BIN1] >= 0) && (adc_info.GetBIN_Result[n_BIN1] < NTC130_UP))
	{
		// 如果在范围内，则设置NTC_Value_normal[n_BIN1]为NTC_set130_up
		mApp_diag.gU16_NTC_Value_normal[n_BIN1] = NTC_set130_up;
	}
	else
	{
		// 如果不在范围内，则设置NTC_Value_normal[n_BIN1]为NTC_set130_down
		mApp_diag.gU16_NTC_Value_normal[n_BIN1] = NTC_set130_down;
	}

    // 判断BIN2 NTC值是否在范围内
    if((adc_info.GetBIN_Result[n_BIN2] >= 0) && (adc_info.GetBIN_Result[n_BIN2] < NTC130_UP))
	{
		// 如果在范围内，则设置NTC_Value_normal[n_BIN2]为NTC_set130_up
		mApp_diag.gU16_NTC_Value_normal[n_BIN2] = NTC_set130_up;
	}
	else
	{
		// 如果不在范围内，则设置NTC_Value_normal[n_BIN2]为NTC_set130_down
		mApp_diag.gU16_NTC_Value_normal[n_BIN2] = NTC_set130_down;
	}

    // 判断BIN3 NTC值是否在范围内
    if((adc_info.GetBIN_Result[n_BIN3] >= 0) && (adc_info.GetBIN_Result[n_BIN3] < NTC130_UP))
	{
		// 如果在范围内，则设置NTC_Value_normal[n_BIN3]为NTC_set130_up
		mApp_diag.gU16_NTC_Value_normal[n_BIN3] = NTC_set130_up;
	}
	else
	{
		// 如果不在范围内，则设置NTC_Value_normal[n_BIN3]为NTC_set130_down
		mApp_diag.gU16_NTC_Value_normal[n_BIN3] =NTC_set130_down;
	}
}

/**
 * @brief ADC检测任务
 *
 * ADC检测任务，负责ADC的扫描和数据处理。
 */
void sl_adc_Tesk(void)//ADC检测任务
{
	uint8_t adcch=0;
	switch(Adc_Scan_Setp)
	{
	case 0:
		// 设置ADC滤波器的计时器周期
		sl_SetTimerPeriod(ADC_Filer, ADC_FILTER_TIME);
		// 刷新计时器
		sl_RefreshTimer(ADC_Filer);
		// 设置ADC扫描步骤为1
		Adc_Scan_Setp = 1;
		break;
	case 1:
		// 遍历10个ADC采样通道
		for(adcch = 0; adcch < (ADC0_CHANNEL_NUMBER); adcch++)
		{
			// 获取ADC通道的值
			SL_ADC0_GetChannelVal(adcch);
		}
		// 调用m_adc_info函数处理ADC信息
		m_adc_info();
		//Get_NTCSts();
		//cnt_adc--;
		// 设置ADC扫描步骤为2
		Adc_Scan_Setp = 2;
		break;
	case 2:
		// 判断ADC滤波器的计时器是否超时
		if(sl_IsTimerExceed(ADC_Filer))
		{
			// 将ADC扫描步骤重置为0
			Adc_Scan_Setp=0;
		}
		break;
	default:
		break;
	}
}

/**
 * @brief 获取BIN值初始化
 *
 * 当cnt_adc不为0时，持续执行sl_adc_Tesk函数。
 * 当cnt_adc为0时，调用GetBinSts函数和MspEERomFun函数。
 */
void get_BIN_Val(void)//BIN值获取初始化
{
	if(cnt_adc == 0)
	{
		GetBinSts();
		MspEERomFun();
		cnt_adc=1;
	}
}
