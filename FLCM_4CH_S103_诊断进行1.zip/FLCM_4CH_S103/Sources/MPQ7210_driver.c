/*
 * MPQ7210_driver.c
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 */

#include "MPQ7210_driver.h"
#include "Diagnostic_fault.h"
#include "sl_softtimer.h"
#include "LLD_config.h"
#include "spi1.h"
#include "spi_pal_cfg.h"
#include <stddef.h>
#include "common_types.h"

uint8_t master_receive[SPI_BUFFER_SIZE];
/*
uint8_t Addrdata[5]={0x03,0x04,0x05,0x06,0x07};
uint8_t AddrdataU1[5]={0};
uint8_t AddrdataU2[5]={0};
uint8_t AddrdataU3[5]={0};
uint8_t AddrdataU11[3];
uint8_t AddrdataU22[3];
uint8_t AddrdataU33[3];
*/

//uint8_t diagnosticFlag = 0;//诊断标志变量，用来限制adc平均值转换

// 计算单个结构体的大小，存放在structSize作为结构体的位移量
//size_t structSize;
//全局变量用来存放有效值

// 定义一组结构体用来存放MPQ7210的ADC寄存器
MPQ_ADC_Config_t MPQ7210_ADC_Registers[APP_NUM_OF_BUCK];

ADC_OUT_Reg_t mpq7210_buck_data =
{
	    .no_use = 0,
	    .adc_data = 0,
	    .reserved16 = 0
};

void SPI_CS_DEAL(uint8_t DevType) //片选处理
{
	if(DevType == U1_MPQ7210)
	{
		BUCK_SPI_CS1_ENABLE;
		BUCK_SPI_CS2_DISABLE;
	}
	if(DevType == U2_MPQ7210)
	{
		BUCK_SPI_CS1_DISABLE;
		BUCK_SPI_CS2_ENABLE;
	}
}

void SPI_CS_CLR(void) //片选清理
{
	BUCK_SPI_CS1_DISABLE;
	BUCK_SPI_CS2_DISABLE;
}

//*************轮询ADC********************//
sMPQ7210_wCMD_STRUCT ADC_CmdTable[] = {
    {ADC_CTRL_ADDR, BUCK1VIN_ADC_CTRL},    // 设置为BUCK1的输入电压
    {ADC_CTRL_ADDR, BUCK1VOUT_ADC_CTRL},   // 设置为BUCK1的输出电压
    {ADC_CTRL_ADDR, BUCK2VIN_ADC_CTRL},    // 设置为BUCK2的输入电压
    {ADC_CTRL_ADDR, BUCK2VOUT_ADC_CTRL},   // 设置为BUCK2的输出电压
    {ADC_CTRL_ADDR, BUCKVCC_ADC_CTRL},     // 设置为VCC电压
    {ADC_CTRL_ADDR, BUCKTEMP_ADC_CTRL},    // 设置为MPQ7210的温度
};

//*************常规设置，点灯必须附带********************//
sMPQ7210_wCMD_STRUCT MPQ7210_NORMAL_CmdTable[]=
{
	{INT_CFG_ADDR, INT_CFG_ALLNOACT},//设保护为全打嗝
	{FS_INT_EN_ADDR, FS_EN_ALL_CTRL},//开启相关故障检测
	{FS_INT_MASK_EN_ADDR, MASK_DIS_ALL_CTRL},//屏蔽没开启的功能
};

//*************数字100% - 50% 最大1000mA********************//
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one100_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},//BUCK1 100% 占空比输出
	{ANA_DIM1_ADDR, ANA_CUR_1000MA}, //BUCK 模拟调光1A
};


sMPQ7210_wCMD_STRUCT MPQ7210_DS_two100_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one90_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two90_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one80_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two80_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one70_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two70_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one60_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two60_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one50_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two50_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};


//*************模拟1000mA - 500mA********************//
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one958_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_958MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two958_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_958MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two500_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_500MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one919_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_919MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one878_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_878MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two855_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_855MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two805_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_805MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_AS_one90_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_900MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two90_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_900MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one80_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_800MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two80_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_800MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one70_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_700MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two70_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_700MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one60_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_600MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two60_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_600MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one50_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_500MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two50_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_500MA},
};


//*************数字200mA -160mA********************//
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one200_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two200_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one180_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two180_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one160_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two160_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_one100mA_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_10_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_958MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two100mA_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_10_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_958MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DS_one20_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_10_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_DS_two10_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_12_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_958MA},
};

//*************模拟200mA -120mA********************//
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one180_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_180MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two180_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_180MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one160_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_160MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two160_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_160MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one140_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_140MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two140_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_140MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_one120_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_120MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_AS_two120_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_120MA},
};



sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_pl_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};


sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable50[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable50[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable50[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable50[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable60[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable60[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable60[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable60[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable70[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable70[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable70[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable70[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable80[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable80[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable80[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable80[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable85[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_85_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable85[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_85_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable85[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_85_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable85[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_85_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_Ti_CmdTable90[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_DRL_CmdTable90[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_LB_CmdTable90[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_HB_CmdTable90[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};


sMPQ7210_wCMD_STRUCT MPQ7210_30_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_30_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_30_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_30_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_40_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_40_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_40_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_40_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_50_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_50_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_60_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_600MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_60_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_600MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_70_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_700MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_70_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_700MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_80_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_800MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_80_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_800MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_90_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_900MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_90_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_900MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_100_One_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_1000MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_100_two_CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_1000MA},
	//{PWM_DIM2_ADDR, 0xA401},
	//{ANA_DIM2_ADDR, 0X6E00},
};


sMPQ7210_wCMD_STRUCT MPQ7210_30_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_30_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_30_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_30_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_40_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_40_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_40_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_40_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_50_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_50_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_50_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_60_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_60_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_60_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_70_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_70_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_70_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_140MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_80_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_80_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_80_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_160MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_90_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_90_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};
sMPQ7210_wCMD_STRUCT MPQ7210_90_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_180MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_100_One_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM1_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM1_ADDR, ANA_CUR_200MA},
};

sMPQ7210_wCMD_STRUCT MPQ7210_100_two_200CmdTable[]=
{
	{DEV_CFG_ADDR, DP_DIM3_500HZ},//模式3,500HZ
	{PWM_DIM2_ADDR, PWM_DIM_100_PERCENT},
	{ANA_DIM2_ADDR, ANA_CUR_200MA},
};

uint8_t data_length = (uint8_t)(sizeof(MPQ7210_DS_one100_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));//点灯指令集长�?
uint8_t normal_length = (uint8_t)(sizeof(MPQ7210_NORMAL_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));//常�?�指令集长度
uint8_t ADC_length = (uint8_t)(sizeof(ADC_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));//adc指令集长�?
uint8_t LB_length = (uint8_t)(sizeof(MPQ7210_LB_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));
uint8_t HB_length = (uint8_t)(sizeof(MPQ7210_HB_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));
uint8_t DRL_length = (uint8_t)(sizeof(MPQ7210_DRL_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));
uint8_t PL_length = (uint8_t)(sizeof(MPQ7210_pl_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));
uint8_t TI_length = (uint8_t)(sizeof(MPQ7210_Ti_CmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));
//uint8_t DRL_TICm_length = (uint8_t)(sizeof(MPQ7210_DRL_TICmdTable)/sizeof(sMPQ7210_wCMD_STRUCT));

uint8_t LLD_MPQ7210_rxtxOper(uint8_t DevType, uint8_t bWR, uint8_t addr, uint8_t* pInData, uint8_t * pOutData, uint8_t dlen)// uint8_t * pOutData1,
{
	  uint8_t buf[32];
	  uint8_t cur_byte=0;

	  if(dlen > INDATALenght)
	  {
		  return 0;
	  }
	  //SPI_CS_DEAL(DevType);
	  if(DevType == U1_MPQ7210)
	  {
		  BUCK_SPI_CS1_DISABLE;
	  }
	  if(DevType == U2_MPQ7210)
	  {
		  BUCK_SPI_CS2_DISABLE;
	  }
	  addr<<=1;
	  if(bWR)//�?
	  {
		  addr |= 1;
		  buf[0] = addr;

		  //SPI_MasterTransfer(&spi1Instance,buf, pOutData, 3);
		  SPI_MasterTransferBlocking(&spi1Instance, buf, pOutData, 3, 1);
		  if(DevType == U1_MPQ7210)
		  {
			  BUCK_SPI_CS1_ENABLE;
		  }
		  if(DevType == U2_MPQ7210)
		  {
			  BUCK_SPI_CS2_ENABLE;
		  }
	  }
	  else//�?
	  {
		  buf[0] = addr;
		  for(cur_byte = 0; cur_byte < dlen; cur_byte++)
		  {
			 buf[cur_byte+1] = pInData[cur_byte];
		  }

		  cur_byte += 1;
		  //SPI_MasterTransfer(&spi1Instance,buf, pOutData, cur_byte);
		  SPI_MasterTransferBlocking(&spi1Instance, buf, pOutData, cur_byte, TIME_OUT_1MS);
		  if(DevType == U1_MPQ7210)
		  {
			  BUCK_SPI_CS1_ENABLE;
		  }
		  if(DevType == U2_MPQ7210)
		  {
			  BUCK_SPI_CS2_ENABLE;
		  }
	  }
	  //SPI_CS_DEAL(DevType);

	  return 0;
}

void Flash_send_fun(uint8_t DevType,uint8_t status,uint16_t *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length)
{
	uint8_t i=0;

	uint8_t temp[2]={0};
	uint8_t reg_addr=0;

	for(i = 0; i<Length-1; i = i+2)
	{
	    temp[0] = MPQ7210_CmdTable[i+1]>>8;
	    temp[1] = MPQ7210_CmdTable[i+1];
	    reg_addr =MPQ7210_CmdTable[i];
	    LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, master_receive, 2);// NULL,
	    //delay_1ms(2);
	}
}

void Sl_MPQ7210_send(uint8_t DevType,uint8_t status,sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length)
{
	uint8_t i=0;
	uint8_t temp[2];
	uint8_t reg_addr;

	for(i=0; i<Length; i++)
	{
	    temp[0] = MPQ7210_CmdTable[i].data>>8;
	    temp[1] = MPQ7210_CmdTable[i].data;
	    reg_addr =MPQ7210_CmdTable[i].addr;
	    LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, master_receive,2);// NULL,

	}
}

/**
 * @brief 把MPQ7210得ADC通道进行写入并读出对应通道得ADC数值读出
 *
 * 共进行8轮数据采集，采集后进行平均运算
 */
void MPQ7210_adc_send(uint8_t DevType, uint8_t status, sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable, MPQ_ADC_Config_t *adcDataStr, uint8_t Length)
{
	uint8_t buck_id_idx;//MPQ7210设备号变量
	sint8_t buck_ch_idx;//MPQ7210通道号变量
	uint8_t buck_cyc_idx;//周期采样圈数变量
    uint8_t temp[2];//新建一个数据发送得缓存空间
    uint8_t reg_addr;//新建一个变量存放即将操作的地址
    uint16_t reg_ctrlvalue = 0;//新建一个变量用来存放要发给ADC通道寄存器的控制指令
	bool buck_fail_flag = false;//用于存放一个标志，判断上个阶段得SPI写入是否成功
    uint8_t adc_ctrl_temp[3] = {0};//新建一个数组用于存放ADC控制指令的buf，用来评估是否写入成功
    uint8_t adcDataAddr[1] = {ADC_DATA_ADDR}; // 将宏的值赋给一个变量
    uint8_t adcCtrlAddr[1] = {ADC_CTRL_ADDR}; // 将宏的值赋给一个变量
	int truncated_int = 0;//临时变量用来保留小数点前两位
	float buck_min_val = 0;//临时变量用来存放整体浮点数
	float fractional_part = 0;//临时变量用来存放小数点后的数
	float truncated_fraction = 0;//临时变量用来存放小数点后的有效数

	memset(&MPQ7210_ADC_Registers, 0, sizeof(MPQ7210_ADC_Registers));//清空总寄存器为后续求和做准备

	for (buck_cyc_idx = 0; buck_cyc_idx < ADC_DATAGET_CYC; buck_cyc_idx++)//遍历8圈
	{
		for (buck_id_idx = BUCK1; buck_id_idx < APP_NUM_OF_BUCK; buck_id_idx++)//遍历2个Buck
		{
			for (buck_ch_idx = BUCK1VIN; buck_ch_idx < ADC_CHANNEL_COUNT; buck_ch_idx++)//遍历单个buck的6个通道
			{
				if(buck_fail_flag)
				{
					buck_ch_idx -= 2;//将ch回退到写入失败得通道
					buck_fail_flag = false;//清空写失败标志
				}
				else
				{
					temp[0] = MPQ7210_CmdTable[buck_ch_idx].data >> 8;
					temp[1] = MPQ7210_CmdTable[buck_ch_idx].data;
					reg_addr = MPQ7210_CmdTable[buck_ch_idx].addr;
					LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, NULL, 2);//发送SPI命令到当前寄存器
					Sl_MPQ7210_16bit_receive(DevType, adcCtrlAddr, adc_ctrl_temp);//SPI读取<ADC控制寄存器>内容
					reg_ctrlvalue = (uint16_t)((uint8_t)(adc_ctrl_temp[2]) << 8 | (uint8_t)(adc_ctrl_temp[1]));//将读取到2份8位数据，拼接成16位数据
					ADC_CTRL_Reg_t *mpq7210_adc_sta = (ADC_CTRL_Reg_t *) & (reg_ctrlvalue);//将16位数据解析并配置到mpq7210_adc_sta结构体实例里
					if(mpq7210_adc_sta->adc_inmux == mpq7210_adc_sta->cur_stored_ch)//判断当前寄存器是否写入成功
					{
						Sl_MPQ7210_16bit_receive(DevType, adcDataAddr, adcDataStr[buck_id_idx].DataBuf[buck_ch_idx]);//SPI读取<ADC数据寄存器>内容
						MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] = (uint16_t)((uint8_t)(MPQ7210_ADC_Registers[buck_id_idx].DataBuf[buck_ch_idx][2]) << 8 | (uint8_t)(MPQ7210_ADC_Registers[buck_id_idx].DataBuf[buck_ch_idx][1]));//将获取的ADC数据拼接成16位数据
						mpq7210_buck_data.no_use = MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] & 0x03; // 取低2位
						mpq7210_buck_data.adc_data = (MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] >> 2) & 0xFF; // 取接下来的2位
						mpq7210_buck_data.reserved16 = MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] >> 10; // 取剩余的高位
						switch (buck_ch_idx)
						{
							case BUCK1VIN:
								buck_min_val = (float)((mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK1VOUT:
								buck_min_val = (float)((mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK2VIN:
								buck_min_val = (float)((mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK2VOUT:
								buck_min_val = (float)((mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCKVCC:
								buck_min_val = (float)((mpq7210_buck_data.adc_data) * (0.032));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCKTEMP:
								buck_min_val = (2 * (float)((mpq7210_buck_data.adc_data) - (131.25)));
							break;
							default:
							/*TBD*/
							break;
						}	
						truncated_int = (int)buck_min_val;//割出小数点以前
						fractional_part = (float)(buck_min_val - truncated_int);//割出小数点以后
						truncated_fraction = truncf(fractional_part * 100) / 100;//保留小数点后两位
						MPQ7210_ADC_Registers[buck_id_idx].buck1_vin_value[buck_ch_idx][buck_cyc_idx] = (float)(truncated_int + truncated_fraction);
						MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] = (MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] + MPQ7210_ADC_Registers[buck_id_idx].buck1_vin_value[buck_ch_idx][buck_cyc_idx]);
					}
					else//当前寄存器写入失败
					{
						buck_fail_flag = true;//置位写失败标志
					}
				}
			}
		}
	}
	//采样8次数据以后进行均值计算
	for (buck_id_idx = BUCK1; buck_id_idx < APP_NUM_OF_BUCK; buck_id_idx++)//遍历2个Buck
	{
		for (buck_ch_idx = BUCK1VIN; buck_ch_idx < ADC_CHANNEL_COUNT; buck_ch_idx++)//遍历单个buck的6个通道
		{
			MPQ7210_ADC_Registers[buck_id_idx].real_buck_value[buck_ch_idx] = (float)(MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] / 8);
		}
	}
}

void Sl_MPQ7210_16bit_receive(uint8_t DevType, uint8_t *Read_AddrCmdTable, uint8_t *Readdata)
{
	uint8_t reg_addr;
	reg_addr = Read_AddrCmdTable[0];
	LLD_MPQ7210_rxtxOper(DevType, READ_BIT, reg_addr, NULL, Readdata, 1);
}

void app_spi0_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable,NULL,HB_length);  //HB
}

void app_spi50_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable50,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable50,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable50,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable50,NULL,HB_length);  //HB
}

void app_spi60_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable60,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable60,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable60,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable60,NULL,HB_length);  //HB
}
void app_spi70_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable70,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable70,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable70,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable70,NULL,HB_length);  //HB
}
void app_spi80_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable80,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable80,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable80,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable80,NULL,HB_length);  //HB
}
void app_spi85_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable85,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable85,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable85,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable85,NULL,HB_length);  //HB
}
void app_spi90_part(void)
{
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_Ti_CmdTable90,NULL,TI_length);	 //TI
	Sl_MPQ7210_send(U1_MPQ7210,WRITE_BIT,MPQ7210_DRL_CmdTable90,NULL,DRL_length);  //DRL -1
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_LB_CmdTable90,NULL,LB_length);  //LB
	Sl_MPQ7210_send(U2_MPQ7210,WRITE_BIT,MPQ7210_HB_CmdTable90,NULL,HB_length);  //HB
}
