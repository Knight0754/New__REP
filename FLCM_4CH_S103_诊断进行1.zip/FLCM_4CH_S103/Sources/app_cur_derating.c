/*
 * app_cur_derating.c
 *
 *  Created on: 2023骞�11鏈�10鏃�
 *      Author: gz06488
 */

#include "app_cur_derating.h"
#include "MPQ7210_driver.h"
#include "app_bin.h"
#include "sl_softtimer.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "al_light_function.h"
#include "data.h"

uint16_t gU16_b_Timer = 0;
uint16_t gU16_Cur_dera_Timer = 0;
uint32_t gU32_KL30Value=0;
uint32_t gU32_KL30Value_mode1=0;
const uint8_t buff_arr[50]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,};
uint8_t pe_num=0;
uint8_t Current_num=0;
uint8_t actual_num=0;
uint8_t RX_pe_num=0;
uint8_t buff_level = 0;
uint8_t Cur_dera_step = 0;
uint16_t Cur_dera_Step_time_buff[256]={0};
uint16_t Cur_dera_add_arr[6]={0,0,0,0,0,0};
//s_STATE_STRUCT s_state_struct={0,49};
s_STATE_STRUCT s_state_struct={0,0};
s_STATE_STRUCT s_state_num1={0,0,1,};
s_STATE_STRUCT s_state_num2={0,0,2,};
s_STATE_STRUCT s_state_num3={0,0,3,};
uint8_t kk = 0;
uint8_t flag_new = 1;

uint8_t send_level_num1_A=0;
uint8_t send_level_num2_A=0;
uint8_t send_level_num3_A=0;



sMPQ7210_wCMD_STRUCT CC3_MPQ7210_CmdTa5[]=
{
	0
};

psMPQ7210_wCMD_STRUCT    pCmd;
pLIGHT_PIXEL_LIST_t    pChList;

//uint8_t CC3_length = (uint8_t)(sizeof(3*s_wCMD_STRUCT)/sizeof(s_wCMD_STRUCT));

uint8_t Pixe_step = 0;
uint16_t Pixe_Step_time_buff[256]={0};
uint16_t flash_add_arr[6]={0};

//**閫氳繃7210 瀵勫瓨鍣ㄦ帶鍒朵寒搴︼紝閫傜敤鍔ㄧ敾鍛煎惛***/
 void LLD_PixelDarsing(uint8_t CC_type,uint8_t num_legth,const  uint16_t Data_lb_arr[][8])
{
	uint8_t i=0;
	for(i=Pixe_step;i<Pixe_step+1;i++)
	{
		Pixe_Step_time_buff[i] =*(Data_lb_arr[i]+1);
		if(IsTimeOver(gU16_b_Timer,Pixe_Step_time_buff[i]))
		{
			/*kk++;
			if(kk == 2 ) kk=0;
			if(kk%2) Open_IC3_CH6_EN_ENABLE;
			else 	Open_IC3_CH6_EN_DISABLE;
			*/
			Pixe_step++;
			//if(Pixe_step == (sizeof(Data_lb_arr)/sizeof(Data_lb_arr[0]))) Pixe_step =0;
			if(Pixe_step == num_legth) Pixe_step =0;
			gU16_b_Timer = GetCurTime();
			flash_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);
			flash_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
			flash_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
			flash_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
			flash_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
			flash_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
			Flash_send_fun(CC_type,WRITE_BIT,flash_add_arr,NULL,(sizeof(flash_add_arr)/sizeof(uint16_t)));
		}

	}
}
 uint8_t sl_cur_derating_fun1(uint8_t CC_type,uint8_t level,const  uint16_t Data_lb_arr[][8])
 {
	 Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[0]+2);
	Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[0]+3);
	Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[0]+4);
	Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[0]+5);
	Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[0]+6);
	Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[0]+7);
	Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));


 		return 0;
 }
 void time_100ms(uint8_t time_cont)
 {

	 for(uint8_t i = 0;i < 4*time_cont; i++)
	 {
		 if(time_cont > 255)
		 {
			  break;
		 }
		 OSIF_TimeDelay(25);
	 }

 }
 uint16_t g_rtoscount = 0;
 uint16_t g_dreatingcount = 0;
 uint16_t g_dreatingcount_down = 0;
 uint16_t g_dreatingcount_up = 0;
 uint16_t g_dreatingcount_sum = 0;
 uint16_t g_dreatingcountC_A = 0;
 uint16_t g_dreatingcount_sumC_A = 0;
 uint16_t cnt_i = 0;
 uint16_t cnt_j = 0;
 uint8_t Time_out_cnt(uint8_t time_base,uint16_t dy_time) //dy_time 是time_base的倍数
 {
 	g_rtoscount++;

 	if(time_base <= dy_time)
 	{
 		if(g_rtoscount == dy_time/time_base)
 		{
 			g_rtoscount=0;
 			return 1;
 		}
 	}
 	else return 0;

 	return 0;
 	/*g_rtoscount = dy_time/time_base;*/

 }
void sl_curC_A_fun(uint8_t CC_type,uint8_t num,const  uint16_t Data_lb_arr[][8])
{
	if(1 == Time_out_cnt(BASETIME,Data_lb_arr[num + g_dreatingcount][1]))
	{
		for(uint8_t i=num + g_dreatingcount; i < 50; i++)
			{
					Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);
					Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
					Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
					Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
					Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
					Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
					Flash_send_fun(CC_type, WRITE_BIT, Cur_dera_add_arr, NULL, (sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
					g_dreatingcount++;
					if(g_dreatingcount > 50) g_dreatingcount = 0;
					if(i >= 49)
					{
						g_dreatingcount=0;
						flagC_A_drl = 0;
					}
					break;

			}
	}
}

 void delay_us(uint32_t T)
 {
	 while(T--);
 }
uint8_t sl_cur_fun(uint8_t CC_type,uint8_t status,const  uint16_t Data_lb_arr[][8])
{
	if(status==A_LEVEL)
	{
		flagHB = 0;flagLB = 0;flagDRL = 0;
		Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[49]+2);
		Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[49]+3);
		Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[49]+4);
		Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[49]+5);
		Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[49]+6);
		Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[49]+7);
		Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
	}
	if(status==B_LEVEL)
	{
		flagHB = 0;flagLB = 0;flagDRL = 0;
		Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[39]+2);
		Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[39]+3);
		Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[39]+4);
		Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[39]+5);
		Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[39]+6);
		Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[39]+7);
		Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
	}
	if(status==C_LEVEL)
	{
		flagHB = 0;flagLB = 0;flagDRL = 0;
		Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[29]+2);
		Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[29]+3);
		Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[29]+4);
		Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[29]+5);
		Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[29]+6);
		Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[29]+7);
		Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
	}
	if(status==D_LEVEL)
	{
		flagHB = 0;flagLB = 0;flagDRL = 0;
		Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[0]+2);
		Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[0]+3);
		Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[0]+4);
		Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[0]+5);
		Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[0]+6);
		Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[0]+7);
		Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
	}
	return 0;
}


 uint8_t sl_cur_derating_fun(uint8_t CC_type,uint8_t level,const  uint16_t Data_lb_arr[][8],uint8_t flag)
{

	 uint8_t i,j =0;
	 buff_level =level;
	if((buff_level != s_state_struct.new ) )//&&(flag_new == 1))
	{
		s_state_struct.new = buff_level;
	}
	if(s_state_struct.old != s_state_struct.new)
	{
		/* send_level_num1_A =1;
		send_level_num2_A =1;
		send_level_num3_A =1; */
		if(flag == 1) send_level_num1_A =1;
		if(flag == 2) send_level_num2_A =1;
		if(flag == 3) send_level_num3_A =1;
		
			if(s_state_struct.old < s_state_struct.new)//降额
			{
				if(1 == Time_out_cnt(BASETIME,Data_lb_arr[(50-(10*(s_state_struct.old)))-1-g_dreatingcount_down][1]))
				{
					//for(j=((50-(10*(s_state_struct.old-1)))-1-g_dreatingcount_down); j >= (50-(10*(s_state_struct.new-1))+1); j--)
					 for(j=((50-(10*(s_state_struct.old)))-1-g_dreatingcount_down); j >= (50-(10*(s_state_struct.new))+1); j--)
					{
							Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[j]+2);
							Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[j]+3);
							Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[j]+4);
							Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[j]+5);
							Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[j]+6);
							Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[j]+7);

							Flash_send_fun(CC_type, WRITE_BIT, Cur_dera_add_arr, NULL, (sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
							flag_new = 0;
							g_dreatingcount_down++;
							if(g_dreatingcount_down > 50) g_dreatingcount_down = 0;
							if(j<=(50-(10*(s_state_struct.new))+1))
							{
								g_dreatingcount_down=0;
								
								/* send_level_num1_A =0;
								send_level_num2_A =0;
								send_level_num3_A =0;
								s_state_num1.old = s_state_num1.new;
								s_state_num2.old = s_state_num2.new;
								s_state_num3.old = s_state_num3.new; */
								if(flag == 1)
								{
									s_state_num1.old = s_state_num1.new;
									send_level_num1_A =0;
								}
								if(flag == 2)
								{
									send_level_num2_A =0;
									s_state_num2.old = s_state_num2.new;
								}
								if(flag == 3)
								{
									send_level_num3_A =0;
									s_state_num3.old = s_state_num3.new;
								}
								flag_new = 1;
								flagC_A_drl = 1;
								s_state_struct.old = s_state_struct.new;
							}
							break;
					}
				}
			}
			if(s_state_struct.old > s_state_struct.new)//sheng升
			{
				if(1 == Time_out_cnt(BASETIME,Data_lb_arr[50-(10*(s_state_struct.old))+ g_dreatingcount_up][1]))
				{
					for(i=(50-(10*(s_state_struct.old))+ g_dreatingcount_up);i <= (50-(10*(s_state_struct.new)))-1;i++)
					{
							Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);
							Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
							Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
							Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
							Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
							Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
							Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
							flag_new = 0;
							g_dreatingcount_up++;
							if(g_dreatingcount_up > 50) g_dreatingcount_up = 0;
							if(i>=(50-(10*(s_state_struct.new)))-1)
							{
								g_dreatingcount_up=0;
								if(flag == 1)
								{
									s_state_num1.old = s_state_num1.new;
									send_level_num1_A =0;
								}
								if(flag == 2)
								{
									send_level_num2_A =0;
									s_state_num2.old = s_state_num2.new;
								}
								if(flag == 3)
								{
									send_level_num3_A =0;
									s_state_num3.old = s_state_num3.new;
								}
								flag_new = 1;
								flagC_A_drl = 1;
								s_state_struct.old = s_state_struct.new;
							}
							break;
					}
				}

			}
	}

	else{
			/* send_level_num1_A =0;
			send_level_num2_A =0;
			send_level_num3_A =0; */
			if(flag == 1)
			{
				send_level_num1_A =0;
			}
			if(flag == 2)
			{
				send_level_num2_A =0;
			}
			if(flag == 3)
			{
				send_level_num3_A =0;
			}
		 if((s_state_struct.old == s_state_struct.new) && s_state_struct.new==A_LEVEL)
			{
				flagHB = 0;flagLB = 0;flagDRL = 0;
				Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[49]+2);
				Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[49]+3);
				Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[49]+4);
				Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[49]+5);
				Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[49]+6);
				Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[49]+7);
				Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
			}
			if((s_state_struct.old == s_state_struct.new) && s_state_struct.new==B_LEVEL)
			{
				flagHB = 0;flagLB = 0;flagDRL = 0;
				Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[39]+2);
				Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[39]+3);
				Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[39]+4);
				Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[39]+5);
				Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[39]+6);
				Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[39]+7);
				Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
			}
			if((s_state_struct.old == s_state_struct.new) && s_state_struct.new==C_LEVEL)
			{
				flagHB = 0;flagLB = 0;flagDRL = 0;
				Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[29]+2);
				Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[29]+3);
				Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[29]+4);
				Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[29]+5);
				Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[29]+6);
				Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[29]+7);
				Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
			}
			if((s_state_struct.old == s_state_struct.new) && s_state_struct.new==D_LEVEL)
			{
				flagHB = 0;flagLB = 0;flagDRL = 0;
				Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[0]+2);
				Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[0]+3);
				Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[0]+4);
				Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[0]+5);
				Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[0]+6);
				Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[0]+7);
				Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
			} 
	}

	return 0;
}


/*uint8_t lld_cur_derating_fun(uint8_t CC_type,const  uint16_t Data_lb_arr[][8])
{
	uint8_t i =0;
		gU32_KL30Value = KL30_buff;  //adc_info.GetKL30_Result;
		if(gU32_KL30Value <VOL_7_0V_UP) // (VOL_7_0V_UP -20))
			return 1;
		else if(gU32_KL30Value > VOL_10_0V_DOWN)
			return 2;
		else{
			pe_num = (gU32_KL30Value - VOL_7_0V_UP)/VOL_PE_ADvale;
			//Current_num = pe_num;
			if(pe_num != s_state_struct.new )
			{
				s_state_struct.new = abs(pe_num);
			}
			if(pe_num <0 ) return 1;//|| pe_num >(VOL_PE+1)
			else{
				if(sl_IsTimerExceed(Test_Filer1) && ((s_state_struct.old != s_state_struct.new)))
				{
					//PINS_DRV_TogglePins(B12_EN_LED1_LB_GPIO,1 << 12);
					if(s_state_struct.old != s_state_struct.new)
					{
						if(s_state_struct.old > s_state_struct.new)
						{
							for(i=s_state_struct.old;i>s_state_struct.new-1;i--)
							{
									Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);

									Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
									Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
									Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
									Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
									Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
									OSIF_TimeDelay(200);
									Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
							}
						}
						if(s_state_struct.old < s_state_struct.new)
						{
							for(i=s_state_struct.old;i<s_state_struct.new+1;i++)
							{
									Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);
									Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
									Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
									Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
									Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
									Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
									OSIF_TimeDelay(100);
									Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
							}
						}
						s_state_struct.old = s_state_struct.new;
					}

					sl_RefreshTimer(Test_Filer1);
				}
				else {
					sl_SetTimerPeriod(Test_Filer1, 100);
				}
				if((s_state_struct.old == s_state_struct.new))
				{

					Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+2);
					Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+3);
					Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+4);
					Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+5);
					Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+6);
					Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[s_state_struct.new]+7);
					Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
				}
			}
		}
		return 0;


	uint8_t i =0;
	gU32_KL30Value = KL30_buff;  //adc_info.GetKL30_Result;
	if(gU32_KL30Value < (VOL_7_0V_UP -20))
		return 1;
	else if(gU32_KL30Value > VOL_10_0V_DOWN)
		return 2;
	else{
		pe_num = (gU32_KL30Value - VOL_7_0V_UP)/VOL_PE_ADvale;
		if(pe_num <=0 || pe_num >(VOL_PE+1)) return 1;
		else{
			for(uint8_t j=1; j <VOL_PE+1;j++)
			{
				if(buff_arr[j] == pe_num)
				{
					RX_pe_num=pe_num;
					break;
				}
			}
			for(i=RX_pe_num;i<RX_pe_num+1;i++)
			{
					Cur_dera_add_arr[0] =(uint16_t)*(Data_lb_arr[i]+2);
					Cur_dera_add_arr[1] =(uint16_t)*(Data_lb_arr[i]+3);
					Cur_dera_add_arr[2] =(uint16_t)*(Data_lb_arr[i]+4);
					Cur_dera_add_arr[3] =(uint16_t)*(Data_lb_arr[i]+5);
					Cur_dera_add_arr[4] =(uint16_t)*(Data_lb_arr[i]+6);
					Cur_dera_add_arr[5] =(uint16_t)*(Data_lb_arr[i]+7);
					Flash_send_fun(CC_type,WRITE_BIT,Cur_dera_add_arr,NULL,(sizeof(Cur_dera_add_arr)/sizeof(uint16_t)));
			}
		}
	}
	return 0;
}*/




