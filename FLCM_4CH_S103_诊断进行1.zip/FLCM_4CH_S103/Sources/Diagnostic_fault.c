/*
 * Diagnostic_fault.c
 *
 *  Created on: 2023年11月16日
 *      Author: gz06488
 */

#include "Diagnostic_fault.h"
#include "app_bin.h"
#include "app_signal_check.h"
#include "MPQ7210_driver.h"
#include "al_light_function.h"
#include <math.h>
#include "stdbool.h"
#include "al_light_function.h"
#include "app_signal_check.h"
#include "LLD_Config.h"
#include "light_mgr.h"
#include "sl_softtimer.h"
#include <string.h> 

void cc3_open_circuit_diagnosis(void);
void cc3_short_circuit_diagnosis(void);

m_LAMP_CONTROL e_LAMP_CMD;
/**
 * 初始化结构体实例
*/
m_BUCK_ERR e_MPQ7210_ERR = {
    .e_lamp = {
        .lb = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
        .hb = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
        .drl = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
        .pl = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
        .tl = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
        .lhb = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
        },
		.cc3 = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
  		},
		.cc2 = {
            .open_err_flag = false,
            .short_err_flag = false,
            .ntc_err_flag = false,
            .rbin_err_flag = false,
            .err_start_timer_flag = false,
			.recov_start_timer_flag = false,
            .counter_500ms_cnt = 0,
			.counter_500ms_dec = 0,
			.err_level = FAULT_LEVEL_DEF,
            .condition_met = NO_FAULT
  		}
    },
    .e_other = {
        .nte_err_flag = false,
        .spi_err_flag = false,
        .kl30_uv_err_flag = false,
        .kl30_ov_err_flag = false
    }
};

void Fault_Trigger_Check(void)
{
	//这里的判断条件不完整，等做完短路关灯控制功能后，要利用那里的标志位来这里补充个逻辑判断防止关灯后进行错误检测。
	if((Input_key_arr[K_LB] == CH_LB_ON) || (Input_key_arr[K_HB] == CH_HB_ON))
	{
		cc3_open_circuit_diagnosis();
		cc3_short_circuit_diagnosis();
	}
	else
	{
		e_MPQ7210_ERR.e_lamp.cc3.err_start_timer_flag = false;
		e_MPQ7210_ERR.e_lamp.cc3.recov_start_timer_flag = false;
		e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt = 0;
		e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec = 0;
		e_MPQ7210_ERR.e_lamp.cc3.condition_met = false;
	}

	if((Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) && (Input_key_arr[K_TL] == CH_TL_OFF))
	{

	}
	else
	{
		//日行或位置
		if(Input_key_arr[K_TL] == CH_TL_OFF &&  (ti_offtimer ==0))
		{

		}
		//转向
		else
		{	
			
		}
		
	}
}

/**
 * 远近光多级故障处理函数
*/
void manage_lhb_fault(void)
{
	switch(e_MPQ7210_ERR.e_lamp.lhb.err_level)
	{
		//可能1- 从始至终没有故障
		case FAULT_LEVEL_DEF:
			e_MPQ7210_ERR.e_lamp.lb.condition_met = false;//清零lb故障条件满足标志
			e_MPQ7210_ERR.e_lamp.lb.open_err_flag = false;//清零lb开路故障标志
			e_MPQ7210_ERR.e_lamp.hb.condition_met = false;//清零hb故障条件满足
			e_MPQ7210_ERR.e_lamp.hb.open_err_flag = false;//清零hb开路故障标志
			e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_EN;//开启远光灯
			e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_EN;//开启近光灯
		break;
		//可能2- 打开近光，关闭远光后故障消失
		case FAULT_LEVEL_HBOFF:
			e_MPQ7210_ERR.e_lamp.hb.open_err_flag = true;//设置hb开路故障标志为真
			e_MPQ7210_ERR.e_lamp.lb.condition_met = true;//设置lb故障条件满足标志为真
		break;
		//可能3- 打开远光，关闭近光后故障消失
		case FAULT_LEVEL_LBOFF:
			e_MPQ7210_ERR.e_lamp.lb.open_err_flag = true;//设置lb开路故障标志为真
			e_MPQ7210_ERR.e_lamp.hb.condition_met = true;//设置hb故障条件满足标志
		break;
		default:
			//可以预留DTC报错标识
		break;
	}
}

/**
 * 近光灯故障恢复函数
*/
void recoverLowBeam(void)
{
	e_MPQ7210_ERR.e_lamp.lb.condition_met = false;//清零lb故障条件满足标志
	e_MPQ7210_ERR.e_lamp.lb.open_err_flag = false;//清零lb开路故障标志
	e_MPQ7210_ERR.e_lamp.lb.counter_500ms_dec = 0;//清零lb故障持续时间计数器
	e_MPQ7210_ERR.e_lamp.lb.recov_start_timer_flag = false;//清除lb故障恢复开始计时器
	e_MPQ7210_ERR.e_lamp.lb.err_start_timer_flag = false;//清除lb故障开始计时器
	e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_EN;//开启近光灯
}

/**
 * 远光灯故障恢复函数
*/
void recoverHighBeam(void)
{
	e_MPQ7210_ERR.e_lamp.hb.condition_met = false;//清零hb故障条件满足标志
	e_MPQ7210_ERR.e_lamp.hb.open_err_flag = false;//清零hb开路故障标志
	e_MPQ7210_ERR.e_lamp.hb.counter_500ms_dec = 0;//清零hb故障持续时间计数器
	e_MPQ7210_ERR.e_lamp.hb.recov_start_timer_flag = false;//清除
	e_MPQ7210_ERR.e_lamp.hb.err_start_timer_flag = false;//清除
	e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_EN;//开启远光灯
}

/**
 * cc3短路诊断函数--较为重要涉及关灯严格审核
*/
void cc3_short_circuit_diagnosis(void)
{
	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] < mpq7210_uv_value)
	{
		e_MPQ7210_ERR.e_lamp.cc3.err_start_timer_flag = true;
		if((e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt >= FAULT_DURATION_MS) || (e_MPQ7210_ERR.e_lamp.cc3.condition_met != NO_FAULT))
		{
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt = 0;
			e_MPQ7210_ERR.e_lamp.cc3.condition_met = SHORT_FAULT;//设置cc3短路故障条件满足标志为真
			//后面这条后面可能可以删掉
			e_MPQ7210_ERR.e_lamp.cc3.short_err_flag = true;//设置cc3短路故障标志为真
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec = 0;
			e_MPQ7210_ERR.e_lamp.cc3.recov_start_timer_flag = false;//设置cc3故障恢复开始计时器
		}
		else
		{
			e_MPQ7210_ERR.e_lamp.cc3.recov_start_timer_flag = true;//设置cc3故障恢复开始计时器
			if((e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec >= FAULT_DURATION_MS) || (e_MPQ7210_ERR.e_lamp.cc3.condition_met == NO_FAULT))
			{
				e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec = 0;
				e_MPQ7210_ERR.e_lamp.cc3.condition_met = NO_FAULT;//设置cc3短路故障条件满足标志为假
				//后面可能可以删掉
				e_MPQ7210_ERR.e_lamp.cc3.short_err_flag = false;
				e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt = 0;//清零cc3故障持续时间计数器,此时目的时防止计数器溢出
				e_MPQ7210_ERR.e_lamp.cc3.err_start_timer_flag = false;
			}
		}
	}
}
/**
 * cc3开路诊断函数
*/
void cc3_open_circuit_diagnosis(void)
{
	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] >= (MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VIN] - delta_Buck))//CC3开路
	{
		e_MPQ7210_ERR.e_lamp.cc3.err_start_timer_flag = true;//设置cc3故障开始计时器
		if((e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt >= FAULT_DURATION_MS) || (e_MPQ7210_ERR.e_lamp.cc3.condition_met != NO_FAULT))
		{
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt = 0;//清零cc3故障持续时间计数器,此时目的时防止计数器溢出
			e_MPQ7210_ERR.e_lamp.cc3.condition_met = OPEN_FAULT;//设置cc3开路故障条件满足标志为真
			//后面这条后面可能可以删掉
			e_MPQ7210_ERR.e_lamp.cc3.open_err_flag = true;//设置cc3开路故障标志为真
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec = 0;
			e_MPQ7210_ERR.e_lamp.cc3.recov_start_timer_flag = false;//设置cc3故障恢复开始计时器
		}
	}
	else
	{
		e_MPQ7210_ERR.e_lamp.cc3.recov_start_timer_flag = true;//设置cc3故障恢复开始计时器
		if((e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec >= FAULT_DURATION_MS) || (e_MPQ7210_ERR.e_lamp.cc3.condition_met == NO_FAULT))
		{
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_dec = 0;
			e_MPQ7210_ERR.e_lamp.cc3.condition_met = NO_FAULT;
			//后面这条后面可能可以删掉
			e_MPQ7210_ERR.e_lamp.cc3.open_err_flag = false;
			e_MPQ7210_ERR.e_lamp.cc3.err_start_timer_flag = false;
			e_MPQ7210_ERR.e_lamp.cc3.counter_500ms_cnt = 0;//清零cc3故障持续时间计数器,此时目的时防止计数器溢出
		}
	}
}
/*
void cc3_open_circuit_diagnosis(void)
{
	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] >= (MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VIN] - delta_Buck))//CC3开路
	{
		//CC3开路时只有4种工况
		//工况1- LB_ON && HB_ON
		//工况2- LB_ON && HB_OFF
		//工况3- LB_OFF && HB_ON
		//工况4- LB_OFF && HB_OFF
		if((Input_key_arr[K_LB] == CH_LB_ON) && (Input_key_arr[K_HB] == CH_HB_ON))
		{
			//工况1
			e_MPQ7210_ERR.e_lamp.lhb.err_start_timer_flag = true;//设置lhb故障开始计时器
			
			//如果lhb故障持续时间超过500ms或者lhb故障条件满足，则进入故障状态
			if(e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_cnt >= FAULT_DURATION_MS || e_MPQ7210_ERR.e_lamp.lhb.condition_met == true)
			{
				e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_cnt = 0;//清零lhb故障持续时间计数器,此时目的时防止计数器溢出
				e_MPQ7210_ERR.e_lamp.lhb.condition_met = true;//设置lhb故障条件满足标志为真
				//感觉备注--这里可能因为抖动会导致档位异常，需要进一步测试
				if(e_MPQ7210_ERR.e_lamp.lhb.err_level == FAULT_LEVEL_LBOFF) //如果lhb故障等级为3级故障，则进行最终处理
				{
					//e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_DIS;//关闭远光灯
					//e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_DIS;//关闭近光灯
					e_MPQ7210_ERR.e_lamp.lb.condition_met = true;//设置lb故障条件满足标志为真
					e_MPQ7210_ERR.e_lamp.hb.condition_met = true;//设置hb故障条件满足标志为真
					e_MPQ7210_ERR.e_lamp.lb.open_err_flag = true;//设置lb开路故障标志为真
					e_MPQ7210_ERR.e_lamp.hb.open_err_flag = true;//设置hb开路故障标志为真
				}
				else if(e_MPQ7210_ERR.e_lamp.lhb.err_level == FAULT_LEVEL_HBOFF) //如果lhb故障等级为2级故障，则设置lhb故障等级为3级故障
				{
					e_MPQ7210_ERR.e_lamp.lhb.err_level = FAULT_LEVEL_LBOFF;//设置3级故障标志
					e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_EN;//开启远光灯
					e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_DIS;//关闭近光灯
				}
				else if(e_MPQ7210_ERR.e_lamp.lhb.err_level == FAULT_LEVEL_DEF)//如果lhb故障等级为默认值，则设置lhb故障等级为1级故障
				{
					e_MPQ7210_ERR.e_lamp.lhb.err_level = FAULT_LEVEL_HBOFF;//设置1级故障标志
					e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_DIS;//关闭远光灯
					e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_EN;//开启近光灯
				}
				
			}
			//定时器未到，执行先不报错功能
			else
			{
				e_MPQ7210_ERR.e_lamp.hb.open_err_flag = false;
				e_MPQ7210_ERR.e_lamp.lb.open_err_flag = false;
			}
		}
		else if((Input_key_arr[K_LB] == CH_LB_ON) && (Input_key_arr[K_HB] == CH_HB_OFF))
		{
			//工况2
		}
		else if((Input_key_arr[K_LB] == CH_LB_OFF) && (Input_key_arr[K_HB] == CH_HB_ON))
		{
			//工况3
		}
		else if((Input_key_arr[K_LB] == CH_LB_OFF) && (Input_key_arr[K_HB] == CH_HB_OFF))
		{
			//工况4
		}
	}
	else//CC3没开路
	{
		//CC3没开路时只有3种点灯工况
		//工况1- LB_ON && HB_ON
		//工况2- LB_ON && HB_OFF
		//工况3- LB_OFF && HB_ON
		    
		//每个点灯工况可能存在以下几种可能
		//可能1- 从始至终没有故障，判断条件为e_MPQ7210_ERR.e_lamp.lhb.condition_met == false
		//可能2- 关闭远光后故障消失，判断条件为e_MPQ7210_ERR.e_lamp.lhb.err_level == FAULT_LEVEL_HBOFF
		//可能3- 关闭远光开近光后故障没有消失，改为关闭近光开启远光，判断条件为e_MPQ7210_ERR.e_lamp.lhb.err_level == FAULT_LEVEL_LBOFF
		if((Input_key_arr[K_LB] == CH_LB_ON) && (Input_key_arr[K_HB] == CH_HB_ON))
		{
			//曾经确诊过故障，后故障消失
			if(e_MPQ7210_ERR.e_lamp.lb.condition_met || e_MPQ7210_ERR.e_lamp.hb.condition_met || e_MPQ7210_ERR.e_lamp.lhb.condition_met)
			{
				if(e_MPQ7210_ERR.e_lamp.lb.counter_500ms_dec >= FAULT_DURATION_MS)
				{
					recoverLowBeam();
				}
				if(e_MPQ7210_ERR.e_lamp.hb.counter_500ms_dec >= FAULT_DURATION_MS)
				{
					recoverHighBeam();
				}
				if(e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_dec >= FAULT_DURATION_MS)
				{
					e_MPQ7210_ERR.e_lamp.lhb.condition_met = false;//清零lhb故障
					e_MPQ7210_ERR.e_lamp.lhb.counter_500ms_dec = 0;
					e_MPQ7210_ERR.e_lamp.lhb.recov_start_timer_flag = false;
					e_MPQ7210_ERR.e_lamp.lhb.err_start_timer_flag = false;
					recoverLowBeam();
					recoverHighBeam();
				}
				//近光确诊，属于可能3
				if(e_MPQ7210_ERR.e_lamp.lb.condition_met)
				{
					e_MPQ7210_ERR.e_lamp.lb.recov_start_timer_flag = true;//设置lb故障恢复开始计时器
				}
				//远光确诊，属于可能2
				if(e_MPQ7210_ERR.e_lamp.hb.condition_met)
				{
					e_MPQ7210_ERR.e_lamp.hb.recov_start_timer_flag = true;//设置hb故障恢复开始计时器
				}
				//远近光均确诊故障
				if(e_MPQ7210_ERR.e_lamp.lb.condition_met && e_MPQ7210_ERR.e_lamp.hb.condition_met)
				{
					e_MPQ7210_ERR.e_lamp.lhb.recov_start_timer_flag = true;//设置lhb故障恢复开始计时器
				}
			}
			//至始至终无故障出现
			else
			{
				manage_lhb_fault();
			}
		}
		else if((Input_key_arr[K_LB] == CH_LB_ON) && (Input_key_arr[K_HB] == CH_HB_OFF))
		{
			//工况2
		}
		else if((Input_key_arr[K_LB] == CH_LB_OFF) && (Input_key_arr[K_HB] == CH_HB_ON))
		{
			//工况3
		}
	}
}
*/

/**
 * 故障分析函数
 * 远近光故障等级区分：1级故障：远近光有故障未锁定为LB还是HB；
*/
void c_analyze_Fault(void)
{
	cc3_open_circuit_diagnosis();
	
}

uint8_t Diag_Scan_Setp = 0;  // 诊断扫描步数
int temp_flag = 0;

// 定义一个诊断结构变量
mAPP_DIAG mApp_diag;//准备把它移动到app_bin


uint8_t QuckFBFLAG = firstTimeUsed;//初始化定义一个快速反馈标志
sstTimerIndex_t SPI_WaitREAD_Filer;//等待CC稳定用的定时器索引
sstTimerIndex_t SPI_READ_Filer;//SPI周期定时器索引
void AutoFB(void);
void WaitCCSetup(void);
void faultControEN(void);

void analyze_Fault(void)
{
	//cc2诊断
	if(MPQ7210_ADC_Registers[BUCK1].real_buck_value[BUCK2VOUT] >= (MPQ7210_ADC_Registers[BUCK1].real_buck_value[BUCK2VIN] - delta_Buck))//CC2开路
	{
		if((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_TL] == CH_TL_ON))
		{
			//MPQ7210_ERR_t.cc2_open_flag = true;
		}
	}
	else
	{
		//MPQ7210_ERR_t.cc2_open_flag = false;
	}

	if (MPQ7210_ADC_Registers[BUCK1].real_buck_value[BUCK2VOUT] <= mpq7210_uv_value)//CC2短路
	{
		if((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_TL] == CH_TL_ON))
		{
			//MPQ7210_ERR_t.cc2_short_flag = true;
		}
	}
	else
	{
		//MPQ7210_ERR_t.cc2_short_flag = false;
	}
	//cc3诊断
	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] >= (MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VIN] - delta_Buck))//CC3开路
	{
		if((Input_key_arr[K_HB] == CH_HB_ON) && (Input_key_arr[K_LB] == CH_LB_ON))
		{
			//MPQ7210_ERR_t.cc3_try_flag = true;
			e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_DIS;
			
		}
		if((Input_key_arr[K_HB] == CH_HB_OFF) && (Input_key_arr[K_LB] == CH_LB_ON))
		{
			//MPQ7210_ERR_t.cc3_try_flag = false;
			//MPQ7210_ERR_t.cc3_lb_open_flag = true;
		}
	}
	else
	{
		if(1)//MPQ7210_ERR_t.cc3_try_flag == true)
		{
			//MPQ7210_ERR_t.cc3_try_flag = false;
			//MPQ7210_ERR_t.cc3_hb_open_flag = true;
		}
		else
		{
			//MPQ7210_ERR_t.cc3_hb_open_flag = false;
			//MPQ7210_ERR_t.cc3_hb_short_flag = false;
		}
	}

	if (MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] <= mpq7210_uv_value)//CC3短路
	{
		if((Input_key_arr[K_HB] == CH_HB_ON) || (Input_key_arr[K_LB] == CH_LB_ON))
		{
			//MPQ7210_ERR_t.cc3_short_flag = true;
		}
	}
	else
	{
		//MPQ7210_ERR_t.cc3_short_flag = false;
	}
}

/**
 * @brief 根据配置信息向MPQ7210的ADC发送写命令
 *
 * 根据用户按下的按键，检查是否需要向MPQ7210的ADC发送写命令。
 * 如果是DRL、PL或TL键，则向MPQ7210的ADC1发送写命令；
 * 如果是HB或LB键，则向MPQ7210的ADC2发送写命令。
 */
void perCfgVRegDiag(void)
{
	// 检查是否按下DRL、PL或TL键
	if((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_TL] == CH_TL_ON))
	{
		// 如果是，则向MPQ7210的ADC1发送写命令
		MPQ7210_adc_send(U1_MPQ7210, WRITE_BIT, ADC_CmdTable, MPQ7210_ADC_Registers, ADC_length);
	}
	// 检查是否按下HB或LB键
	if((Input_key_arr[K_HB] == CH_HB_ON) || (Input_key_arr[K_LB] == CH_LB_ON))
	{
		// 如果是，则向MPQ7210的ADC2发送写命令
		MPQ7210_adc_send(U2_MPQ7210, WRITE_BIT, ADC_CmdTable, MPQ7210_ADC_Registers, ADC_length);
	}
}

void check_FB(void)
{
	if(0)//if((MPQ7210_ERR_t.cc3_open_flag == false) && (MPQ7210_ERR_t.cc3_short_flag == false))
	{
		if(Input_key_arr[K_HB] == CH_HB_ON) 
		{
			E11_EN_FB2_HB_FB_ENABLE;//HB FB2
		}
		else 
		{
			E11_EN_FB2_HB_FB_DISABLE;
		}
		if(Input_key_arr[K_LB] == CH_LB_ON)  
		{
			D1_EN_FB1_LB_FB_ENABLE;//LB FB1
		}
		else 
		{
			D1_EN_FB1_LB_FB_DISABLE;
		}
	}
	else 
	{
		if(0)//if(Input_key_arr[K_HB] == CH_HB_ON && (MPQ7210_ERR_t.cc3_open_flag == true || MPQ7210_ERR_t.cc3_short_flag == true)) //HB FB2
		{
			E11_EN_FB2_HB_FB_DISABLE;
		}
		if(Input_key_arr[K_HB] == CH_HB_OFF)
		{
			E11_EN_FB2_HB_FB_DISABLE;
		}
		if(0)//if(Input_key_arr[K_LB] == CH_LB_ON && (MPQ7210_ERR_t.cc3_open_flag == true || MPQ7210_ERR_t.cc3_short_flag == true))  //LB FB1
		{
			D1_EN_FB1_LB_FB_DISABLE;
			
		}
		if(Input_key_arr[K_LB] == CH_LB_OFF)
		{
			D1_EN_FB1_LB_FB_DISABLE;
		}
	}
	if(0)//if((MPQ7210_ERR_t.cc2_open_flag == false) && (MPQ7210_ERR_t.cc2_short_flag == false))
	{
		if((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON)) 
		{
			E10_EN_FB_DRL_PL_ENABLE;//DRL PL  E10
		}
		else 
		{
			E10_EN_FB_DRL_PL_DISABLE;
		}
		if(Input_key_arr[K_TL] == CH_TL_ON)  
		{
			D0_EN_FB3_TL_FB_ENABLE;//LB FB1
		}
		else 
		{
			D0_EN_FB3_TL_FB_DISABLE;
		}
	}
	else
	{
		if(0)//if(((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON)) && (MPQ7210_ERR_t.cc2_open_flag == true || MPQ7210_ERR_t.cc2_short_flag == true))  //DRL PL  E10
		{
			E10_EN_FB_DRL_PL_DISABLE;
		
		}
		if((Input_key_arr[K_DRL] == CH_DRL_OFF) && (Input_key_arr[K_PL] == CH_PL_OFF) )
		{
			E10_EN_FB_DRL_PL_DISABLE;
		}
		if(0)//if(Input_key_arr[K_TL] == CH_TL_ON && (MPQ7210_ERR_t.cc2_open_flag == true || MPQ7210_ERR_t.cc2_short_flag == true)) //TI FB3
		{
			D0_EN_FB3_TL_FB_DISABLE;
			
		}
		if(Input_key_arr[K_TL] == CH_TL_OFF)
		{
			D0_EN_FB3_TL_FB_DISABLE;
		}
	}
}


/**
 * @brief 故障控制启用函数
 *
 * 将各个灯光（远光灯、近光灯、日间行车灯、示宽灯、转向灯）的故障控制标志位设置为启用状态。
 */
void faultControEN(void)
{
	e_LAMP_CMD.highBeam.faultControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.lowBeam.faultControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.daytime.faultControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.position.faultControl = LIGHT_CONTROL_EN;
	e_LAMP_CMD.turn.faultControl = LIGHT_CONTROL_EN;
}


void AutoFB(void)
{
	if(Input_key_arr[0] == CH_HB_ON) 
	{
		E11_EN_FB2_HB_FB_ENABLE;//HB FB2
	}
	else 
	{
		E11_EN_FB2_HB_FB_DISABLE;
	}
	if(Input_key_arr[1] == CH_LB_ON)  
	{
		D1_EN_FB1_LB_FB_ENABLE;//LB FB1
	}
	else 
	{
		D1_EN_FB1_LB_FB_DISABLE;
	}
	if(Input_key_arr[4] == CH_TL_ON) 
	{
		D0_EN_FB3_TL_FB_ENABLE;
	}
	else 
	{
		D0_EN_FB3_TL_FB_DISABLE;
	}
	if(((Input_key_arr[2] == CH_DRL_ON) || (Input_key_arr[3] == CH_PL_ON)) )  //DRL PL  E10
	{
		E10_EN_FB_DRL_PL_ENABLE;
	}
	if((Input_key_arr[2] == CH_DRL_OFF) && (Input_key_arr[3] == CH_PL_OFF) )
	{
		E10_EN_FB_DRL_PL_DISABLE;
	}
}

void Diagnostic_fault_Tesk(void)
{
	switch(Diag_Scan_Setp)
	{
		case 0:
			Diag_Scan_Setp = 1;
			break;
		case 1:
			al_Bin_value_funtion();//将EEPROM的BIN的档位赋给实时变量gU16_BIN_Value_normal
			//al_NTC_value_funtion();//NTC档位赋值gU16_NTC_Value_normal
			/*
			if(sl_IsTimerExceed(SPI_WaitREAD_Filer))
			{
				sl_RefreshTimer(SPI_WaitREAD_Filer);
				QuckFBFLAG = DisableUse;
				SPI_READ_Filer = sl_BaseTimer_GreatSoftTimer();//获取等待SPI周期读取定时器索引
				sl_SetTimerPeriod(SPI_READ_Filer, SPI_CYC_FILTER_TIME);//由于SPI采用堵塞模式，后续此项周期评估删除，亦或转为500ms持续时间判断用的时钟
			}
			if(QuckFBFLAG)//CC未稳定前执行快速反馈
			{
				sl_RefreshTimer(SPI_READ_Filer);
				if(QuckFBFLAG == firstTimeUsed)
				{
					QuckFBFLAG = secondTimeUsed;
					WaitCCSetup();//启动CC等待定时器
				}
				AutoFB();
			}
			else//CC稳定后基于点灯信息对CC进行配置
			{
				perCfgVRegDiag();
				faultControEN();
				analyzeFault();
				if(LightShowMode == LIGHT_SHOW_MODE_NORMAL)
				{
					check_FB();//QuckFBFLAG赋值逻辑需要补充修改
				}
				else
				{
					AutoFB();
				}
				
			}
			*/
			Diag_Scan_Setp = 2;
			break;
		case 2:
			Diag_Scan_Setp = 0;
			break;
		default:
			break;
	}
}

void WaitCCSetup(void)
{
	//memset(&MPQ7210_ERR_t, 0, sizeof(MPQ7210_ERR_t));//清空MPQ7210故障标志位准备读取
	SPI_WaitREAD_Filer = sl_BaseTimer_GreatSoftTimer();//获取等待CC定时器索引
    sl_SetTimerPeriod(SPI_WaitREAD_Filer, SPI_READ_FILTER_TIME);//配置cc稳定等待时长
}


