/*
 * Diagnostic_fault.h
 *
 *  Created on: 2023骞�11鏈�16鏃�
 *      Author: Administrator
 */

#ifndef DIAGNOSTIC_FAULT_H_
#define DIAGNOSTIC_FAULT_H_
#include "LLD_config.h"
#include "sl_softtimer.h"
#include "app_bin.h"
#include "stdbool.h"

#define DIAG_FILTER_TIME  10
#define DisableUse      0
#define firstTimeUsed   1
#define secondTimeUsed  2
//定义点灯后延时100ms等待稳定后开始读电压
#define SPI_READ_FILTER_TIME 100
//定义周期读SPI故障的周期为20ms---时间TBD
#define SPI_CYC_FILTER_TIME 20

typedef uint8_t reg_addr_t;
typedef uint16_t reg_data_t;
#define FAULT_DURATION_MS (500)//故障存在时间500ms
#define FAULT_LEVEL_DEF   (0)//默认
#define FAULT_LEVEL_HBOFF (1)//远近光1级故障
#define FAULT_LEVEL_LBOFF (2)//远近光2级故障
// 定义枚举类型，用来存放是无故障还是开路故障还是短路故障
typedef enum {
    NO_FAULT = 0,
    OPEN_FAULT = 1, 
    SHORT_FAULT = 2
} m_BUCK_FAULT;
// 定义基础结构体，包含错误标志、启动定时器标志、500ms计数器和条件满足标志
typedef struct {
    bool open_err_flag;
    bool short_err_flag;
    bool ntc_err_flag;
    bool rbin_err_flag;
    bool err_start_timer_flag;
	bool recov_start_timer_flag;
    uint16_t counter_500ms_cnt;
	uint16_t counter_500ms_dec;
    uint8_t err_level;
    m_BUCK_FAULT condition_met;
} m_BUCK_BASE;
// 定义具有特定前缀的结构体
typedef struct {
    m_BUCK_BASE lb; // lb_前缀的基础结构体
    m_BUCK_BASE hb; // hb_前缀的基础结构体
    m_BUCK_BASE drl; // drl_前缀的基础结构体
    m_BUCK_BASE pl; // pl_前缀的基础结构体
    m_BUCK_BASE tl; // tl_前缀的基础结构体
	m_BUCK_BASE lhb; // lhb_前缀的基础结构体
    m_BUCK_BASE cc3; // cc3_含近光和远光
    m_BUCK_BASE cc2; // cc2_含日行，位置，转向
} m_BUCK_ERR_LAMP;
// 定义其他没有特定前缀的结构体
typedef struct {
    bool nte_err_flag;
    bool spi_err_flag;
    bool kl30_uv_err_flag;
    bool kl30_ov_err_flag;
} m_BUCK_ERR_OTHER;
/**
 * 故障处理
 * A09前组合灯低配_项目软硬件接口说明 _V06
 * 8_功能故障诊断定义
*/
typedef struct {
    m_BUCK_ERR_LAMP  e_lamp; // 嵌套具有特定前缀的结构体
    m_BUCK_ERR_OTHER e_other; // 嵌套其他没有特定前缀的结构体
} m_BUCK_ERR;
extern m_BUCK_ERR e_MPQ7210_ERR;

typedef struct{
	uint8_t U8_open_VOL;
	uint8_t U8_short_VOL;
	uint8_t U8_over_VOL;
	uint8_t U8_under_VOL;
	uint8_t U8_overcurrent;
	uint8_t U8_undercurrent;
}mVOLTAGE_DIAG,*pVOLTAGE_DIAG;

typedef struct{
	mVOLTAGE_DIAG U8_NTC[3];
	mVOLTAGE_DIAG U8_BIN[3];
	uint8_t U8_Internal_temperature;//暂时没用到
	mVOLTAGE_DIAG U8_BOOST[2];
	mVOLTAGE_DIAG U8_BUCK[2][2];
	uint16_t gU16_BIN_Value_normal[3];//实时存放BIN的档位  0到5 6-s 7-o
	uint16_t gU16_NTC_Value_normal[3];//实时存放NTC的档位  0到1
}mAPP_DIAG,*pAPP_DIAG;

extern mAPP_DIAG mApp_diag;
extern sstTimerIndex_t SPI_READ_Filer;

extern uint8_t QuckFBFLAG;
extern void sl_Diagnostic_init(void);
extern void deal_spidata(void);
extern void perCfgVRegDiag(void);
extern void analyze_Fault(void);
extern void checkAndProcess(void);
extern void Diag_deal(void);
extern void Diagnostic_fault_Tesk(void);
extern void WaitCCSetup(void);
extern void Vehicle_Diagnostic_fun(void);
extern void Fault_Trigger_Check(void);

#endif /* DIAGNOSTIC_FAULT_H_ */
