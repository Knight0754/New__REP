/*
 * sl_softtimer.h
 *
 *  Created on: 2023��11��7��
 *      Author: gz06488
 */

#ifndef SL_SOFTTIMER_H_
#define SL_SOFTTIMER_H_

#include <stdint.h>

#define MAX_TIMECOUNTER_NUM 		(uint16_t)(0xFFFFu)
#define MIN_TIMECOUNTER_NUM 		(uint16_t)(0x0000u)
#define  SL_BASeTIMER_MAX     200u

typedef uint8_t sstTimerIndex_t;
extern uint16_t gU16_Millisecond;

typedef struct _SL_TIMER {
	uint16_t stimer;  //cnt
	uint16_t period;  //dst
	uint16_t ticks;   //cur
}SL_TIMER_t, *pSL_TIMER_t;

extern void sl_BaseTimerInit(void);
extern uint16_t GetCurTime(void);
extern sstTimerIndex_t sl_BaseTimer_GreatSoftTimer(void);
extern void sl_TimeBase1msProcess(void);
extern uint8_t IsTimeOver(uint16_t OldTimer, uint16_t ThrottleTimeMs);
extern uint8_t sl_IsTimerExceed(sstTimerIndex_t index);
extern void sl_RefreshTimer(sstTimerIndex_t index);
extern void sl_SetTimerPeriod(sstTimerIndex_t index, uint16_t period_ms);

#endif /* SL_SOFTTIMER_H_ */
