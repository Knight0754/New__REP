/*
 * app_bin.h
 *
 *  Created on: 2023�?11�?9�?
 *      Author: gz06488
 */

#ifndef APP_BIN_H_
#define APP_BIN_H_

#include "LLD_config.h"
#include "clockMan1.h"
#include "Cpu.h"
#include "adc_driver.h"
#include <string.h>
#include "app_eeprom.h"
#include "sl_softtimer.h"
#include "Diagnostic_fault.h"

#define ADC_FILTER_TIME  10 //ADC�?询周�?10ms
#define adcMax  4095    //12bit分辨率最多分辨率
#define ADC_VREFH       (5.0f) //5V
#define ADC_VREFL       (0.0f) //0V

#define ADC0_CHANNEL_NUMBER      10 //ADC采集口的�?�?
#define ADC0_BUFF_SIZE           10 //每个ADC采集口采集的次数

#define LB_NTC_SHORT 541
#define LB_NTC_OPEN  3822

//用于m_adc_info结构体的存放指示
#define n_CV1 	    0
#define n_CV2   	1
#define n_BIN1      0
#define n_BIN2      1
#define n_BIN3      2
#define n_NTC1      0
#define n_NTC2      1
#define n_NTC3      2
//以下为CC的ADC检测�?�留
#define num_CC      4
#define n_CC1       0
#define n_CC2       1
#define n_CC3       2
#define n_CC4       3

//BIN档位阈�?
#define BINshort     487
#define BINOpen      3440
#define BINLeve1_L   (BINshort + 1)
#define BINLeve1_H   1149
#define BINLeve2_L   (BINLeve1_H + 1)
#define BINLeve2_H   1820
#define BINLeve3_L   (BINLeve2_H + 1)
#define BINLeve3_H   2457
#define BINLeve4_L   (BINLeve3_H + 1)
#define BINLeve4_H   2942
#define BINLeve5_L   (BINLeve4_H + 1)
#define BINLeve5_H   (BINOpen - 1)
//定义了RBIN枚举
typedef enum
{
	LEVEL1 = 1u,
	LEVEL2,
	LEVEL3,
	LEVEL4,
	LEVEL5,
	RBIN_short,
	RBIN_open,
}RBINStatus;

#define VOL_PE            50   //0.1V涓哄崟浣�?
#define VOL_PE_ADvale  	  4
#define VOL_7_0V_UP  	  498  //560	//鍑忛�?   璁捐�?6.8V
#define VOL_10_0V_DOWN    722 //744  //	鍑忛�? 780 璁捐�?9.8V
#define VOL_18_5V_DOWN  	1355

#define VOL_8_0V_AD     580
#define VOL_9_0V_AD     650
#define VOL_10_0V_AD    722

#define NTC130_UP  	 	   356
#define NTC130_DOWN  	   NTC130_UP+80  //AD鍊�80锛屽洖鎵�?10搴�

/* 内部NTC版本 */
#define NTC_30_AD    3924    // 4.79V 对应的AD值，模拟环境下30°C对应的AD值
#define NTC100_AD    600     // 理论上100°C, 实际测量105°C对应的AD值
#define NTC110_AD    485     // 理论上110°C, 实际测量115°C对应的AD值
#define NTC150_AD    238     // 0.292V 对应的AD值，模拟环境下150°C对应的AD值
/* 外部NTC版本 */
#define NTC_30_AD    3924    // 4.79V 对应的AD值，模拟环境下30°C对应的AD值
#define NTC110_AD    485     // 理论上110°C, 实际测量115°C对应的AD值
#define NTC120_AD    437     // 理论上120°C, 实际测量120°C对应的AD值
#define NTC125_AD    394     // 理论上125°C, 实际测量125°C对应的AD值
#define NTC150_AD    238     // 0.292V 对应的AD值，模拟环境下150°C对应的AD值

extern uint16_t KL30_buff;
extern uint8_t cnt_adc;

#define ADC_CHANNEL_NUMBER     10
#define ADC_BUFF_SIZE          10

typedef enum
{
	NTC_set130_down=0u,
	NTC_set130_up,
}NTCStatus;

typedef enum
{
	K30_shorV = 0u,
	KL30_7_0todonw,
	KL30_7_0to10_0V,
	KL30_10_0to18_5V,
	KL30_7_0to8_5V,
	KL30_8_5to10_0V,
	KL30_7_0to18_5V,
	KL30_18_5V_up,
}Vk30Status;

typedef enum
{
	A6_ADC_ECU_NTC=0,
	A7_ADC_CV2_CV,
	B2_ADC_RBIN3_TBD,
	B3_ADC_RBIN2_TBD,
	C2_ADC_KL30,
	C3_ADC_NTC1_TBD,
	C14_ADC_RBIN1_TBD,
	C15_ADC_NTC3_TBD,
	C16_ADC_NTC2_TBD,
	C17_ADC_CV1_CV,
}ADC_CH;


#define BIN_COUNTNUM      3
#define BINLEVEL          7
#define KL30LEVEL         4//4档状�? 1:>10v; 2: 9-10V; 3:7-9V; 4:<7V;
#define CURVE_LEVELmode   3
#define BOOST_NUM   2
#define BUCK_NUM    4
#define NTC_NUM     3
#define NTCLEVEL    2
#define A_LEVEL    0
#define B_LEVEL    1
#define C_LEVEL    2
#define D_LEVEL    5
//#define ADC_SEC

typedef struct
{
	uint16_t ADC_ECU_NTC[ADC_BUFF_SIZE];
	uint16_t ADC_CV2_CV[ADC_BUFF_SIZE];
	uint16_t ADC_RBIN3[ADC_BUFF_SIZE];
	uint16_t ADC_RBIN2[ADC_BUFF_SIZE];
	uint16_t ADC_KL30[ADC_BUFF_SIZE];
	uint16_t ADC_NTC1[ADC_BUFF_SIZE];
	uint16_t ADC_RBIN1[ADC_BUFF_SIZE];
	uint16_t ADC_NTC3[ADC_BUFF_SIZE];
	uint16_t ADC_NTC2[ADC_BUFF_SIZE];
	uint16_t ADC_CV1_CV[ADC_BUFF_SIZE];

}mADC_buff,*pADC_buff;
typedef struct
{
	uint8_t NTC_uvp;
	uint8_t NTC_ovp;

}mDIG_STA,*pDIG_STA;

typedef struct
{
// 	A=1  B=2  C=3
	uint8_t Vin_level;
	uint8_t InternalNTC_level;
	uint8_t ExternalNTC_level[CURVE_LEVELmode];
	mDIG_STA InternalNTC[1];
	mDIG_STA ExternalNTC[CURVE_LEVELmode];

}mCURVE_STA,*pCURVE_STA;

typedef struct
{
	uint8_t BIN_open[BIN_COUNTNUM];
	uint8_t BIN_short[BIN_COUNTNUM];
	uint16_t gU16_BinValue_level[BIN_COUNTNUM][BINLEVEL];
	uint8_t gU16_BinValue_eeprom[BIN_COUNTNUM];//用于存放BIN的档�?
	uint8_t gU16_BinValue_Leve5_eeprom[BIN_COUNTNUM];
	uint16_t gU16_BinValue[BIN_COUNTNUM];//用于存放3个BIN电阻的adc�?
	uint16_t gU16_Bin_Dig[BIN_COUNTNUM];

	//uint8_t KL30_open;
	//uint8_t KL30_short;
	uint16_t gU16_KL30Value;//用于存放KL30的adc�?
	uint16_t KL30_Level[KL30LEVEL];//电压等级标�??-没使用到


	uint16_t gU16_NTC_inner_Value;//用于存放板级NTC的adc�?
	uint16_t NTC_Level[NTC_NUM];//用于存放3个NTC电阻的adc�?
	uint16_t NTC_Value_Level[NTC_NUM][NTCLEVEL];//用于存放3个NTC电阻的档�?
}mADC_STA,*pADC_STA;

typedef struct{
	uint8_t NTCBIN_open;
	uint8_t NTCBIN_short;
	uint16_t uint16_t[NTC_NUM+1];
	uint16_t gU16_NTCBIN_Value_normal_temper[NTC_NUM+1];
	uint16_t gU16_NTCBIN_Value_disnormal_temper[NTC_NUM+1];
	uint16_t gU16_NTCBIN_Level[NTC_NUM];

}mCOMBINE_NTCBIN,*pCOMBINE_NTCBIN;

typedef struct{
	 uint16_t GetKL30_Result;
	 //uint16_t GetHSD_Result;
	 uint16_t GetECUNTC_Result;
	 uint16_t GetCV_Result[BOOST_NUM];
	 //uint16_t GetCC_Result[BUCK_NUM];
	 uint16_t GetNTC_Result[NTC_NUM];
	 uint16_t GetBIN_Result[BIN_COUNTNUM];

}mADC_INFO,*pmADC_INFO;

//定义一�?结构体，存放NTC的bin和相关温�?
typedef struct{
	 uint8_t Bin[NTC_NUM];
	 uint8_t Temp;
}mCONVERT_INFO,*pCONVERT_INFO;

typedef struct{
	uint8_t instance;
	uint8_t ch_index;
	const adc_chan_config_t *ch_cfg;
}ADC_SCAN_INFO,*pADC_SCAN_INFO;

extern uint8_t gu8_curve_max[CURVE_LEVELmode];
extern mCONVERT_INFO mconvert_sta;
extern mADC_STA  adc_sta;
extern mADC_INFO  adc_info;
extern void sl_adc_init(void);
extern uint8_t Get_KL30Sts(void);
extern uint8_t Get_mode_KL30Sts(void);
extern uint8_t Get_LEVEL_KL30Sts(void);

extern unsigned char  Adc_Buff_cnt;
extern unsigned char  Adc_Scan_Index;
extern unsigned int Adc_TempBuff[ADC_CHANNEL_NUMBER][ADC_BUFF_SIZE];
extern const ADC_SCAN_INFO Adc_ChannelList[ADC_CHANNEL_NUMBER];
extern mCURVE_STA curve_sta;

extern void ADManage_Tesk();
extern void m_adc_info(void);
extern uint8_t Curve_fun_process(uint8_t NTC_num);
extern void al_Bin_value_funtion(void);
extern void al_NTC_value_funtion(void);
extern uint8_t sl_analyze_BIN_NTC(void);
extern uint8_t SL_ADC0_GetChannelVal(uint8_t channel);
extern uint8_t LLD_ADC0_MeasureProcess(void);
//extern uint32_t BubbleSort( uint16_t *a, uint8_t n);
extern void sl_adc_Tesk(void);
extern void get_BIN_Val(void);
//extern void al_Bin_value_funtion(void);

#endif /* APP_BIN_H_ */
