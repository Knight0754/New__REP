/*
 * hal_pwm.h
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#ifndef HAL_PWM_H_
#define HAL_PWM_H_

void ftmTimer_init(void);

#endif /* HAL_PWM_H_ */
