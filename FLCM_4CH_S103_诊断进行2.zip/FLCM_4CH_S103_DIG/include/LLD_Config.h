/*
 * LLD_Config.h
 *
 *  Created on: 2023年12月20日
 *      Author: gz06488
 */

#ifndef LLD_CONFIG_H_
#define LLD_CONFIG_H_

#include "pin_mux.h"
#include "stdbool.h"
#include "pins_gpio_hw_access.h"
#if defined(FEATURE_PINS_DRIVER_USING_SIUL2)
#include "pins_siul2_hw_access.h"
#elif defined(FEATURE_PINS_DRIVER_USING_PORT)
#endif

#define true 1
#define false 0

//=========锟斤拷准锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷==========
#define E3_SW_TL_GPIO             PTE
#define E3_SW_TL_PIN              3U
#define E9_SW_FTL_IN1_GPIO        PTE//预锟斤拷锟接憋拷锟斤拷锟斤拷锟斤拷
#define E9_SW_FTL_IN1_PIN         9U
#define D7_SW_LB_GPIO             PTD
#define D7_SW_LB_PIN              7U
#define C9_SW_DRL_GPIO            PTC
#define C9_SW_DRL_PIN             9U
#define C8_SW_PL_GPIO             PTC
#define C8_SW_PL_PIN              8U
#define A13_SW_HB_GPIO            PTA
#define A13_SW_HB_PIN             13U
#define E8_SW_IN_FB4_GPIO         PTE
#define E8_SW_IN_FB4_PIN          8U
#define B5_SW_IN_FB5_GPIO         PTB
#define B5_SW_IN_FB5_PIN          5U
#define D2_SW_FS_IC1_2_GPIO       PTD
#define D2_SW_FS_IC1_2_PIN        2U
//===========锟斤拷准锟斤拷锟斤拷SPI============
#define E1_SPI_BUCK_MISO_GPIO        PTE
#define E1_SPI_BUCK_MISO_PIN         1U
#define E0_SPI_SCK_GPIO              PTE
#define E0_SPI_SCK_PIN               0U
#define C5_SPI_CS1_GPIO              PTC
#define C5_SPI_CS1_PIN               5U
#define E6_SPI_CS2_GPIO              PTE
#define E6_SPI_CS2_PIN               6U
#define E2_SPI_BUCK_MOSI_GPIO        PTE
#define E2_SPI_BUCK_MOSI_PIN         2U
//=========锟斤拷准锟斤拷锟斤拷锟斤拷压锟斤拷锟�==========
#define D6_EN_CV1_GPIO                   PTD
#define D6_EN_CV1_PIN                    6U
#define D5_EN_CV2_GPIO                   PTD
#define D5_EN_CV2_PIN                    5U
#define A0_EN_CV3_4_GPIO                 PTA
#define A0_EN_CV3_4_PIN                  0U
#define CO_PWM_reference_CV1_GPIO        PTC
#define CO_PWM_reference_CV1_PIN         0U
#define C1_PWM_reference_CV2_GPIO        PTC
#define C1_PWM_reference_CV2_PIN         1U
#define B4_PWM_RT_CV1_GPIO               PTB
#define B4_PWM_RT_CV1_PIN                4U
#define E7_PWM_RT_CV2_GPIO               PTE
#define E7_PWM_RT_CV2_PIN                7U
//==============锟斤拷准锟斤拷锟斤拷锟斤拷锟诫开锟斤拷PMOS===========
#define D16_EN_PMOS_GPIO    	     PTD
#define D16_EN_PMOS_PIN       		 16U
//==============锟斤拷准锟斤拷锟斤拷锟斤拷源锟斤拷锟�===========
#define E4_EN_LDO_BUCK_GPIO    	     PTE
#define E4_EN_LDO_BUCK_PIN     		 4U
#define E5_EN_LDO_LOADER_GPIO        PTE
#define E5_EN_LDO_LOADER_PIN         5U
//==============锟斤拷准锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷===========
//锟剿达拷锟斤拷锟斤拷锟侥诧拷锟斤拷锟斤拷锟斤拷锟矫ｏ拷锟斤拷锟斤拷喜锟斤拷纸锟斤拷锟斤拷源锟�
#define E10_EN_FB_DRL_PL_GPIO      PTE
#define E10_EN_FB_DRL_PL_PIN       10U
#define D1_EN_FB1_LB_FB_GPIO         PTD
#define D1_EN_FB1_LB_FB_PIN          1U
#define E11_EN_FB2_HB_FB_GPIO        PTE
#define E11_EN_FB2_HB_FB_PIN         11U
#define D0_EN_FB3_TL_FB_GPIO         PTD
#define D0_EN_FB3_TL_FB_PIN          0U

//#define EN_OFF_LH_MCU_S_GPIO	0	//PTD
#define EN_OFF_LH_MCU_S_PIN		0//	4U
//============锟斤拷准锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟�==============
//锟剿达拷锟斤拷锟斤拷锟侥诧拷锟斤拷锟斤拷锟斤拷锟矫ｏ拷锟斤拷锟斤拷喜锟斤拷纸锟斤拷锟斤拷源锟�
#define E8_EN_FB4_Falut_GPIO        PTE
#define E8_EN_FB4_Falut_PIN         8U
#define E9_EN_FB5_Falut_GPIO        PTE
#define E9_EN_FB5_Falut_PIN         9U
#define D2_EN_FB_BUCK_Falut_GPIO    PTD
#define D2_EN_FB_BUCK_Falut_PIN     2U
//===========锟斤拷准锟斤拷锟斤拷锟斤拷锟絃ED使锟斤拷 MOS锟斤拷==========
//锟剿达拷锟斤拷锟斤拷锟侥诧拷锟斤拷锟斤拷锟斤拷锟矫ｏ拷锟斤拷锟斤拷撇锟斤拷纸锟斤拷锟斤拷源锟�
#define B12_EN_LED1_HB_GPIO  		 PTB
#define B12_EN_LED1_HB_PIN           13U
#define B13_EN_LED2_LB_GPIO  		 PTB
#define B13_EN_LED2_LB_PIN           12U
#define A11_EN_LED5_TL_GPIO         PTA
#define A11_EN_LED5_TL_PIN           11U
#define A12_EN_LED6_DRL_PL_GPIO         PTA
#define A12_EN_LED6_DRL_PL_PIN			 12U
//=============锟斤拷准锟斤拷锟斤拷BUCK锟斤拷锟绞癸拷锟�==============
#define A2_EN_BUCK1_EN1_GPIO          PTA
#define A2_EN_BUCK1_EN1_PIN           2U
#define A10_EN_BUCK1_EN2_GPIO         PTA
#define A10_EN_BUCK1_EN2_PIN          10U
#define D3_EN_BUCK2_EN1_GPIO          PTD
#define D3_EN_BUCK2_EN1_PIN           3U
#define A3_EN_BUCK2_EN2_GPIO          PTA
#define A3_EN_BUCK2_EN2_PIN           3U
#define EN_ON_LH_MCU_S_GPIO       PTD
#define EN_ON_LH_MCU_S_PIN       4U
//=============锟斤拷准锟斤拷锟斤拷ADC锟斤拷锟斤拷锟斤拷锟斤拷==============
//锟剿达拷锟斤拷锟斤拷锟侥诧拷锟斤拷锟斤拷锟斤拷锟矫ｏ拷锟斤拷adc锟斤拷锟街斤拷锟斤拷锟皆达拷
#define A6_ADC_ECU_NTC_GPIO                 PTA
#define A6_ADC_ECU_NTC_PIN                  6U
#define A7_ADC_CV2_CV_GPIO                  PTA
#define A7_ADC_CV2_CV_PIN                   7U
#define B2_ADC_RBIN3_TBD_GPIO               PTB
#define B2_ADC_RBIN3_TBD_PIN                2U
#define B3_ADC_RBIN2_TBD_GPIO               PTB
#define B3_ADC_RBIN2_TBD_PIN                3U
#define C2_ADC_KL30_GPIO                    PTC
#define C2_ADC_KL30_PIN                     2U
#define C3_ADC_NTC1_TBD_GPIO                PTC
#define C3_ADC_NTC1_TBD_PIN                 3U
#define C14_ADC_RBIN1_TBD_GPIO              PTC
#define C14_ADC_RBIN1_TBD_PIN               14U
#define C15_ADC_NTC3_TBD_GPIO               PTC
#define C15_ADC_NTC3_TBD_PIN                15U
#define C16_ADC_NTC2_TBD_GPIO               PTC
#define C16_ADC_NTC2_TBD_PIN                16U
#define C17_ADC_CV1_CV_GPIO                 PTC
#define C17_ADC_CV1_CV_PIN                  17U
//锟斤拷锟脚达拷锟斤拷锟斤拷锟斤拷
#define Read_PINS(gpio,pin)    		 (PINS_DRV_ReadPins(gpio) & (1 << pin))

#define SET_PINS(gpio,pin)    		 PINS_DRV_SetPins(gpio,1 << pin)
#define CLR_PINS(gpio,pin)    		 PINS_DRV_ClearPins(gpio,1 << pin)
#define TOG_PINS(gpio,pin)    		 PINS_DRV_TogglePins(gpio,1 << pin)

#define bool_HB_state				Read_PINS(A13_SW_HB_GPIO,A13_SW_HB_PIN)
#define bool_LB_state				Read_PINS(D7_SW_LB_GPIO,D7_SW_LB_PIN)
#define bool_DRL_state				Read_PINS(C9_SW_DRL_GPIO,C9_SW_DRL_PIN)
#define bool_PL_state				Read_PINS(C8_SW_PL_GPIO,C8_SW_PL_PIN)
#define bool_TL_state				Read_PINS(E3_SW_TL_GPIO,E3_SW_TL_PIN)
#define bool_7210_FS_state          Read_PINS(D2_EN_FB_BUCK_Falut_GPIO,D2_EN_FB_BUCK_Falut_PIN)

//#define ENABLE_OFF_LH_MCU_S 		 SET_PINS(EN_OFF_LH_MCU_S_GPIO,EN_OFF_LH_MCU_S_PIN)
//#define DisABLE_OFF_LH_MCU_S 		 CLR_PINS(EN_OFF_LH_MCU_S_GPIO,EN_OFF_LH_MCU_S_PIN)

#define EN_LDO5VOUT_LDO_ENABLE			     SET_PINS(E5_EN_LDO_LOADER_GPIO,E5_EN_LDO_LOADER_PIN)
#define EN_LDO5VOUT_LDO_DISABLE		         CLR_PINS(E5_EN_LDO_LOADER_GPIO,E5_EN_LDO_LOADER_PIN)
#define EN_BVCK5V_MCU_LDO_ENABLE			 SET_PINS(E4_EN_LDO_BUCK_GPIO,E4_EN_LDO_BUCK_PIN)
#define EN_BVCK5V_MCU_LDO_DISABLE		     CLR_PINS(E4_EN_LDO_BUCK_GPIO,E4_EN_LDO_BUCK_PIN)
#define EN_IC3_4_ENABLE				         SET_PINS(A0_EN_CV3_4_GPIO,A0_EN_CV3_4_PIN)
#define EN_IC3_4_DISABLE		    	     CLR_PINS(A0_EN_CV3_4_GPIO,A0_EN_CV3_4_PIN)

#define EN_IC1_CV_ENABLE			 SET_PINS(D6_EN_CV1_GPIO,D6_EN_CV1_PIN)
#define EN_IC1_CV_DISABLE		     CLR_PINS(D6_EN_CV1_GPIO,D6_EN_CV1_PIN)
#define EN_IC2_CV_ENABLE			 SET_PINS(D5_EN_CV2_GPIO,D5_EN_CV2_PIN)
#define EN_IC2_CV_DISABLE		     CLR_PINS(D5_EN_CV2_GPIO,D5_EN_CV2_PIN)
#define BUCK_SPI_CS1_ENABLE			 SET_PINS(C5_SPI_CS1_GPIO,C5_SPI_CS1_PIN)//CS锟角碉拷锟斤拷效锟斤拷EN锟斤拷CLR
#define BUCK_SPI_CS1_DISABLE		 CLR_PINS(C5_SPI_CS1_GPIO,C5_SPI_CS1_PIN)
#define BUCK_SPI_CS2_ENABLE			 SET_PINS(E6_SPI_CS2_GPIO,E6_SPI_CS2_PIN)//CS锟角碉拷锟斤拷效锟斤拷EN锟斤拷CLR
#define BUCK_SPI_CS2_DISABLE		 CLR_PINS(E6_SPI_CS2_GPIO,E6_SPI_CS2_PIN)
#define Open_PMOS_Input_ENABLE     	 SET_PINS(D16_EN_PMOS_GPIO,D16_EN_PMOS_PIN)
#define Open_PMOS_Input_DISABLE      CLR_PINS(D16_EN_PMOS_GPIO,D16_EN_PMOS_PIN)

#define E10_EN_FB_DRL_PL_ENABLE      SET_PINS(E10_EN_FB_DRL_PL_GPIO, E10_EN_FB_DRL_PL_PIN)
#define E10_EN_FB_DRL_PL_DISABLE     CLR_PINS(E10_EN_FB_DRL_PL_GPIO, E10_EN_FB_DRL_PL_PIN)
#define D1_EN_FB1_LB_FB_ENABLE         SET_PINS(D1_EN_FB1_LB_FB_GPIO, D1_EN_FB1_LB_FB_PIN)
#define D1_EN_FB1_LB_FB_DISABLE        CLR_PINS(D1_EN_FB1_LB_FB_GPIO, D1_EN_FB1_LB_FB_PIN)
#define E11_EN_FB2_HB_FB_ENABLE        SET_PINS(E11_EN_FB2_HB_FB_GPIO, E11_EN_FB2_HB_FB_PIN)
#define E11_EN_FB2_HB_FB_DISABLE       CLR_PINS(E11_EN_FB2_HB_FB_GPIO, E11_EN_FB2_HB_FB_PIN)
#define D0_EN_FB3_TL_FB_ENABLE         SET_PINS(D0_EN_FB3_TL_FB_GPIO, D0_EN_FB3_TL_FB_PIN)
#define D0_EN_FB3_TL_FB_DISABLE        CLR_PINS(D0_EN_FB3_TL_FB_GPIO, D0_EN_FB3_TL_FB_PIN)

#define E8_EN_FB4_Falut_ENABLE       SET_PINS(E8_EN_FB4_Falut_GPIO, E8_EN_FB4_Falut_PIN)
#define E8_EN_FB4_Falut_DISABLE      CLR_PINS(E8_EN_FB4_Falut_GPIO, E8_EN_FB4_Falut_PIN)
#define E9_EN_FB5_Falut_ENABLE       SET_PINS(E9_EN_FB5_Falut_GPIO, E9_EN_FB5_Falut_PIN)
#define E9_EN_FB5_Falut_DISABLE      CLR_PINS(E9_EN_FB5_Falut_GPIO, E9_EN_FB5_Falut_PIN)

#define B12_EN_LED1_HB_ENABLE        SET_PINS(B12_EN_LED1_HB_GPIO, B12_EN_LED1_HB_PIN)
#define B12_EN_LED1_HB_DISABLE       CLR_PINS(B12_EN_LED1_HB_GPIO, B12_EN_LED1_HB_PIN)
#define B13_EN_LED2_LB_ENABLE        SET_PINS(B13_EN_LED2_LB_GPIO, B13_EN_LED2_LB_PIN)
#define B13_EN_LED2_LB_DISABLE       CLR_PINS(B13_EN_LED2_LB_GPIO, B13_EN_LED2_LB_PIN)

#define A11_EN_LED5_TL_ENABLE        SET_PINS(A11_EN_LED5_TL_GPIO, A11_EN_LED5_TL_PIN)
#define A11_EN_LED5_TL_DISABLE       CLR_PINS(A11_EN_LED5_TL_GPIO, A11_EN_LED5_TL_PIN)
#define A12_EN_LED6_DRL_PL_ENABLE    SET_PINS(A12_EN_LED6_DRL_PL_GPIO, A12_EN_LED6_DRL_PL_PIN)
#define A12_EN_LED6_DRL_PL_DISABLE   CLR_PINS(A12_EN_LED6_DRL_PL_GPIO, A12_EN_LED6_DRL_PL_PIN)

#define Open_IC_CC1_EN1_ENABLE   	 SET_PINS(A2_EN_BUCK1_EN1_GPIO,A2_EN_BUCK1_EN1_PIN)
#define Open_IC_CC2_EN2_ENABLE   	 SET_PINS(A10_EN_BUCK1_EN2_GPIO,A10_EN_BUCK1_EN2_PIN)
#define Open_IC_CC3_EN1_ENABLE   	 SET_PINS(D3_EN_BUCK2_EN1_GPIO,D3_EN_BUCK2_EN1_PIN)
#define Open_IC_CC4_EN2_ENABLE   	 SET_PINS(A3_EN_BUCK2_EN2_GPIO,A3_EN_BUCK2_EN2_PIN)

#define Open_IC_CC1_EN1_DISABLE  	 CLR_PINS(A2_EN_BUCK1_EN1_GPIO,A2_EN_BUCK1_EN1_PIN)
#define Open_IC_CC2_EN2_DISABLE  	 CLR_PINS(A10_EN_BUCK1_EN2_GPIO,A10_EN_BUCK1_EN2_PIN)
#define Open_IC_CC3_EN1_DISABLE  	 CLR_PINS(D3_EN_BUCK2_EN1_GPIO,D3_EN_BUCK2_EN1_PIN)
#define Open_IC_CC4_EN2_DISABLE  	 CLR_PINS(A3_EN_BUCK2_EN2_GPIO,A3_EN_BUCK2_EN2_PIN)

#define ENABLE_ON_LH_MCU_S   	 SET_PINS(EN_ON_LH_MCU_S_GPIO,EN_ON_LH_MCU_S_PIN)
#define DisABLE_ON_LH_MCU_S  	 CLR_PINS(EN_ON_LH_MCU_S_GPIO,EN_ON_LH_MCU_S_PIN)

extern void Pin_state_init(void);
extern void delay_1ms(uint32_t time);
#endif /* LLD_CONFIG_H_ */
