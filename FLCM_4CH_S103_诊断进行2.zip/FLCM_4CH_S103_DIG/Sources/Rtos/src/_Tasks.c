/******************************************************************************
*
*   COPYRIGHT       : Ternary 
*   FILENAME        : $Source: _Tasks.c $
*   COMPILER        : IAR IDE  9.40.1
*   PROCESSOR       : YTM32B1ME0
*
*   DATE OF CREATION: 10.03.2024
*   LAST REVISION   : $Date  : 10.03.2024 $
*                     $Author:        $

******************************************************************************/


 
 /* ========= File define =================================================== */
#define _Tasks_c


/* ========== Includes ====================================================== */
#include "_Tasks.h"
#include "LLD_config.h"
#include "app_bin.h"
#include "app_signal_check.h"
#include "al_light_function.h"
#include "APP_Demo.h"
#include "al_light_function.h"
#include "bootloader_debug.h"
#include "Diagnostic_fault.h"

/*
#include "Mcal.h"
#include "EcuM.h"
#include "BswM.h"
#include "CanIf.h"
#include "Com.h"
#include "PduR.h"
#include "ComM.h"
#include "CanSM.h"
#include "CanNm.h"
#include "Fls.h"
#include "Fee.h"
#include "NvM.h"
#include "CanTp.h"
#include "Dcm.h"
#include "Dcm_Cbk.h"
#include "Dem.h"
#include "Rte_E2EXf.h"
#include "MPQ7210_driver.h"
#include "TLE9262_test.h"
#include "_Rte_Handler.h"
#include "_Boot_Interface.h"
#include "_Coding_Handler.h"
#include "_Rtos.h"
#include "_AD_Handler.h"
#include "_signal_filter.h"
#include "_app_lamp_input.h"
#include "_app_lamp_output.h"
#include "_bat_calc.h"
#include "_temp_calc.h"
#include "_rbin_calc.h"
*/


/* ========== Local Defines, Enumerations, Type Definitions ================= */

/* ========== Local Function Prototypes ===================================== */

/* ========== Local Macros ================================================== */

/* ========== Local Variables =============================================== */

//ComM_ModeType can_BusMode = COMM_NO_COMMUNICATION;

/* ========== Local Functions =============================================== */


/* ========== Global Functions ============================================== */


/* ************************************************************************** */
/*!
 * @fn         void _5msTask(void)
 * @brief      5ms Task
 * @details    none
 */
/* ************************************************************************** */
void _5msTask(void)
{
#ifdef TEST_DEBUG
      APP_Demo_MainFun();
#endif
      if(LB_HB_OFF_TIME == 1)
	  {
		  Get_LB_HB_OFF_TIME ++; //LB_HB_OFF_TIME++;
	  }
	  if(Get_LB_HB_OFF_TIME >= 1)
      {
          B12_EN_LED1_HB_DISABLE;//HB - OFF
          B13_EN_LED2_LB_DISABLE;//LB - OFF
          LB_HB_OFF_TIME = 0;
          Get_LB_HB_OFF_TIME = 0;
      }
}


/* ************************************************************************** */
/*!
 * @fn         void _10ms_A_Task(void)
 * @brief      10ms A Task
 * @details    none
 */
/* ************************************************************************** */
void _10ms_Task(void)
{
	ADManage_Tesk();
	LightFunctionProcess();
	Vehicle_Diagnostic_fun();
}


/* ************************************************************************** */
/*!
 * @fn         void _20ms_A_Task(void)
 * @brief      20ms A Task
 * @details    none
 */
/* ************************************************************************** */
void _20ms_A_Task(void)  
{
	Sig_StatusDectProcess();
}


/* ************************************************************************** */
/*!
 * @fn         void _20ms_B_Task(void)
 * @brief      20ms B Task
 * @details    none
 */
/* ************************************************************************** */
void _20ms_B_Task(void)
{
	Fault_Trigger_Check();
}


/* ************************************************************************** */
/*!
 * @fn         void _50msTask(void)
 * @brief      50ms Task
 * @details    none
 */
/* ************************************************************************** */
void _50msTask(void)
{

}

/* ************************************************************************** */
/*!
 * @fn         void _100msTask(void)
 * @brief      100ms Task
 * @details    none
 */
/* ************************************************************************** */
void _100msTask(void)
{

}

/* ************************************************************************** */
/*!
 * @fn         void _250msTask(void)
 * @brief      250ms Task
 * @details    none
 */
/* ************************************************************************** */
void _250msTask(void)
{
	
}

/* ************************************************************************** */
/*!
 * @fn         void _500msTask(void)
 * @brief      500ms Task
 * @details    none
 */
/* ************************************************************************** */
void _500msTask(void)
{
	
}

/* ************************************************************************** */
/*!
 * @fn         void _1000msTask(void)
 * @brief      1000ms Task
 * @details    none
 */
/* ************************************************************************** */
void _1000msTask(void)
{
	uint8_t a = 0;
	a++;
	//uint16_t reg_temp = 0;//新建一个变量用来存放要发给ADC通道寄存器的控制指令
	//reg_temp = (uint16_t)((uint8_t)(FS_INT_EN_temp[2]) << 8 | (uint8_t)(FS_INT_EN_temp[1]));//将读取到2份8位数据，拼接成16位数据
	//APPDebugPrintf("reg_temp is %ld", reg_temp);
	if(a >= 2)
	{
		a = 0;
		if(e_MPQ7210_ERR.e_lamp.cc3.open_err_flag)
		{
			APPDebugPrintf("cc3.open\n");
		}
		else
		{
			APPDebugPrintf("cc3.open.recov\n");
		}
		if(e_MPQ7210_ERR.e_lamp.cc2.open_err_flag)
		{
			APPDebugPrintf("cc2.open\n");
		}
		else
		{
			APPDebugPrintf("cc2.open.recov\n");
		}

		if(e_MPQ7210_ERR.e_lamp.cc3.short_err_flag)
		{
			APPDebugPrintf("cc3.short\n");
		}
		else
		{
			APPDebugPrintf("cc3.short.recov\n");
		}
		if(e_MPQ7210_ERR.e_lamp.cc2.short_err_flag)
		{
			APPDebugPrintf("cc2.short\n");
		}
		else
		{
			APPDebugPrintf("cc2.short.recov\n");
		}
	}
}





