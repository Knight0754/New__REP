/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2018 NXP
 * All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
/*!
 * @file APP_Demo.c
 * 
 * @brief: Add your description here for this file.
 *
 * @page misra_violations MISRA-C:2012 violations
 *
 * @section Rule_11-4 Rule: 11.4 (Advisory)
 * Violates MISRA 2012 Advisory Rule 11.4, Conversion between a pointer and integer type.
 * The cast is required to initialize a pointer with an unsigned long define, representing an address.
 *
 * @section Rule_11-6 Rule: 11.6 (Required)
 * Violates MISRA 2012 Required Rule 11.6, Cast from unsigned int to pointer.
 * The cast is required to initialize a pointer with an unsigned long define, representing an address.
 *
 * @par Version Histroy
<pre><b>
Version:   Author:       Date&&Time:      Revision Log: </b>
 V1.0.0  Tomlin Tang  2020-12-29 09:17:00  First Creat
When you update, please do not forgot to del me and add your info at here.
</pre>
 */

/*******************************************************************************
 * User Include
 ******************************************************************************/
#include "APP_Demo.h"
#include "Cpu.h"
#include "UDS_app.h"
#include "TP.h"
#include "bootloader_debug.h"
#include "LLD_Config.h"
#include "watchdog_hal.h"
#include "timer_hal.h"
#include "boot.h"
/*******************************************************************************
 * Macros
 ******************************************************************************/
#define LPIT_CHANNEL        0UL
#define LPIT_Channel_IRQn   LPIT0_IRQn
/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint16_t capturedValue = 0U;
uint16_t timerCounterValue[2] = {0u};
uint16_t timerOverflowInterruptCount = 0u;

uint8_t GACVer_Arr_H[8] = {
	0x37, 0x32, 0x31, 0x30,
	0x30, 0x30, 0x37, 0x43,
};

uint8_t GACVer_Arr_L[6] = {
	0x44, 0x45, 0x30, 0x35,
	0x30, 0x30,
};

uint8_t SWVer_Arr[5] = {
	0x53, 0x2E, 0x44, 0x30,
	0x32,
};

uint8_t HWVer_Arr[5] = {
	0x48, 0x2E, 0x44, 0x30,
	0x30,
};

uint8_t sSWVer_Arr[4] = {
	0x53, 0x31, 0x30, 0x33,
};

/**
 * @brief LPIT 中断服务程序
 *
 * 当 LPIT 定时器发生中断时，调用此函数进行处理。
 *
 */
void LPIT_ISR(void)
{
	// 清除中断标志位
	LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT1, (1 << LPIT_CHANNEL));

	/* Increment overflow count */
	// 增加溢出计数
	timerOverflowInterruptCount++;

#ifdef TEST_DEBUG
	// 判断定时器是否超时，如果超时则执行超时服务
	LIN_DRV_TimeoutService(INST_LIN1);
#endif
}
	
/* (CLK (MHz)* timer period (us) / Prescaler) */
#define TIMER_COMPARE_VAL (uint16_t)(2000U)
#define TIMER_TICKS_1US   (uint16_t)(4U)

/**
 * @brief 获取LIN1定时器的时间间隔回调函数0
 *
 * 获取LIN1定时器的时间间隔，并计算自上次调用该函数以来经过的纳秒数。
 *
 * @param ns 存储计算得到的纳秒数的指针
 *
 * @return 总是返回0
 */
uint32_t lin1TimerGetTimeIntervalCallback0(uint32_t *ns)
{
	// 定义一个静态变量，用于保存上一次计数值
	static uint32_t previousCountValue = 0UL;

	// 获取当前计数值
	uint32_t counterValue;
	counterValue = capturedValue;

	// 计算时间间隔，单位为纳秒
	*ns = ((uint32_t)(counterValue + timerOverflowInterruptCount * TIMER_COMPARE_VAL - previousCountValue)) * 1000UL / TIMER_TICKS_1US;

	// 重置定时器溢出中断次数
	timerOverflowInterruptCount = 0UL;

	// 更新上一次计数值
	previousCountValue = counterValue;

	// 返回0，表示函数执行成功
	return 0UL;
}

boolean g_bIsNeedTxMsg = FALSE;
uint8 g_aLINRxBuf[8u] = {0u};
uint8 g_aLINTxBuf[8u] = {0u};

/* User includes (#include below this line is not maintained by Processor Expert) */
/**
 * @brief LIN回调函数
 *
 * 当LIN通信发生事件时，该函数会被调用。
 *
 * @param instance LIN实例
 * @param linState LIN状态指针
 */
void LINCallBack(uint32_t instance, void * linState)
{
	const lin_state_t * linCurrentState = linState;
	uint8 id = linCurrentState->currentId;
	uint8 bytesRemaining = 0U;
	uint8 rxSize = 8;

	status_t result = STATUS_UNSUPPORTED;

	switch (linCurrentState->currentEventId)
	{
	 case LIN_PID_OK:
		 if(0x30 == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_SendFrameData(INST_LIN1, GACVer_Arr_H, sizeof(GACVer_Arr_H));
		}
		if(0x31 == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_SendFrameData(INST_LIN1, GACVer_Arr_L, sizeof(GACVer_Arr_L));
		}
		if(0x32 == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_SendFrameData(INST_LIN1, SWVer_Arr, sizeof(SWVer_Arr));
		}
		if(0x33 == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_SendFrameData(INST_LIN1, HWVer_Arr, sizeof(HWVer_Arr));
		}
		if(0x34 == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_SendFrameData(INST_LIN1, sSWVer_Arr, sizeof(sSWVer_Arr));
		}
		// 如果当前ID为0x3C
		if(0x3C == id)
		{
			// 设置LIN1的超时计数器为8
			LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
			// 接收LIN1的帧数据，存储在g_aLINRxBuf中，接收8个字节
			result = LIN_DRV_ReceiveFrameData(INST_LIN1, g_aLINRxBuf, 8u);
		}
		else
		{
			// 如果需要发送消息
			if(TRUE == g_bIsNeedTxMsg)
			{
				// 设置LIN1的超时计数器为8
				LIN_DRV_SetTimeoutCounter(INST_LIN1, 8);
				// 发送LIN1的帧数据，从g_aLINTxBuf中发送，发送大小为g_aLINTxBuf的大小
				result = LIN_DRV_SendFrameData(INST_LIN1, g_aLINTxBuf, sizeof(g_aLINTxBuf));
			}
		}

		 break;

	 case LIN_PID_ERROR:
		 // 发生错误
		 break;

	 case LIN_TX_COMPLETED:
		// 发送完成，设置不需要发送消息
		g_bIsNeedTxMsg = FALSE;
		// 调用发送消息成功的回调函数
		TP_DoTxMsgSuccesfulCallback();

		 break;

	 case LIN_RX_COMPLETED:
		 // 接收完成，将接收到的数据写入TP
		 TP_DriverWriteDataInTP(0x3Cu, 8u, g_aLINRxBuf);
		 break;

	 case LIN_CHECKSUM_ERROR:
		 // 校验和错误
		 break;

	 case LIN_READBACK_ERROR:
		 // 读回错误
		 break;

	 case LIN_FRAME_ERROR:
		 // 帧错误
		 break;

	 case LIN_RECV_BREAK_FIELD_OK:
		 // 接收中断字段正常
		 break;
	 case LIN_SYNC_ERROR:
		 // 同步错误
		 break;
	 case LIN_BAUDRATE_ADJUSTED:
		 // 波特率调整
		 break;
	 case LIN_NO_EVENT:
		 // 没有事件
		 if (linCurrentState->timeoutCounterFlag == (bool)1U)
		 {
			 {
				 // 获取接收状态
				 (void)LIN_DRV_GetReceiveStatus(instance, &bytesRemaining);
				 // 接收部分数据但未完成
				 /* Received part of data but not completed */
				 if (linCurrentState->rxSize > bytesRemaining)
				 {

				 }
			 }
		 }
		 break;

	 default:
		 // 不执行任何操作
		 /* do nothing */
		 break;
	}
}


static void BSP_Init(void);

static void SendMsgMainFun(void);


/**
 * @brief APP_Demo_Init 函数初始化演示应用
 *
 * 此函数用于初始化演示应用程序。
 */
void APP_Demo_Init(void)
{
	// 初始化底层硬件
	BSP_Init();

	// 初始化看门狗
	//WATCHDOG_HAL_Init();

	// 初始化定时器
	TIMER_HAL_Init();

	// 初始化调试模块
	BOOTLOADER_DEBUG_Init();

#ifdef TEST_DEBUG

	// 初始化UDS协议
	UDS_Init();

	// 初始化协议层
	TP_Init();

	// 检查APP下载状态
	Boot_CheckDownloadAPPStatus();

#endif
	// 输出LIN波特率信息
	APPDebugPrintf("Welcome enter S32K118 LIN(19200) APP demo!\n");
}

/**
 * @brief APP_Demo_MainFun 函数
 *
 * 该函数是 APP_Demo 的主函数，用于执行主要的操作。
 */
void APP_Demo_MainFun(void)
{
	// 检查1ms定时器是否超时
	if(TRUE == TIMER_HAL_Is1msTickTimeout())
	{
		// 执行TP系统时钟控制函数
		TP_SystemTickCtl();

		// 执行UDS系统时钟控制函数
		UDS_SystemTickCtl();
	}

	// 执行TP主函数
	TP_MainFun();

	// 执行UDS主函数
	UDS_MainFun();

	// 检查100ms定时器是否超时
	if(TRUE == TIMER_HAL_Is100msTickTimeout())
	{
		// 喂狗，防止看门狗超时
		WATCHDOG_HAL_Fed();
	}

	// 执行发送消息主函数
	SendMsgMainFun();
}

/*Send msg main function*/
/**
 * @brief 发送消息主函数
 *
 * 从TP读取消息，并将其标记为需要发送的消息。
 */
static void SendMsgMainFun(void)
{
	// 定义消息ID和消息长度变量
	uint32 msgId = 0u;
	uint32 msgLength = 0u;

	// 从TP获取消息
	/*get message from TP*/
	if(FALSE == g_bIsNeedTxMsg)
	{
		// 从TP读取数据，并更新消息ID和消息长度
		if(TRUE == TP_DriverReadDataFromTP(8u, g_aLINTxBuf, &msgId, &msgLength))
		{
			// 设置需要发送消息的标志位为TRUE
			g_bIsNeedTxMsg = TRUE;
		}
	}
}

/**
 * @brief 初始化 BSP（板级支持包）
 *
 * 初始化时钟系统、引脚驱动、LIN 驱动、LPIT 驱动等模块。
 *
 */
static void BSP_Init(void)
{
	// 初始化时钟管理系统
	CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT, g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
	// 更新时钟配置
	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

	// 初始化引脚驱动
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);

#ifdef TEST_DEBUG
	// 初始化LIN驱动
	LIN_DRV_Init(INST_LIN1, &lin1_InitConfig0, &lin1_State);
	// 安装LIN驱动回调函数
	LIN_DRV_InstallCallback(INST_LIN1, LINCallBack);
	// 启用LIN驱动中断
	LIN_DRV_EnableIRQ(INST_LIN1);
	// 启用LPUART1_RxTx_IRQn中断
	INT_SYS_EnableIRQ(LPUART1_RxTx_IRQn);
#endif
	// 初始化LPIT驱动
	LPIT_DRV_Init(INST_LPIT1, &lpit1_InitConfig);
	// 初始化LPIT通道0，配置为周期性计数器，用于每秒生成一个中断
	/* Initialize LPIT channel 0 and configure it as a periodic counter
	 * which is used to generate an interrupt every second.
	 */
	LPIT_DRV_InitChannel(INST_LPIT1, LPIT_CHANNEL, &lpit1_ChnConfig0);
	// 安装LPIT_ISR作为LPIT中断处理函数
	/* Install LPIT_ISR as LPIT interrupt handler */
	INT_SYS_InstallHandler(LPIT_Channel_IRQn, &LPIT_ISR, (isr_t *)0);
	// 启动LPIT0通道0计数器
	/* Start LPIT0 channel 0 counter */
	LPIT_DRV_StartTimerChannels(INST_LPIT1, (1 << LPIT_CHANNEL));

	// 启用全局中断
	INT_SYS_EnableIRQGlobal();
}

/******************************************************************************
 * EOF
 *****************************************************************************/
