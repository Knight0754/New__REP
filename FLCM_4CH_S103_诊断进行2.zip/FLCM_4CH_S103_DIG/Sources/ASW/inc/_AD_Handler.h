#ifndef _AD_Handler_h
#define _AD_Handler_h

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define ADC_VENDOR_ID_PBCFG               (180)
#define ADC_AR_REL_MAJOR_VER_PBCFG        (4)
#define ADC_AR_REL_MINOR_VER_PBCFG        (4)
#define ADC_AR_REL_REVISION_VER_PBCFG     (0)
#define ADC_SW_MAJOR_VER_PBCFG            (2)
#define ADC_SW_MINOR_VER_PBCFG            (0)
#define ADC_SW_PATCH_VER_PBCFG            (0)


/**
*@brief Adc0Group_0 Group index ，channel number and channel index
*/
#define AdcConf_AdcConfigSet_Adc0Group_0                (0U)

#define Adc0Group_0_CHANNEL_NUMBER             (10U)

/**
*@brief Adc1Group_0 Group index ，channel number and channel index
*/
#define AdcConf_AdcConfigSet_Adc1Group_0                (1U)

#define Adc1Group_0_CHANNEL_NUMBER             (7U)

/**
*@brief Adc1Group_1 Group index ，channel number and channel index
*/
#define AdcConf_AdcConfigSet_Adc1Group_1                (2U)

#define Adc1Group_1_CHANNEL_NUMBER             (4U)
enum
{
   ADC_RBIN3_MCU_S,
   ADC_RBIN4_MCU_S,
   ADC_RBIN5_MCU_S,
   ADC_CV2_CV_MCU,
   ADC_NTC1_MCU_S,
   ADC_NTC2_MCU_S,
   ADC_NTC3_MCU_S,
   ADC_NTC4_MCU_S,
   ADC_NTC5_MCU_S,
   ADC_RBIN1_MCU_S,
   ADC_RBIN2_MCU_S,
   ADC_ECU_NTC_MCU,
   ADC_CV1_CV_MCU,
   ADC_KL30_P_MCU,
   ADC_MSS_MCU_HSD,
   ADC_CHL_MAX  
};

extern uint16 g_u16AdVal[ADC_CHL_MAX];
extern void ADC_Configuration(void);
extern void ADC_GroupStart(void);

extern uint16 g_u16AdVal[ADC_CHL_MAX];


#endif
