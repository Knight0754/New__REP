/*
 * boost3910.c
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#include "boost3910.h"
#include "ftm_pwm_driver.h"
#include "ftm_hw_access.h"
#include "LLD_config.h"

/**
 * @brief FTM0_PWM_DutyCycle_Output 函数
 *
 * 设置 FTM0 PWM 通道的占空比输出值。
 *
 * @param CHN PWM 通道号
 * @param value 占空比输出值
 */
void FTM0_PWM_DutyCycle_Output(uint8_t CHN,uint16_t value)
{
	FTM_DRV_UpdatePwmChannel(INST_FLEXTIMER_PWM1, CHN, FTM_PWM_UPDATE_IN_DUTY_CYCLE, value, 0U, true);
	//FTM_DRV_UpdatePwmChannel(INST_FLEXTIMER_PWM2, CHN, FTM_PWM_UPDATE_IN_DUTY_CYCLE, value, 0U, true);
}
void FTM1_PWM_DutyCycle_Output(uint8_t CHN,uint16_t value)
{
	//FTM_DRV_UpdatePwmChannel(INST_FLEXTIMER_PWM1, CHN, FTM_PWM_UPDATE_IN_DUTY_CYCLE, value, 0U, true);
	FTM_DRV_UpdatePwmChannel(INST_FLEXTIMER_PWM2, CHN, FTM_PWM_UPDATE_IN_DUTY_CYCLE, value, 0U, true);
}

/**
 * @brief 初始化Boost电路
 *
 * 初始化Boost电路，启用IC1和IC2的CV功能，设置FTM0和FTM1的PWM占空比，并输出到相应的PWM引脚。
 */
void sl_boost_init(void)
{
	// 启用IC1的CV功能
	EN_IC1_CV_ENABLE;
	// 启用IC2的CV功能
	EN_IC2_CV_ENABLE;
	// 设置FTM0的PWM占空比为50%并输出到nPWM_RT_CV1
	FTM0_PWM_DutyCycle_Output(nPWM_RT_CV1, duty_50);
	// 设置FTM0的PWM占空比为50%并输出到nPWM_RT_CV2
	FTM0_PWM_DutyCycle_Output(nPWM_RT_CV2, duty_50);
	// 设置FTM1的PWM占空比为0%并输出到nPWM_reference_CV1
	FTM1_PWM_DutyCycle_Output(nPWM_reference_CV1, duty_0);
	// 设置FTM1的PWM占空比为0%并输出到nPWM_reference_CV2
	FTM1_PWM_DutyCycle_Output(nPWM_reference_CV2, duty_0);
}
