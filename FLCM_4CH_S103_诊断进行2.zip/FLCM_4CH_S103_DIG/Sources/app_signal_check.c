/*
 * app_signal_check.c
 *
 *  Created on: 2023�??11�??7�??
 *      Author: gz06488
 */

#include "app_signal_check.h"
#include "LLD_config.h"
#include "sl_softtimer.h"

static sstTimerIndex_t Key_Mode_Filer = 0;
uint8_t Input_key_arr[KEY_SIG_NUM]={0,0,0,0,0,};

/**
 * @brief 初始化按键
 *
 * 将按键的新状态设置为0，并将新状态赋值给旧状态。
 * 将滤波器设置为0，并将事件设置为FALSE。
 * 创建一个软件定时器，并将其赋值给Key_Mode_Filer。
 * 设置定时器的周期为key_MODE_FILTER_TIME。
 */
void Key_INIT(void)
{
	// 设置新状态为0
	SIGNAL_Mode.NewState = 0;
	// 将新状态赋值给旧状态
	SIGNAL_Mode.OldState = SIGNAL_Mode.NewState;
	// 设置滤波器为0
	SIGNAL_Mode.Filer = 0;
	// 设置事件为FALSE
	SIGNAL_Mode.Evnt = FALSE;
	// 创建一个软件定时器，并将其赋值给Key_Mode_Filer
	Key_Mode_Filer = sl_BaseTimer_GreatSoftTimer();
	// 设置定时器的周期为key_MODE_FILTER_TIME
	sl_SetTimerPeriod(Key_Mode_Filer, key_MODE_FILTER_TIME);
}


/**
 * @brief 检测灯光信号
 *
 * 检测每个按键的状态，并根据按键状态更新 temp 变量。
 * 如果 temp 不等于 SIGNAL_Mode.NewState，则更新 SIGNAL_Mode.NewState，并设置定时器 Key_Mode_Filer 的周期为 key_MODE_FILTER_TIME。
 * 如果定时器 Key_Mode_Filer 超时，则刷新定时器，并检查 SIGNAL_Mode.NewState 是否与 SIGNAL_Mode.OldState 不同。
 * 如果不同，则更新 SIGNAL_Mode.OldState，将 SIGNAL_Mode.Evnt 设置为 TRUE，并返回 SIGNAL_Mode.Evnt 的值。
 * 如果相同，则返回 FALSE。
 *
 * @return 如果检测到按键状态变化，则返回 TRUE；否则返回 FALSE。
 */
uint8_t DetectLightSignals( void )
{
	uint8_t temp=0;

	if(bool_HB_state)
		{
			temp |= KEY_HB;
			//APPDebugPrintf("bool_HB_state == 1!\n");
		}
		if(bool_LB_state)
		{
			temp |= KEY_LB;
		}
		if(bool_DRL_state)
		{
			temp |= KEY_DRL;
			//APPDebugPrintf("bool_DRL_state == 1!\n");
		}
		if(bool_PL_state)
		{
			temp |= KEY_PL;
		}
		if(bool_TL_state)
		{
			temp |= KEY_TL;
		}
	
	// 如果temp不等于SIGNAL_Mode.NewState
	if(temp != SIGNAL_Mode.NewState)
	{
		// 将temp赋值给SIGNAL_Mode.NewState
		SIGNAL_Mode.NewState = temp;
		// 设置定时器Key_Mode_Filer的周期为key_MODE_FILTER_TIME
		sl_SetTimerPeriod(Key_Mode_Filer, key_MODE_FILTER_TIME);
	}
	else
	{
		// 如果定时器Key_Mode_Filer超时
		if(sl_IsTimerExceed(Key_Mode_Filer))
		{
			// 刷新定时器Key_Mode_Filer
			sl_RefreshTimer(Key_Mode_Filer);
			// 如果SIGNAL_Mode.NewState不等于SIGNAL_Mode.OldState
			if( SIGNAL_Mode.NewState != SIGNAL_Mode.OldState )
			{
				// 将SIGNAL_Mode.NewState赋值给SIGNAL_Mode.OldState
				SIGNAL_Mode.OldState = SIGNAL_Mode.NewState;
				// 将SIGNAL_Mode.Evnt设置为TRUE
				SIGNAL_Mode.Evnt = TRUE;
				// 返回SIGNAL_Mode.Evnt的值
				return SIGNAL_Mode.Evnt;
			}
		}
	}
	// 返回FALSE
	return FALSE;
}

/**
 * @brief 信号状态检测处理函数
 *
 * 检测灯光信号并进行相应的处理。
 */
void Sig_StatusDectProcess(void)// 信号状态检测处理函数
{
		if(bool_HB_state)
		{
			Input_key_arr[K_HB] = CH_HB_ON;
		}
		else
		{
			Input_key_arr[K_HB] = CH_HB_OFF;
		}
		if(bool_LB_state)
		{
			Input_key_arr[K_LB] = CH_LB_ON;
		}
		else
		{
			Input_key_arr[K_LB] = CH_LB_OFF;
		}
		if(bool_DRL_state)
		{
			Input_key_arr[K_DRL] = CH_DRL_ON;
		}
		else
		{
			Input_key_arr[K_DRL] = CH_DRL_OFF;
		}
		if(bool_PL_state)
		{
			Input_key_arr[K_PL] = CH_PL_ON;
		}
		else
		{
			Input_key_arr[K_PL] = CH_PL_OFF;
		}
		if(bool_TL_state)
		{
			Input_key_arr[K_TL] = CH_TL_ON;
		}
		else
		{
			Input_key_arr[K_TL] = CH_TL_OFF;
		}

}

