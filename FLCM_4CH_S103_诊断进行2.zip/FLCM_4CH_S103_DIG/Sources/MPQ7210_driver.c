/*
 * MPQ7210_driver.c
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 *      修改内容:  串一个200ohm电阻靠近mcu，电容10皮法放在靠近buck的地方
 */

#include "MPQ7210_driver.h"
#include "Diagnostic_fault.h"
#include "sl_softtimer.h"
#include "LLD_config.h"
#include "spi1.h"
#include "spi_pal_cfg.h"
#include <stddef.h>
#include "common_types.h"
#include "FreeRTimer.h"

uint8_t master_receive[SPI_BUFFER_SIZE];

// 定义一组结构体用来存放MPQ7210的ADC寄存器
MPQ_ADC_Config_t MPQ7210_ADC_Registers[APP_NUM_OF_BUCK];

// 初始化 MPQ7210_ADC_Registers 数组
void init_MPQ7210_ADC_Registers(void)
{
    // 遍历数组中的每个元素
    for (uint8_t i = 0; i < APP_NUM_OF_BUCK; ++i) {
        // 初始化 buck_value_sum
        for (uint8_t j = 0; j < 6; ++j) {
            MPQ7210_ADC_Registers[i].buck_value_sum[j] = 0.0;
        }
        // 初始化 real_buck_value
        for (uint8_t j = 0; j < 6; ++j) {
            MPQ7210_ADC_Registers[i].real_buck_value[j] = 0.0;
        }
        // 初始化 hexResult
        for (uint8_t j = 0; j < 6; ++j) {
            MPQ7210_ADC_Registers[i].hexResult[j] = 0;
        }
        // 初始化 DataBuf
        for (uint8_t j = 0; j < 6; ++j) {
            for (uint8_t k = 0; k < 3; ++k) {
                MPQ7210_ADC_Registers[i].DataBuf[j][k] = 0;
            }
        }
        // 初始化 buck1_vin_value、buck1_vout_value、buck2_vin_value、buck2_vout_value、buck_vcc_value、buck_temp_value
        for (uint8_t j = 0; j < 6; ++j) {
            for (uint8_t k = 0; k < 8; ++k) {
                MPQ7210_ADC_Registers[i].buck1_vin_value[j][k] = 0.0;
                MPQ7210_ADC_Registers[i].buck1_vout_value[j][k] = 0.0;
                MPQ7210_ADC_Registers[i].buck2_vin_value[j][k] = 0.0;
                MPQ7210_ADC_Registers[i].buck2_vout_value[j][k] = 0.0;
                MPQ7210_ADC_Registers[i].buck_vcc_value[j][k] = 0.0;
                MPQ7210_ADC_Registers[i].buck_temp_value[j][k] = 0.0;
            }
        }
    }
}

ADC_OUT_Reg_t e_mpq7210_buck_data =
{
	.no_use = 0,
	.adc_data = 0,
	.reserved16 = 0
};

void SPI_CS_DEAL(uint8_t DevType) //片选处理
{
	if(DevType == U1_MPQ7210)
	{
		BUCK_SPI_CS1_ENABLE;
		BUCK_SPI_CS2_DISABLE;
	}
	if(DevType == U2_MPQ7210)
	{
		BUCK_SPI_CS1_DISABLE;
		BUCK_SPI_CS2_ENABLE;
	}
}

void SPI_CS_CLR(void) //片选清理
{
	BUCK_SPI_CS1_DISABLE;
	BUCK_SPI_CS2_DISABLE;
}

uint8_t LLD_MPQ7210_rxtxOper(uint8_t DevType, uint8_t bWR, uint8_t addr, uint8_t* pInData, uint8_t * pOutData, uint8_t dlen)// uint8_t * pOutData1,
{
	  uint8_t buf[32];
	  uint8_t cur_byte=0;

	  if(dlen > INDATALenght)
	  {
		  return 0;
	  }
	  SPI_CS_DEAL(DevType);
	  addr<<=1;
	  if(bWR)
	  {
		  addr |= 1;
		  buf[0] = addr;
		  SPI_MasterTransferBlocking(&spi1Instance, buf, pOutData, SPI_Frames_Size, TIME_OUT_1MS);
		  SPI_CS_DEAL(DevType);
	  }
	  else
	  {
		  buf[0] = addr;
		  for(cur_byte = 0; cur_byte < dlen; cur_byte++)
		  {
			 buf[cur_byte+1] = pInData[cur_byte];
		  }
		  cur_byte += 1;
		  SPI_MasterTransferBlocking(&spi1Instance, buf, pOutData, cur_byte, TIME_OUT_1MS);
		  SPI_CS_DEAL(DevType);
	  }

	  return 0;
}

/**
 * @brief 发送函数，用于通过降额使用的SPI发送函数
 *
 * 将给定的数据表 MPQ7210_CmdTable 中的数据按照规定的格式发送到指定的设备。
 *
 * @param DevType 设备类型
 * @param status 设备状态
 * @param MPQ7210_CmdTable 数据表指针，包含要发送的数据
 * @param master_receive 接收缓冲区指针，用于存储接收到的数据
 * @param Length 数据表长度
 */
void Flash_send_fun(uint8_t DevType,uint8_t status,uint16_t *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length)
{
	uint8_t i=0;

	// 用于临时存储两个字节的数组
	uint8_t temp[2]={0};
	// 寄存器地址
	uint8_t reg_addr=0;

	// 遍历MPQ7210_CmdTable数组，每次处理两个字节
	for(i = 0; i < (Length - 1); i += 2)
	{
	    // 将MPQ7210_CmdTable数组中第i+1个元素的高8位赋值给temp数组的第一个元素
	    temp[0] = MPQ7210_CmdTable[i+1]>>8;
	    // 将MPQ7210_CmdTable数组中第i+1个元素的低8位赋值给temp数组的第二个元素
	    temp[1] = MPQ7210_CmdTable[i+1];
	    // 将MPQ7210_CmdTable数组中第i个元素赋值给reg_addr
	    reg_addr =MPQ7210_CmdTable[i];
	    // 调用LLD_MPQ7210_rxtxOper函数，进行数据传输操作
	    LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, master_receive, TIME_OUT_1MS);
	}
}

/**
 * @brief MPQ7210发送数据
 *
 * 将给定的命令表通过MPQ7210设备发送出去，并根据设备类型、状态等信息执行发送和接收操作。
 *
 * @param DevType 设备类型
 * @param status 设备状态
 * @param MPQ7210_CmdTable 命令表指针
 * @param master_receive 接收缓冲区指针
 * @param Length 命令表长度
 */
void Sl_MPQ7210_send(uint8_t DevType,uint8_t status,sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable,uint8_t *master_receive, uint8_t Length)
{
	// 遍历命令表，对每个命令进行操作
	uint8_t i = 0;
	uint8_t temp[2];
	uint8_t reg_addr;

	for(i = 0; i < Length; i++)
	{
		// 将命令的高8位存入temp[0]
		temp[0] = MPQ7210_CmdTable[i].data>>8;
		// 将命令的低8位存入temp[1]
		temp[1] = MPQ7210_CmdTable[i].data;
		// 获取命令的地址
		reg_addr =MPQ7210_CmdTable[i].addr;
		// 调用LLD_MPQ7210_rxtxOper函数执行命令发送和接收操作
		LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, master_receive, TIME_OUT_1MS);
	}
}

/**
 * @brief 把MPQ7210得ADC通道进行写入并读出对应通道得ADC数值读出
 *
 * 共进行8轮数据采集，采集后进行平均运算
 */
void MPQ7210_adc_send(uint8_t DevType, uint8_t status, sMPQ7210_wCMD_STRUCT *MPQ7210_CmdTable, MPQ_ADC_Config_t *adcDataStr, uint8_t Length)
{
	uint32_t MPQ7210_timer =0;// 开始从RTOS获取起始时间点
	uint32_t MPQ7210_timerSPAN =0;// 查询时候的时间点
	uint8_t buck_id_idx;// MPQ7210设备号变量
	sint8_t buck_ch_idx;// MPQ7210通道号变量
	uint8_t buck_cyc_idx;// 周期采样圈数变量
    uint8_t temp[2];// 新建一个数据发送得缓存空间
    uint8_t reg_addr;// 新建一个变量存放即将操作的地址
    uint16_t reg_ctrlvalue = 0;// 新建一个变量用来存放要发给ADC通道寄存器的控制指令
	bool buck_fail_flag = false;// 用于存放一个标志，判断上个阶段得SPI写入是否成功
    uint8_t adc_ctrl_temp[3] = {0};// 新建一个数组用于存放ADC控制指令的buf，用来评估是否写入成功
    uint8_t adcDataAddr[1] = {ADC_DATA_ADDR}; // 将宏的值赋给一个变量
    uint8_t adcCtrlAddr[1] = {ADC_CTRL_ADDR}; // 将宏的值赋给一个变量
	int truncated_int = 0;// 临时变量用来保留小数点前两位
	float buck_min_val = 0;// 临时变量用来存放整体浮点数
	float fractional_part = 0;// 临时变量用来存放小数点后的数
	float truncated_fraction = 0;// 临时变量用来存放小数点后的有效数
    MPQ7210_ResetTimer(&MPQ7210_timer); //简单理解为开始计时
	for (buck_cyc_idx = 0; buck_cyc_idx < ADC_DATAGET_CYC; buck_cyc_idx++)//遍历8圈
	{
		MPQ7210_GetSpanTimer(MPQ7210_timer,&MPQ7210_timerSPAN);// 检测当前过去多少时间
		if(MPQ7210_timerSPAN > TIME_OUT_7MS) //当前计时超过7ms
		{
			break;
		}
		for (buck_id_idx = BUCK1; buck_id_idx < APP_NUM_OF_BUCK; buck_id_idx++)//遍历2个Buck
		{
			for (buck_ch_idx = BUCK1VIN; buck_ch_idx < ADC_CHANNEL_COUNT; buck_ch_idx++)//遍历单个buck的6个通道
			{
				if(buck_fail_flag)
				{
					buck_ch_idx -= 1;//将ch回退到写入失败得通道
					buck_fail_flag = false;//清空写失败标志
				}
				else
				{
					temp[0] = MPQ7210_CmdTable[buck_ch_idx].data >> 8;
					temp[1] = MPQ7210_CmdTable[buck_ch_idx].data;
					reg_addr = MPQ7210_CmdTable[buck_ch_idx].addr;
					LLD_MPQ7210_rxtxOper(DevType, status, reg_addr, temp, NULL, TIME_OUT_1MS);//发送SPI命令到当前寄存器
					Sl_MPQ7210_16bit_receive(DevType, adcCtrlAddr, adc_ctrl_temp);//SPI读取<ADC控制寄存器>内容
					reg_ctrlvalue = (uint16_t)((uint8_t)(adc_ctrl_temp[2]) << 8 | (uint8_t)(adc_ctrl_temp[1]));//将读取到2份8位数据，拼接成16位数据
					ADC_CTRL_Reg_t *mpq7210_adc_sta = (ADC_CTRL_Reg_t *) & (reg_ctrlvalue);//将16位数据解析并配置到mpq7210_adc_sta结构体实例里
					if(mpq7210_adc_sta->adc_inmux == mpq7210_adc_sta->cur_stored_ch)//判断当前寄存器是否写入成功
					{
						Sl_MPQ7210_16bit_receive(DevType, adcDataAddr, adcDataStr[buck_id_idx].DataBuf[buck_ch_idx]);//SPI读取<ADC数据寄存器>内容
						MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] = (uint16_t)((uint8_t)(MPQ7210_ADC_Registers[buck_id_idx].DataBuf[buck_ch_idx][2]) << 8 | (uint8_t)(MPQ7210_ADC_Registers[buck_id_idx].DataBuf[buck_ch_idx][1]));//将获取的ADC数据拼接成16位数据
						e_mpq7210_buck_data.no_use = MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] & 0x03; // 取低2位
						e_mpq7210_buck_data.adc_data = (MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] >> 2) & 0xFF; // 取接下来的2位
						e_mpq7210_buck_data.reserved16 = MPQ7210_ADC_Registers[buck_id_idx].hexResult[buck_ch_idx] >> 10; // 取剩余的高位
						switch (buck_ch_idx)
						{
							case BUCK1VIN:
								buck_min_val = (float)((e_mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK1VOUT:
								buck_min_val = (float)((e_mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK2VIN:
								buck_min_val = (float)((e_mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCK2VOUT:
								buck_min_val = (float)((e_mpq7210_buck_data.adc_data) * (0.257));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCKVCC:
								buck_min_val = (float)((e_mpq7210_buck_data.adc_data) * (0.032));//将adc数据进行浮点运算算出实际十进制值
							break;
							case BUCKTEMP:
								buck_min_val = (2 * (float)((e_mpq7210_buck_data.adc_data) - (131.25)));
							break;
							default:
							/*TBD*/
							break;
						}	
						truncated_int = (int)buck_min_val;//割出小数点以前
						fractional_part = (float)(buck_min_val - truncated_int);//割出小数点以后
						truncated_fraction = truncf(fractional_part * 100) / 100;//保留小数点后两位
						MPQ7210_ADC_Registers[buck_id_idx].buck1_vin_value[buck_ch_idx][buck_cyc_idx] = (float)(truncated_int + truncated_fraction);
						MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] = (MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] + MPQ7210_ADC_Registers[buck_id_idx].buck1_vin_value[buck_ch_idx][buck_cyc_idx]);
					}
					else//当前寄存器写入失败
					{
						buck_fail_flag = true;//置位写失败标志
					}
				}
			}
		}
	}
	//采样8次数据以后进行均值计算
	for (buck_id_idx = BUCK1; buck_id_idx < APP_NUM_OF_BUCK; buck_id_idx++)//遍历2个Buck
	{
		for (buck_ch_idx = BUCK1VIN; buck_ch_idx < ADC_CHANNEL_COUNT; buck_ch_idx++)//遍历单个buck的6个通道
		{
			MPQ7210_ADC_Registers[buck_id_idx].real_buck_value[buck_ch_idx] = (float)(MPQ7210_ADC_Registers[buck_id_idx].buck_value_sum[buck_ch_idx] / 8);
		}
	}

}

/**
 * @brief MPQ7210 16位接收函数
 *
 * 通过MPQ7210设备的16位接口接收数据。
 *
 * @param DevType 设备类型
 * @param Read_AddrCmdTable 读取地址命令表指针
 * @param Readdata 接收数据指针
 */
void Sl_MPQ7210_16bit_receive(uint8_t DevType, uint8_t *Read_AddrCmdTable, uint8_t *Readdata)
{
	// 定义一个8位无符号整型变量reg_addr，用于存储寄存器地址
	uint8_t reg_addr;
	// 将Read_AddrCmdTable数组的第一个元素赋值给reg_addr变量
	reg_addr = Read_AddrCmdTable[0];
	// 调用LLD_MPQ7210_rxtxOper函数，进行读操作，传入参数包括DevType（设备类型）、READ_BIT（操作模式）、reg_addr（寄存器地址）、NULL（发送数据指针）、Readdata（接收数据指针）和TIME_OUT_1MS（超时时间）
	LLD_MPQ7210_rxtxOper(DevType, READ_BIT, reg_addr, NULL, Readdata, TIME_OUT_1MS);
}
