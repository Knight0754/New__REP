/*
 * Diagnostic_fault.h
 *
 *  Created on: 2023骞�11鏈�16鏃�
 *      Author: Administrator
 */

#ifndef DIAGNOSTIC_FAULT_H_
#define DIAGNOSTIC_FAULT_H_
#include "LLD_config.h"
#include "sl_softtimer.h"
#include "app_bin.h"
#include "stdbool.h"
#define STD_ON     0x01u

#define STD_OFF    0x00u
#define FB_TM     STD_ON

/* typedef enum {
    LIGHT_CONTROL_DIS = 0,  // 灯控制禁止
    LIGHT_CONTROL_EN = 1    // 灯控制允许
} LightControlStatus;

typedef struct {
    LightControlStatus binControl;   // BIN相关控制状态
    LightControlStatus btnControl;   // 硬线相关控制状态
    LightControlStatus voltageControl; // 电压相关控制状态
} LightControlConfig;

typedef struct {
    LightControlConfig highBeam;     // 远光灯控制状态
    LightControlConfig lowBeam;      // 近光灯控制状态
    LightControlConfig daytime;      // 日行灯控制状态
    LightControlConfig turn;         // 转向灯控制状态
    LightControlConfig position;     // 位置灯控制状态
} VehicleLightingControl;
 
extern VehicleLightingControl lightCnt;
*/

uint8_t dig_en_flag;

#define LIGHT_CONTROL_DIS  (0)  // 灯控制禁止
#define LIGHT_CONTROL_EN   (1)    // 灯控制允许

typedef struct {
    bool cc3_open_flag;
    bool cc3_short_flag;
    bool cc2_open_flag;
    bool cc2_short_flag;
    bool error_flagcc2;
    bool error_flagcc3;
} m_LAMP_ERROR_STATE;

typedef struct {
	bool voltageControl; // 电压相关控制状态
	m_LAMP_ERROR_STATE faultControl; // 故障相关控制状态
}m_LAMP_FAULT_CONFIG;


typedef struct {
    bool binControl;   // BIN相关控制状态
    bool keyControl;   // 硬线相关控制状态
} m_LAMP_CON_CONFIG;

typedef struct {
    m_LAMP_CON_CONFIG lowBeam;      // 近光灯控制状态
    m_LAMP_CON_CONFIG highBeam;     // 远光灯控制状态
    m_LAMP_CON_CONFIG turn;         // 转向灯控制状态
    m_LAMP_CON_CONFIG daytime;      // 日行灯控制状态
    m_LAMP_CON_CONFIG position;     // 位置灯控制状态
} m_LAMP_CONTROL;

extern uint8_t FBhblb;
extern m_LAMP_FAULT_CONFIG e_LAMP_CMD; // 声明结构体实例可供外部使用
extern m_LAMP_CONTROL lightCnt;// 声明结构体实例可供外部使用

typedef struct{
	uint8_t U8_open_VOL;
	uint8_t U8_short_VOL;
	uint8_t U8_over_VOL;
	uint8_t U8_under_VOL;
	uint8_t U8_overcurrent;
	uint8_t U8_undercurrent;
}mVOLTAGE_DIAG,*pVOLTAGE_DIAG;

typedef struct{
	mVOLTAGE_DIAG U8_NTC[3];
	mVOLTAGE_DIAG U8_BIN[3];
	uint8_t U8_Internal_temperature;//暂时没用到
	mVOLTAGE_DIAG U8_BOOST[2];
	mVOLTAGE_DIAG U8_BUCK[2][2];
	uint16_t gU16_BIN_Value_normal[3];//实时存放BIN的档位  0到5 6-s 7-o
	uint16_t gU16_NTC_Value_normal[3];//实时存放NTC的档位  0到1
}mAPP_DIAG,*pAPP_DIAG;

extern void Fault_Trigger_Check(void);
extern void perCfgVRegDiag(void);
extern mAPP_DIAG mApp_diag;
extern void Vehicle_Diagnostic_fun();
extern void diagnosic_timer(void);

#endif /* DIAGNOSTIC_FAULT_H_ */
