/*
 * hw_init.h
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#ifndef HW_INIT_H_
#define HW_INIT_H_

#include "status.h"
#include "stdint.h"
#include "ftm_common.h"
#include "ftm_hw_access.h"

#define hwuint_debug

void Flash_Init(void);
void CCIF_Handler(void);

extern void Hw_config_init(void);

#endif /* HW_INIT_H_ */
