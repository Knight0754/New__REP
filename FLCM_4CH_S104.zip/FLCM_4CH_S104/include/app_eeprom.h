/*
 * app_eeprom.h
 *
 *  Created on: 2023�?11�?10�?
 *      Author: gz06488
 */

#ifndef APP_EEPROM_H_
#define APP_EEPROM_H_

#include <stdint.h>
#include "status.h"
#include "Flash1.h"
#include "app_bin.h"

#define LB_ouvp  0
#define HB_ouvp  1

#define DRL_ouvp  0
#define PL_ouvp  1
#define TI_ouvp  2


/* If target is flash, insert this macro to locate callback function into RAM */
START_FUNCTION_DECLARATION_RAMSECTION
void CCIF_Callback(void)
END_FUNCTION_DECLARATION_RAMSECTION

typedef struct
{
	uint8_t  gU16_EEPROM_wirte_Bin[3];
	uint8_t  gU16_EEPROM_read_Bin[3];
	uint8_t  gU16_EEPROM_wirte_Leve5_Bin[3];
	uint8_t  gU16_EEPROM_read_Leve5_Bin[3];
	uint8_t  gU16_EEPROM_Diag_wirte_Bin[3];
	uint8_t  gU16_EEPROM_Diag_read_Bin[3];
	uint8_t  gU16_EEPROM_Old_read_Bin[3];
	uint8_t  gU16_EEPROM_New_read_Bin[3];
	uint16_t gU16_EEPROM_BinValue[3];

	uint8_t gU16_EEPROM_kl30_wirte_uvp;
	uint8_t gU16_EEPROM_kl30_read_uvp;

	uint8_t gU16_EEPROM_kl30_wirte_ovp;
	uint8_t gU16_EEPROM_kl30_read_ovp;

	uint8_t gU16_EEPROM_CC3_wirte_uvp[2]; //  0��LB ��·   1��HB ��·
	uint8_t gU16_EEPROM_CC3_read_uvp[2];  //  0��LB ��·   1��HB ��·

	uint8_t gU16_EEPROM_CC3_wirte_ovp[2]; //  0��LB ��·   1��HB��·
	uint8_t gU16_EEPROM_CC3_read_ovp[2];  //  0��LB ��·   1��HB��·

	uint8_t gU16_EEPROM_CC2_wirte_uvp[3]; //  0��DRL ��·   1��PL ��·  2: TI ��·
	uint8_t gU16_EEPROM_CC2_read_uvp[3];  //  0��DRL ��·   1��PL ��·  2: TI ��·

	uint8_t gU16_EEPROM_CC2_wirte_ovp[3]; //  0��DRL ��·   1��PL ��·  2: TI ��·
	uint8_t gU16_EEPROM_CC2_read_ovp[3];  //  0��DRL ��·   1��PL ��·  2: TI ��·


}mEEPROM_STA,*pEEPROM_STA;

extern flash_ssd_config_t flashSSDConfig;
extern mEEPROM_STA meeprom;
extern uint8_t r_epromdata[];
status_t MspEERomFun(void);

extern void Dflash_Read(void);
extern void Dflash_Fun(void);

#endif /* APP_EEPROM_H_ */
