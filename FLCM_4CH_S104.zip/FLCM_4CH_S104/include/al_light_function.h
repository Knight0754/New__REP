/*
 * al_light_function.h
 *
 *  Created on: 2023骞�11鏈�7鏃�
 *      Author: gz06488
 */

#ifndef AL_LIGHT_FUNCTION_H_
#define AL_LIGHT_FUNCTION_H_

#include <stdint.h>
#include "Diagnostic_fault.h"
#include "stdbool.h"

#define   LIGHT_SUB_PATTERN_MAX  5
#define   Temp_normal  0
#define LIGHT_SHOW_MODE_NORMAL      0
#define LIGHT_SHOW_MODE_WELCOME     1
#define LIGHT_SHOW_MODE_SHOW1       2
#define LIGHT_SHOW_MODE_SHOW2       3
#define LIGHT_SHOW_MODE_SHOW3       4
//#define   LB_BINNTC  1
//#define GAC_A09
#define A_cur 0
#define B_cur 1
#define C_cur 2
#define D_cur 3

typedef enum
{
	CH_HB_OFF =0u,
	CH_HB_ON,
	CH_LB_OFF,
	CH_LB_ON,
	CH_DRL_OFF,
	CH_DRL_ON,
	CH_PL_OFF,
	CH_PL_ON,
	CH_TL_OFF,
	CH_TL_ON=9u,
}STATE_CH;


typedef struct
{
	bool lampstatus_old;
	bool lampstatus_new;
	bool lamplb_sta;
	bool lamphb_sta;
	bool lampdrl_sta;
	bool lamppl_sta;
	bool lamptl_sta;
}Light_Status_flag_t;

typedef struct
{
	uint8_t  pixel_number;
	uint8_t  ppixel_index_head;
}LightFunctionPixel_t, *pLightFunctionPixel_t;

typedef struct
{
	uint16_t setp;
	uint16_t time;
    uint8_t  pduty_list_head;
}LightFunctionPattern_t, *pLightFunctionPattern_t;

void TurnOff_ALL(void);
void TurnOn_DRL(void);
void TurnOn_PL(void);
void TurnOn_TL(void);
void TurnOn_HB(void);
void TurnOn_DRL_HB(void);
void TurnOn_PL_HB(void);
void TurnOn_TL_HB(void);
void TurnOn_LB(void);
void TurnOn_DRL_LB(void);
void TurnOn_PL_LB(void);
void TurnOn_TL_LB(void);
void TurnOn_HB_LB(void);
void TurnOn_HB_LB_DRL(void);
void TurnOn_HB_LB_PL(void);
void TurnOn_HB_LB_TL(void);

extern uint8_t DRL_derating_arr[4];
extern uint8_t LB_HB_OFF_TIME;
extern uint8_t Get_LB_HB_OFF_TIME;
extern uint8_t flagC_A_drl;
extern uint8_t send_level_num1;
extern uint8_t send_level_num2;
extern uint8_t send_level_num3;
extern uint8_t flagHB;
extern uint8_t flagLB;
extern uint8_t flagDRL;
extern uint8_t flagPL;
extern uint8_t flagTI;
extern uint32_t Test_Filer1;
extern uint8_t LightShowMode;
extern uint8_t leding_flag;//用于判断灯是否处于点亮期间
extern volatile uint16_t ti_offtimer;
extern Light_Status_flag_t v_lampsta;
extern void Test_time_init(void);
extern Light_Status_flag_t v_lamgsta;//定义一个结构体变量用来查看新老点灯变化

extern void LightFunctionProcess(void);
extern void CheckLampConSta(void);
extern void EN_IOable(void);
extern void nEN_IOable(void);
extern void App_command_fun(uint8_t V_state,const uint8_t *state,mAPP_DIAG Str);
extern void Test_App_command_funMode(uint8_t V_state,const uint8_t *state,mAPP_DIAG Str);
extern void VolControDIS(void);
extern void BTNControDIS(void);
extern void VolControEN(void);

#endif /* AL_LIGHT_FUNCTION_H_ */
