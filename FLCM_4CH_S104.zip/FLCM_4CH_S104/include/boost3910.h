/*
 * boost3910.h
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#ifndef BOOST3910_H_
#define BOOST3910_H_

#include <stdbool.h>
#include <stdint.h>
#include "LLD_config.h"
#include "Cpu.h"

#define  nPWM_RT_CV1      			 4
#define  nPWM_RT_CV2     			 7
#define  nPWM_reference_CV1          6
#define  nPWM_reference_CV2          7

#define duty_0   0x000

#define duty_50   0x4000
#define duty_10   0x1000

extern void sl_boost_init(void);

#endif /* BOOST3910_H_ */
