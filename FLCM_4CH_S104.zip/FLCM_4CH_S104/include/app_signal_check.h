/*
 * app_signal_check.h
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 */

#include "al_light_function.h"
#include <stddef.h>
#include "device_registers.h"
#include "status.h"
#include "common_types.h"

#ifndef APP_SIGNAL_CHECK_H_
#define APP_SIGNAL_CHECK_H_

#define  KEY_NUM  5
#define  True_State   1
#define  False_State  0
#define  __HB_part	  0x10000000
#define  __LB_part	  0x00001000
#define  __DRL_part	  0x10000000000000
#define  __PL_part	  0x01000000

#define KEY_HB     	   0x01
#define KEY_LB         0x02
#define KEY_DRL        0x04
#define KEY_PL         0x08
#define KEY_TL         0x10
#define KEY_SIG_NUM			5
#define K_HB			0
#define K_LB			1
#define K_DRL			2
#define K_PL			3
#define K_TL			4

#define KEY_BASE_TIME_TICK       5
#define KEY_FILTER_TIME          10 //(50/KEY_BASE_TIME_TICK)
#define key_MODE_FILTER_TIME     (10u)

extern uint8_t Input_key_arr[KEY_SIG_NUM];
typedef struct
{
	uint8_t    OldState;
	uint8_t    NewState;
	uint8_t    Filer;
	uint8_t    Evnt;
	uint8_t    Check;
}SIGNAL_DectTypeDef;

SIGNAL_DectTypeDef  SIGNAL_Mode;

extern void Key_INIT(void);
extern void Sig_StatusDectProcess(void);

#endif /* APP_SIGNAL_CHECK_H_ */
