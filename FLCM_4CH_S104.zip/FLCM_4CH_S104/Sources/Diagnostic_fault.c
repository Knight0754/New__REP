/*
 * Diagnostic_fault.c
 *
 *  Created on: 2023�??11�??16�??
 *      Author: Administrator
 */

#include "Diagnostic_fault.h"
#include "app_bin.h"
#include "app_signal_check.h"
#include "MPQ7210_driver.h"
#include "al_light_function.h"
#include <math.h>
#include "stdbool.h"
#include "al_light_function.h"
#include "app_signal_check.h"
#include "LLD_Config.h"
#include "light_mgr.h"
#include "sl_softtimer.h"
#include <string.h> 

uint8_t FBhblb = 0; //lb ovp =1; hb ovp =2; hb+lb ovp =3;
uint8_t Lock_FBhb = 0;
uint8_t Lock_FBlb = 0;
uint8_t Lock_FBti = 0;
uint8_t Lock_FBpl = 0;
uint8_t Lock_FBdrl = 0;
uint8_t ovp_fl_d = 0;
uint8_t ovp_fl_l = 0;
uint8_t ovp_fl = 0;
// 定义一个诊断结构变量
mAPP_DIAG mApp_diag;//准备把它移动到app_bin
//uint8_t QuckFBFLAG = firstTimeUsed;//初始化定义一个快速反馈标志

m_mpq7210_filter e_mpq7210_adc_filter[APP_NUM_OF_BUCK];
 
void cc3_open_circuit_diagnosis(void);
void cc3_short_circuit_diagnosis(void);
void cc2_open_circuit_diagnosis(void);
void cc2_short_circuit_diagnosis(void);

m_LAMP_CONTROL lightCnt = {
	 .lowBeam = {
		.binControl = LIGHT_CONTROL_EN,
		.keyControl = LIGHT_CONTROL_DIS,
	 },
	 .highBeam = {
		.binControl = LIGHT_CONTROL_EN,
		.keyControl = LIGHT_CONTROL_DIS,
	 },
	 .turn = {
		.binControl = LIGHT_CONTROL_EN,
		.keyControl = LIGHT_CONTROL_DIS,
	 },
	 .position = {
		.binControl = LIGHT_CONTROL_EN,
		.keyControl = LIGHT_CONTROL_DIS,
	 },
	 .daytime = {
		.binControl = LIGHT_CONTROL_EN,
		.keyControl = LIGHT_CONTROL_DIS,
	 },
};
m_LAMP_FAULT_CONFIG e_LAMP_CMD  = {
	.voltageControl = LIGHT_CONTROL_DIS,//无作用
	.faultControl.cc3_open_flag = LIGHT_CONTROL_EN,
	.faultControl.cc3_short_flag = LIGHT_CONTROL_EN,
	.faultControl.cc2_open_flag = LIGHT_CONTROL_EN,
	.faultControl.cc2_short_flag = LIGHT_CONTROL_EN,
	.faultControl.error_flagcc2 = LIGHT_CONTROL_EN,
	.faultControl.error_flagcc3 = LIGHT_CONTROL_EN,
};

void Fault_Trigger_Check(void)
{
	cc3_open_circuit_diagnosis();
	cc3_short_circuit_diagnosis();
	cc2_open_circuit_diagnosis();
	cc2_short_circuit_diagnosis();
	if((e_LAMP_CMD.faultControl.cc2_short_flag == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.cc2_open_flag == LIGHT_CONTROL_EN))
	{
		e_LAMP_CMD.faultControl.error_flagcc2 = LIGHT_CONTROL_EN;
	}
	if((e_LAMP_CMD.faultControl.cc3_short_flag == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.cc3_open_flag == LIGHT_CONTROL_EN))
	{
		e_LAMP_CMD.faultControl.error_flagcc3 = LIGHT_CONTROL_EN;
	}
}

/**
 * cc2短路诊断函数--较为重要涉及关灯严格审核
*/
void cc2_short_circuit_diagnosis(void)
{
	float t_mpq7210_value_val = 40.0;//设置保守值，不轻易触发短路
	if(Input_key_arr[K_TL] == CH_TL_ON)
	{
		t_mpq7210_value_val = mpq7210_tl_uv_value;
	}
	else
	{
		if(ti_offtimer == 0)
		{
			if(Input_key_arr[K_DRL] == CH_DRL_ON)
			{
				t_mpq7210_value_val = mpq7210_drl_uv_value;
			}
			else
			{
				t_mpq7210_value_val = mpq7210_pl_uv_value;
			}
		}
	}
	if(MPQ7210_ADC_Registers[BUCK1].real_buck_value[BUCK2VOUT] < t_mpq7210_value_val)
	{
		e_LAMP_CMD.faultControl.cc2_short_flag = LIGHT_CONTROL_DIS;//设置cc2短路故障标志为真
		e_LAMP_CMD.faultControl.error_flagcc2 = LIGHT_CONTROL_DIS;
	}
	else
	{
		e_LAMP_CMD.faultControl.cc2_short_flag = LIGHT_CONTROL_EN;//设置cc2短路故障标志为真

	}
}
/**
 * cc2开路诊断函数
*/
void cc2_open_circuit_diagnosis(void)
{
	//if(Input_key_arr[K_DRL] == CH_DRL_)
	if(MPQ7210_ADC_Registers[BUCK1].real_buck_value[BUCK2VOUT] >= (MPQ7210_ADC_Registers[BUCK1].real_buck_value[1] - delta_PL_Buck))//CC3开路
	{
		e_LAMP_CMD.faultControl.cc2_open_flag = LIGHT_CONTROL_DIS;//设置cc2短路故障标志为真
		e_LAMP_CMD.faultControl.error_flagcc2 = LIGHT_CONTROL_DIS;
	}
	else
	{
		e_LAMP_CMD.faultControl.cc2_open_flag = LIGHT_CONTROL_EN;//设置cc2短路故障标志为真
	}
}
/**
 * cc3短路诊断函数--较为重要涉及关灯严格审核
*/
void cc3_short_circuit_diagnosis(void)
{

	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] < mpq7210_uv_value)
	{
		e_LAMP_CMD.faultControl.cc3_short_flag = LIGHT_CONTROL_DIS;//设置cc2短路故障标志为真
		e_LAMP_CMD.faultControl.error_flagcc3 = LIGHT_CONTROL_DIS;
	}
	else
	{
		e_LAMP_CMD.faultControl.cc3_short_flag = LIGHT_CONTROL_EN;//设置cc2短路故障标志为真
	}
}
/**
 * cc3开路诊断函数
*/
void cc3_open_circuit_diagnosis(void)
{
	if(MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VOUT] >= (MPQ7210_ADC_Registers[BUCK2].real_buck_value[BUCK1VIN] - delta_Buck))//CC3开路
	{
		e_LAMP_CMD.faultControl.cc3_open_flag = LIGHT_CONTROL_DIS;//设置cc2短路故障标志为真
		e_LAMP_CMD.faultControl.error_flagcc3 = LIGHT_CONTROL_DIS;
	}
	else
	{
		e_LAMP_CMD.faultControl.cc3_open_flag = LIGHT_CONTROL_EN;//设置cc2短路故障标志为真
	}
}


/**
 * @brief 根据配置信息向MPQ7210的ADC发送写命令
 *
 * 根据用户按下的按键，检查是否需要向MPQ7210的ADC发送写命令。
 * 如果是DRL、PL或TL键，则向MPQ7210的ADC1发送写命令；
 * 如果是HB或LB键，则向MPQ7210的ADC2发送写命令。
 */
void perCfgVRegDiag(void)
{
	// 检查是否按下DRL、PL或TL键
	if((Input_key_arr[K_DRL] == CH_DRL_ON) || (Input_key_arr[K_PL] == CH_PL_ON) || (Input_key_arr[K_TL] == CH_TL_ON))
	{
		// 如果是，则向MPQ7210的ADC1发送写命令
		MPQ7210_adc_send(U1_MPQ7210, WRITE_BIT, ADC_CmdTable, MPQ7210_ADC_Registers, ADC_length, &e_mpq7210_adc_filter[U1_MPQ7210]);
	}
	// 检查是否按下HB或LB键
	if((Input_key_arr[K_HB] == CH_HB_ON) || (Input_key_arr[K_LB] == CH_LB_ON))
	{
		// 如果是，则向MPQ7210的ADC2发送写命令
		MPQ7210_adc_send(U2_MPQ7210, WRITE_BIT, ADC_CmdTable, MPQ7210_ADC_Registers, ADC_length, &e_mpq7210_adc_filter[U2_MPQ7210]);
	}
}

//故障判断使能标志
uint8_t dig_en_flag = 0;

/**
 * @brief 初始化诊断周期任务
 *
 * 此函数用于初始化诊断周期任务。
 */
void diagnosic_timer(void)
{
		if(Input_key_arr[0] == CH_HB_ON && Lock_FBhb==0)
		{
			Lock_FBhb = 1;
			E11_EN_FB2_HB_FB_ENABLE;//HB FB2
		}
		if(Input_key_arr[0] == CH_HB_OFF)
		{
			Lock_FBhb = 0;
			E11_EN_FB2_HB_FB_DISABLE;
		}
		if(Input_key_arr[1] == CH_LB_ON && Lock_FBlb==0) 
		{
			Lock_FBlb = 1;
			D1_EN_FB1_LB_FB_ENABLE;//LB FB1
		}
		if(Input_key_arr[1] == CH_LB_OFF)
		{
			Lock_FBlb = 0;
			D1_EN_FB1_LB_FB_DISABLE;
		}
		if(Input_key_arr[4] == CH_TL_ON && Lock_FBti==0)
		{
			Lock_FBti = 1;
			D0_EN_FB3_TL_FB_ENABLE;
		}
		if(Input_key_arr[4] == CH_TL_OFF)
		{
			Lock_FBti = 0;
			D0_EN_FB3_TL_FB_DISABLE;
		}
		if((Input_key_arr[2] == CH_DRL_ON) && Lock_FBdrl==0)  //DRL PL  E10
		{
			Lock_FBdrl = 1;
			E10_EN_FB_DRL_PL_ENABLE;
		}
		if(((Input_key_arr[3] == CH_PL_ON)) && Lock_FBpl==0)  //DRL PL  E10
		{
			Lock_FBpl = 1;
			E10_EN_FB_DRL_PL_ENABLE;
		}
		if((Input_key_arr[2] == CH_DRL_OFF) && (Input_key_arr[3] == CH_PL_OFF) )
		{
			Lock_FBdrl = 0;
			Lock_FBpl = 0;
			E10_EN_FB_DRL_PL_DISABLE;
		}
}

uint8_t hblb_Diagovp(uint8_t ovp)
{
	if(ovp == 0 && ovp_fl == 0)
	{
		B12_EN_LED2_HB_DISABLE;//关闭HB
		B13_EN_LED1_LB_ENABLE;
		ovp_fl = 1;
		FBhblb = 4;
		return FBhblb;
	}
	else if((ovp == 1 && ovp_fl == 1) || (FBhblb == 1))
	{
		//判定为HB故障
		B12_EN_LED2_HB_DISABLE;//关闭HB
		B13_EN_LED1_LB_ENABLE;
		E11_EN_FB2_HB_FB_DISABLE;
		//ovp_fl_d = 0;
		ovp_fl = 0;
		FBhblb = 1;
		return FBhblb;
	}
	else if(ovp == 0 && ovp_fl == 1 )
	{
		//判定为LB故障或者LBHB故障
		B12_EN_LED2_HB_ENABLE;//打开HB
		B13_EN_LED1_LB_DISABLE;//关闭LB
		//ovp_fl_d =1;
		//ovp_fl_l =1;
		FBhblb = 5;
		ovp_fl = 0;
		return FBhblb;
	}
	else{}
	if((ovp == 1 && FBhblb == 5) || (FBhblb == 2))
	{
		//判定LB故障
		B12_EN_LED2_HB_ENABLE;//打开HB
		B13_EN_LED1_LB_DISABLE;//关闭LB
		D1_EN_FB1_LB_FB_DISABLE;
		//ovp_fl_d = 0;
		ovp_fl = 0;
		//ovp_fl_l = 0;
		FBhblb = 2;
		return FBhblb;
	}
	 else if((ovp == 0 && FBhblb == 5)|| (FBhblb == 2))
	{
		//判定LBHB故障
		//Open_IC_CC3_EN1_DISABLE;
		//B13_EN_LED1_LB_DISABLE;//关闭HB
		//B12_EN_LED2_HB_DISABLE;//关闭LB
		E11_EN_FB2_HB_FB_DISABLE;
		D1_EN_FB1_LB_FB_DISABLE;
		//ovp_fl_d = 0;
		ovp_fl = 0;
		//ovp_fl_l = 0;
		FBhblb = 3;
		return FBhblb;
	}

	else{}

	/* //uint8_t ovp = ~ovp1;
	if(ovp == 0 && ovp_fl == 0)
	{
		B12_EN_LED2_HB_DISABLE;//关闭HB
		B13_EN_LED1_LB_ENABLE;
		ovp_fl = 1;
		FBhblb = 4;
		return FBhblb;
	}
	else if(ovp == 1 && ovp_fl == 1)
	{
		//判定为HB故障
		B12_EN_LED2_HB_DISABLE;//关闭HB
		B13_EN_LED1_LB_ENABLE;
		E11_EN_FB2_HB_FB_DISABLE;
		ovp_fl_d = 0;
		ovp_fl = 0;
		//ovp_fl_l = 0;
		FBhblb = 1;
		return FBhblb;
	}
	else if(ovp == 0 && ovp_fl == 1 && ovp_fl_l == 0)
	{
		//判定为LB故障或者LBHB故障
		B12_EN_LED2_HB_ENABLE;//打开HB
		B13_EN_LED1_LB_DISABLE;//关闭LB
		ovp_fl_d =1;
		ovp_fl_l =1;
		FBhblb = 5;
		//ovp_fl = 0;
		return FBhblb;
	}
	else{}

	 if(ovp == 1 && ovp_fl_d == 1)
	{
		//判定LB故障
		B12_EN_LED2_HB_ENABLE;//打开HB
		B13_EN_LED1_LB_DISABLE;//关闭LB
		D1_EN_FB1_LB_FB_DISABLE;
		ovp_fl_d = 0;
		ovp_fl = 0;
		//ovp_fl_l = 0;
		FBhblb = 2;
		return FBhblb;
	}
	 else if(ovp == 0 && ovp_fl_d == 1)
	{
		//判定LBHB故障
		//Open_IC_CC3_EN1_DISABLE;
		//B13_EN_LED1_LB_DISABLE;//关闭HB
		//B12_EN_LED2_HB_DISABLE;//关闭LB
		E11_EN_FB2_HB_FB_DISABLE;
		D1_EN_FB1_LB_FB_DISABLE;
		ovp_fl_d = 0;
		ovp_fl = 0;
		ovp_fl_l = 0;
		FBhblb = 3;
		return FBhblb;
	}

	else{}
	 */

	return 7;
	
}
void Vehicle_Diagnostic_fun()
{
#if (FB_TM == STD_ON)
	if((lightCnt.highBeam.keyControl == LIGHT_CONTROL_EN) && (lightCnt.lowBeam.keyControl == LIGHT_CONTROL_EN))
	{
		hblb_Diagovp(e_LAMP_CMD.faultControl.cc3_open_flag);
	}
	else{
			if(lightCnt.highBeam.keyControl == LIGHT_CONTROL_EN)
			{
				if(lightCnt.highBeam.binControl == LIGHT_CONTROL_DIS)
				{
					E11_EN_FB2_HB_FB_DISABLE;
				}
				if(e_LAMP_CMD.faultControl.error_flagcc3 == LIGHT_CONTROL_DIS)
				{
					E11_EN_FB2_HB_FB_DISABLE;
					if(e_LAMP_CMD.faultControl.cc3_open_flag == LIGHT_CONTROL_DIS)
					{
							;
					}
					if(e_LAMP_CMD.faultControl.cc3_short_flag == LIGHT_CONTROL_DIS)
					{
							;
					}
					

				}
				if((lightCnt.highBeam.binControl == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.error_flagcc3 == LIGHT_CONTROL_EN))
				{
					E11_EN_FB2_HB_FB_ENABLE;
				}
			}
			else{
				E11_EN_FB2_HB_FB_DISABLE;
			}
			if(lightCnt.lowBeam.keyControl == LIGHT_CONTROL_EN)
			{
				if(lightCnt.lowBeam.binControl == LIGHT_CONTROL_DIS)
				{
					D1_EN_FB1_LB_FB_DISABLE;
				}
				if(e_LAMP_CMD.faultControl.error_flagcc3 == LIGHT_CONTROL_DIS)
				{
					D1_EN_FB1_LB_FB_DISABLE;
					if(e_LAMP_CMD.faultControl.cc3_open_flag  == LIGHT_CONTROL_DIS)
					{
							;
					}
					if(e_LAMP_CMD.faultControl.cc3_short_flag == LIGHT_CONTROL_DIS)
					{
							;
					}


				}
				if((lightCnt.lowBeam.binControl == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.error_flagcc3 == LIGHT_CONTROL_EN))
				{
					D1_EN_FB1_LB_FB_ENABLE;
				}
			}
			else{
				D1_EN_FB1_LB_FB_DISABLE;
			}
		}

	
	if((lightCnt.daytime.keyControl == LIGHT_CONTROL_EN) || (lightCnt.position.keyControl == LIGHT_CONTROL_EN))
	{
		if(lightCnt.daytime.binControl == LIGHT_CONTROL_DIS)
		{
			E10_EN_FB_DRL_PL_DISABLE;
		}
		if(e_LAMP_CMD.faultControl.error_flagcc2 == LIGHT_CONTROL_DIS)
		{
			E10_EN_FB_DRL_PL_DISABLE;
			if(e_LAMP_CMD.faultControl.cc2_open_flag == LIGHT_CONTROL_DIS)
			{
					;
			}
			if(e_LAMP_CMD.faultControl.cc2_short_flag  == LIGHT_CONTROL_DIS)
			{
					;
			}


		}
		if((lightCnt.daytime.binControl == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.error_flagcc2 == LIGHT_CONTROL_EN))
		{
			E10_EN_FB_DRL_PL_ENABLE;
		}
	}
	else{
		E10_EN_FB_DRL_PL_DISABLE;
	}
	if(lightCnt.turn.keyControl == LIGHT_CONTROL_EN)
	{
		if(lightCnt.turn.binControl == LIGHT_CONTROL_DIS)
		{
			D0_EN_FB3_TL_FB_DISABLE;
		}
		if(e_LAMP_CMD.faultControl.error_flagcc2 == LIGHT_CONTROL_DIS)
		{
			D0_EN_FB3_TL_FB_DISABLE;
			if(e_LAMP_CMD.faultControl.cc2_open_flag == LIGHT_CONTROL_DIS)
			{
					;
			}
			if(e_LAMP_CMD.faultControl.cc2_short_flag == LIGHT_CONTROL_DIS)
			{
					;
			}
		}
		if((lightCnt.turn.binControl == LIGHT_CONTROL_EN) && (e_LAMP_CMD.faultControl.error_flagcc2 == LIGHT_CONTROL_EN))
		{
			D0_EN_FB3_TL_FB_ENABLE;
		}
	}
	else{
		D0_EN_FB3_TL_FB_DISABLE;
	}


#endif
}






