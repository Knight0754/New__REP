/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/

/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include "APP_Demo.h" 
#include "bootloader_debug.h" 

  volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */
#include "hal_pwm.h"
#include "hw_init.h"
#include "LLD_Config.h"
#include "sl_softtimer.h"
#include "boost3910.h"
#include "app_signal_check.h"
#include "app_bin.h"
#include "al_light_function.h"
#include "MPQ7210_driver.h"
#include "Diagnostic_fault.h"
#include "watchdog_hal.h"
#include "timer_hal.h"
#include "_Rtos.h"
#include "_Tasks.h"
#include "FreeRTimer.h"


/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
    WDOG_DRV_Deinit(0);
    APP_Demo_Init();
    Pin_state_init();
    Hw_config_init();
    BINControEN();
    sl_adc_init();
    sl_boost_init();
    _Rtos_Init();
    _Rtos_Task();
    /* For example: for(;;) { } */
    for(;;)
    {
    }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
