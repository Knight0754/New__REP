/*
 * sl_softtimer.c
 *
 *  Created on: 2023年11月7日
 *      Author: gz06488
 */

#include "sl_softtimer.h"
#include "device_registers.h"
#include "pins_gpio_hw_access.h"
#if defined(FEATURE_PINS_DRIVER_USING_SIUL2)
#include "pins_siul2_hw_access.h"
#elif defined(FEATURE_PINS_DRIVER_USING_PORT)
#include "pins_port_hw_access.h"
#endif
#include "LLD_config.h"

static volatile SL_TIMER_t slBaseTimerArry[SL_BASeTIMER_MAX];
static uint8_t  slBaseTimerCnt=0;
uint16_t gU16_Millisecond = MIN_TIMECOUNTER_NUM;

/**
 * @brief 初始化基础定时器
 *
 * 将基础定时器计数器初始化为0。
 */
void sl_BaseTimerInit(void)
{
	// 初始化基础定时器计数器为0
	slBaseTimerCnt =0;
}

/**
 * @brief 获取软件计时器索引
 *
 * 如果 slBaseTimerCnt 小于 511，则将其加 1，并返回 slBaseTimerCnt 减去 1 的值。
 * 如果 slBaseTimerCnt 大于等于 511，则返回 0x200u。
 *
 * @return sstTimerIndex_t 软件计时器索引
 */
sstTimerIndex_t sl_BaseTimer_GreatSoftTimer(void)
{
	// 如果slBaseTimerCnt小于511
	if(slBaseTimerCnt < SL_BASeTIMER_MAX-1)
	{
		// 将slBaseTimerCnt加1
		slBaseTimerCnt++;
		// 返回slBaseTimerCnt减去1的值
		return (slBaseTimerCnt -1 );
	}
	// 返回0x200u
	return SL_BASeTIMER_MAX;
}

/**
 * @brief 刷新定时器
 *
 * 根据给定的索引刷新定时器。
 *
 * @param index 定时器索引
 */
void sl_RefreshTimer(sstTimerIndex_t index)
{
	// 如果索引小于基础定时器数量
	if(index < slBaseTimerCnt)
	{
		// 将基础定时器数组对应索引的定时器重置为0
		slBaseTimerArry[index].stimer = 0;
		// 将基础定时器数组对应索引的计时器刻度重置为周期值
		slBaseTimerArry[index].ticks = slBaseTimerArry[index].period;
	}
}

/**
 * @brief 设置定时器周期
 *
 * 根据给定的索引和周期值，设置定时器的周期。
 *
 * @param index 定时器索引
 * @param period_ms 周期值，单位为毫秒
 */
void sl_SetTimerPeriod(sstTimerIndex_t index, uint16_t period_ms)
{
	// 判断索引是否小于基础定时器数量
	if(index < slBaseTimerCnt)
	{
	   // 设置基础定时器数组对应索引的周期值
	   slBaseTimerArry[index].period = period_ms;
	}
}

/**
 * @brief 以1ms为基准处理时间
 *
 * 该函数用于以1ms为基准处理时间，通过遍历slBaseTimerArry数组，对其中每个元素的stimer成员进行递增操作。
 *
 */
void sl_TimeBase1msProcess(void)
{
   // 定义一个8位无符号整数变量i
   uint8_t i;

   // 循环遍历slBaseTimerCnt次
   for(i=0; i<slBaseTimerCnt; i++)
   {
	  // 如果slBaseTimerArry数组中第i个元素的stimer成员不等于0xffff
	  if(slBaseTimerArry[i].stimer != 0xffff)
	  {
		 // 将slBaseTimerArry数组中第i个元素的stimer成员加1
		 slBaseTimerArry[i].stimer++;
	  }
   }
}

/**
 * @brief 判断定时器是否超时
 *
 * 根据给定的定时器索引，判断该定时器是否超过了设定的ticks。
 *
 * @param index 定时器索引
 *
 * @return 如果定时器超时，返回1；否则返回0
 */
uint8_t sl_IsTimerExceed(sstTimerIndex_t index)
{
    uint8_t fg =0;

	// 判断索引是否小于基础定时器数量
	if(index < slBaseTimerCnt)
    {
	   // 判断定时器是否启动
	   if(slBaseTimerArry[index].stimer)
	   {
	   	  // 判断定时器是否超过设定的ticks
	   	  if(slBaseTimerArry[index].stimer >= slBaseTimerArry[index].ticks )
	   	  {
	   		  // 超过ticks，将ticks重置为0
	   		  slBaseTimerArry[index].ticks = 0;  //exceed
			  fg =1;
			}
			else
			{
				// 未超过ticks，减去已过去的stimer时间
				slBaseTimerArry[index].ticks -= slBaseTimerArry[index].stimer; //
			}
	   	  // 将stimer重置为0
	   	  slBaseTimerArry[index].stimer = 0;
	   }
	}
	// 返回fg值，表示定时器是否超过ticks
	return fg;
}



uint16_t GetCurTime(void)
{
    // 返回当前毫秒数
    return gU16_Millisecond;
}

/**
 * @brief 获取时间差
 *
 * 计算给定的旧时间与当前毫秒数之间的时间差。
 *
 * @param OldTime 旧时间
 *
 * @return 返回时间差
 */
static uint16_t GetTimeDiff(uint16_t OldTime)
{
	uint16_t DiffTime;
	// 如果旧时间大于当前毫秒数
	if(OldTime > gU16_Millisecond)
	{
		// 计算时间差，从最大时间计数器数减去旧时间
		DiffTime = MAX_TIMECOUNTER_NUM - OldTime;
		// 加上当前毫秒数，得到实际时间差
		DiffTime += gU16_Millisecond;
	}
	else
	{
		// 如果旧时间小于等于当前毫秒数
		// 直接用当前毫秒数减去旧时间，得到实际时间差
		DiffTime = gU16_Millisecond - OldTime;
	}
	// 返回时间差
	return DiffTime;
}

/**
 * @brief 判断时间是否超时
 *
 * 根据给定的旧计时器和时间阈值，判断时间是否超时。
 *
 * @param OldTimer 旧计时器
 * @param ThrottleTimeMs 时间阈值（毫秒）
 *
 * @return 如果时间差大于等于给定的时间阈值，返回1；否则返回0
 */
uint8_t IsTimeOver(uint16_t OldTimer, uint16_t ThrottleTimeMs)
{
    // 初始化返回值，默认为0
    uint8_t retVal = 0u;

    // 如果时间差大于等于给定的时间阈值
    if(GetTimeDiff(OldTimer) >= ThrottleTimeMs)
    {
        // 将返回值设置为1
    	retVal = 1u;
    }

    // 返回结果
    return retVal;
}

