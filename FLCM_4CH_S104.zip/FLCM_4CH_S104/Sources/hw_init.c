/*
 * hw_init.c
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#include "hw_init.h"
#include "hal_pwm.h"
#include "cpu.h"
#include "sl_softtimer.h"
#include "LLD_config.h"
#include "spi_pal_cfg.h"
#include "app_eeprom.h"
#include "al_light_function.h"

/**
 * @brief 初始化ADC硬件
 *
 * 此函数用于初始化ADC硬件。
 */
void ADC_Hardware_INIT(void)
{
	// 初始化ADC
	ADC_DRV_ConfigConverter(INST_ADCONV1, &adConv1_ConvConfig0);
	// 自动校准ADC
	ADC_DRV_AutoCalibration(INST_ADCONV1);
}

/**
 * @brief 初始化Flash
 *
 * 安装中断处理程序，启用中断和全局中断，初始化Flash驱动。
 */
void Flash_Init(void)
{

	// 安装中断处理程序
	INT_SYS_InstallHandler(FTFC_IRQn, CCIF_Handler, (isr_t*) 0);

	// 启用中断
	INT_SYS_EnableIRQ(FTFC_IRQn);

	// 启用全局中断
	INT_SYS_DisableIRQGlobal();

	// 初始化Flash驱动
	FLASH_DRV_Init(&Flash1_InitConfig0, &flashSSDConfig);

	//配置flash性能和访问权限
	// MSCM->OCMDR[0u] |= MSCM_OCMDR_OCM1(0x3u);
	// MSCM->OCMDR[1u] |= MSCM_OCMDR_OCM1(0x3u);
	// 初始化Flash。
	//FLASH_DRV_Init(&Flash1_InitConfig0, &flashSSDConfig);

	//检查是否已分配EE（EEPROM Emulation Feature）空间
	if(0 == flashSSDConfig.EEESize)
	{
		// 分区这个函数必须使用
		 // 选配分出内存分区段
		 // uEEEDataSizeCode              FCCOB4  0X2选择4K 的EEPROM空间
		 // uDEPartitionCode              FCCOB5  0x8选择64K 的EEPROM空间
		 // uCSEcKeySize                  FCCOB1  CSEc加密服务选项  无
		 // uSFE                          FCCOB2  仅验证属性关闭
		 // flexRamEnableLoadEEEData      FCCOB3  复位期间是否加载数据  加载
		//分区配置时备份区size = EEESize*16 分区代码参考芯片的DataSheet
		//
				// 将 FlexRAM 配置为 EEPROM，将 FlexNVM 配置为 EEPROM 备份区域，
				// EEEDataSizeCode = 0x02u：EEPROM 大小 = 4 KB
				// DEPartitionCode = 0x08u：EEPROM 备份大小 = 64 KB
		//若未分配EEE，则执行分配指令
		//FLASH_DRV_DEFlashPartition用于分区配置，参数设置EEPROM大小和备份区大小
		//FLASH_DRV_DEFlashPartition(&flashSSDConfig, 0x0F, 0x00, 0x0u, false, true);
		FLASH_DRV_DEFlashPartition(&flashSSDConfig, 0x03, 0x08, 0x0u, false, true);
		//重新分配后,一定要记得重新初始化
		FLASH_DRV_Init(&Flash1_InitConfig0, &flashSSDConfig);

		//
		   // 选配分出内存分区段
		   // flexRamFuncCode   FCCOB1   EEE_ENABLE 使能FlexRAM 模拟EEPROM
		   // byteOfQuickWrite  FCCOB4 FCCOB5
		   //pEEPROMStatus     EEPROM状态  结构体中三个状态
		   //
		//设置FlexRAM功能，用作EEPROM模拟
		//启动EEPROM
		FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_ENABLE, 0x00, NULL);
	}
	else    // FLexRAM is already configured as EEPROM
	{
		// 如果已经配置了FlexRAM作为EEPROM，只需设置FlexRAM功能
		FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_ENABLE, 0x00u, NULL);
	}

	INT_SYS_EnableIRQGlobal();
}

/**
 * @brief CCIF 中断处理函数
 *
 * 当 Flash 命令完成时，调用此函数处理中断。
 *
 */
void CCIF_Handler(void)
{
    // 关闭Flash命令完成中断
    /* Disable Flash Command Complete interrupt */
    FTFx_FCNFG &= (~FTFx_FCNFG_CCIE_MASK);

    return;
}

/**
 * @brief 初始化硬件配置
 *
 * 此函数用于初始化硬件设备的配置，包括 EDMA、ADC、Flash、FTM 和 SPI。
 */
void Hw_config_init(void)
{
	// 初始化 EDMA 驱动
	EDMA_DRV_Init(&dmaController1_State, &dmaController1_InitConfig0, edmaChnStateArray, edmaChnConfigArray, EDMA_CONFIGURED_CHANNELS_COUNT);

	// 初始化 ADC 硬件
	ADC_Hardware_INIT();

	// 初始化 Flash
	Flash_Init();

	// 初始化 FTM 定时器
	ftmTimer_init();

	// 初始化 FTM PWM 驱动，用于 PWM1
	FTM_DRV_InitPwm(INST_FLEXTIMER_PWM1, &flexTimer_pwm1_PwmConfig);

	// 初始化 FTM PWM 驱动，用于 PWM2
	FTM_DRV_InitPwm(INST_FLEXTIMER_PWM2, &flexTimer_pwm2_PwmConfig);

	// 初始化 SPI 主模式
	SPI_MasterInit(&spi1Instance, &spi1_MasterConfig0);
}
