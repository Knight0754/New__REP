/*
 * app_eeprom.c
 *
 *  Created on: 2023�?11�?10�?
 *      Author: gz06488
 */


#include "app_eeprom.h"
#include "app_bin.h"
#include <string.h>
#include "stdbool.h"
#include "Diagnostic_fault.h"

/*声明一个由FlashInit初始化的FLASH配置结构体，并将被所有FLASH操作使用*/
flash_ssd_config_t flashSSDConfig;
uint8_t bin_eeprom_flag = 0;//定义一个内存写入过的标志
#define DF_BUFFER_SIZE    0x100u          //定义可以存放的数据的最大内容
uint8_t sourceBuffer[DF_BUFFER_SIZE];  // 存放写入数据的buf
uint8_t readData[DF_BUFFER_SIZE];      // 用于存储读取的数据的buf
uint8_t readData_temp[DF_BUFFER_SIZE];      // 临时用于存储读取的数据的buf
uint32_t address;
uint32_t size;
flash_callback_t pCallBack;

uint8_t epromflag[1] = {0}; // EEPROM写入的标志位
uint8_t Reepromflag[1] = {0}; // EEPROM再次写入的标志位

mEEPROM_STA meeprom=
{
	.gU16_EEPROM_wirte_Bin={0,0,0,},
	.gU16_EEPROM_read_Bin = {0, 0, 0}, // 默认的EEPROM读取值为0
};

status_t MspEERomRead(uint16_t addr,  uint8_t  *pdata, uint16_t size)
{
	uint16_t i;
	uint32_t dstaddr;

    dstaddr = flashSSDConfig.EERAMBase + addr;

    for(i=0; i<size; i++)
    {
    	*pdata++ = *((uint8_t *)dstaddr++);
    }
    return STATUS_SUCCESS;
}

status_t MspEERomWrite(uint16_t addr, uint8_t *pdata, uint16_t size)
{
    uint32_t dstaddr;
    dstaddr = flashSSDConfig.EERAMBase + addr;
    return(FLASH_DRV_EEEWrite(&flashSSDConfig, dstaddr, size, pdata));
}

/**
 * @brief 读取DFlash中的数据
 *
 * 将DFlash中的数据读取到指定的缓冲区中。
 */
void Dflash_Read(void)
{

	// 设置起始地址为DFlash的基地址
	address = flashSSDConfig.DFlashBase;
	// 设置读取的数据大小为缓冲区大小
	size = DF_BUFFER_SIZE;
	// 循环读取数据
	for(int i = 0; i < size; i++)
    {
		// 从DFlash中读取一个8位数据到readData数组中
		readData[i] = *(volatile uint8_t *)(address + i);  // 读取一个8位数据
		// 将读取的数据暂时保存到readData_temp数组中
		readData_temp[i] = readData[i];
		// 将读取的数据最终保存到sourceBuffer数组中
		sourceBuffer[i] = readData_temp[i];
    }
	if(readData[1] == 255 && readData[2] == 255 && readData[3] == 255 )
	{
		bin_eeprom_flag = 0;
	}
}

uint8_t epromdata[BIN_COUNTNUM][BINLEVEL]={0};

uint8_t testdata[16]={0};


uint8_t read_BIN_Sta(void)
{
	meeprom.gU16_EEPROM_wirte_Bin[0] = adc_sta.gU16_BinValue_eeprom[0];
	meeprom.gU16_EEPROM_wirte_Bin[1] = adc_sta.gU16_BinValue_eeprom[1];
	meeprom.gU16_EEPROM_wirte_Bin[2] = adc_sta.gU16_BinValue_eeprom[2];
	meeprom.gU16_EEPROM_wirte_Leve5_Bin[0] = adc_sta.gU16_BinValue_Leve5_eeprom[0];
	meeprom.gU16_EEPROM_wirte_Leve5_Bin[1] = adc_sta.gU16_BinValue_Leve5_eeprom[1];
	meeprom.gU16_EEPROM_wirte_Leve5_Bin[2] = adc_sta.gU16_BinValue_Leve5_eeprom[2];
	meeprom.gU16_EEPROM_Diag_wirte_Bin[0]=adc_sta.gU16_Bin_Dig[0];
	meeprom.gU16_EEPROM_Diag_wirte_Bin[1]=adc_sta.gU16_Bin_Dig[1];
	meeprom.gU16_EEPROM_Diag_wirte_Bin[2]=adc_sta.gU16_Bin_Dig[2];
	for(uint8_t i = 0;i < BIN_COUNTNUM; i++)
	{
		//上报BIN故障
		if( ((meeprom.gU16_EEPROM_read_Bin[i] == 0) || (meeprom.gU16_EEPROM_read_Bin[i] > 5)) || ((meeprom.gU16_EEPROM_read_Leve5_Bin[i] == 0) || (meeprom.gU16_EEPROM_read_Leve5_Bin[i] > 5)))  //(meeprom.gU16_EEPROM_wirte_Bin[i] != 0) &&
		{
			if((adc_sta.gU16_Bin_Dig[i] == 0) )//0:正常  1：短�?  2：开�?
			{
				adc_sta.BIN_short[i]=false;
				adc_sta.BIN_open[i]=false;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =0;//
				bin_eeprom_flag = 1;
			}
			if((adc_sta.gU16_Bin_Dig[i] == 1) )//0:正常  1：短�?  2：开�?
			{
				adc_sta.BIN_short[i]=true;
				adc_sta.BIN_open[i]=false;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =1;//short
				bin_eeprom_flag = 1;
			}
			if((adc_sta.gU16_Bin_Dig[i] == 2) )//0:正常  1：短�?  2：开�?
			{
				adc_sta.BIN_short[i]=false;
				adc_sta.BIN_open[i]=true;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =2; //open
				bin_eeprom_flag = 1;
			}
		}
		if ( (meeprom.gU16_EEPROM_read_Bin[i] > 0) && (meeprom.gU16_EEPROM_read_Bin[i] < 5))
		{//正常范围(meeprom.gU16_EEPROM_read_Bin[i] != 0) &&
			
			if(meeprom.gU16_EEPROM_wirte_Bin[i] != meeprom.gU16_EEPROM_read_Bin[i])
			{
				//meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =0;//short
				//meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =0; //open
				//meeprom.gU16_EEPROM_wirte_Bin[i] = meeprom.gU16_EEPROM_read_Bin[i];
				bin_eeprom_flag = 1;
				
			}
			if((adc_sta.gU16_Bin_Dig[i] == 1) )
			{
				adc_sta.BIN_short[i]=true;
				adc_sta.BIN_open[i]=false;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =1;//short  读取gU16_EEPROM_Diag_wirte_Bin上报故障�?0:正常  1：短�?  2：开�?
				meeprom.gU16_EEPROM_wirte_Bin[i] = meeprom.gU16_EEPROM_read_Bin[i];
				bin_eeprom_flag = 1;
				
			}
			if((adc_sta.gU16_Bin_Dig[i] == 2) )
			{
				adc_sta.BIN_short[i]=false;
				adc_sta.BIN_open[i]=true;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =2; //open  读取gU16_EEPROM_Diag_wirte_Bin上报故障�?0:正常  1：短�?  2：开�?
				meeprom.gU16_EEPROM_wirte_Bin[i] = meeprom.gU16_EEPROM_read_Bin[i];
				bin_eeprom_flag = 1;
				
			}
			
			
		}
		if ( (meeprom.gU16_EEPROM_read_Leve5_Bin[i] == LEVEL5) )
		{
			if((adc_sta.gU16_Bin_Dig[i] == 1) )
			{
				adc_sta.BIN_short[i]=true;
				adc_sta.BIN_open[i]=false;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =1;//short  读取gU16_EEPROM_Diag_wirte_Bin上报故障�?0:正常  1：短�?  2：开�?
				//meeprom.gU16_EEPROM_wirte_Bin[i] = meeprom.gU16_EEPROM_read_Bin[i];
				bin_eeprom_flag = 1;
				
			}
			if((adc_sta.gU16_Bin_Dig[i] == 2) )
			{
				adc_sta.BIN_short[i]=false;
				adc_sta.BIN_open[i]=true;
				meeprom.gU16_EEPROM_Diag_wirte_Bin[i] =2; //open  读取gU16_EEPROM_Diag_wirte_Bin上报故障�?0:正常  1：短�?  2：开�?
				//meeprom.gU16_EEPROM_wirte_Bin[i] = meeprom.gU16_EEPROM_read_Bin[i];
				bin_eeprom_flag = 1;
				
			}
			
			
		}
		if((i == (BIN_COUNTNUM - 1)) && (bin_eeprom_flag == 1))
		{
			return 1;
		}
	}
	return 0;
}

/*!
  \brief Callback function for Flash operations
*/
START_FUNCTION_DEFINITION_RAMSECTION
void CCIF_Callback(void)
{
    /* Enable interrupt for Flash Command Complete */
    if ((FTFx_FCNFG & FTFx_FCNFG_CCIE_MASK) == 0u)
    {
        FTFx_FCNFG |= FTFx_FCNFG_CCIE_MASK;
    }
}
END_FUNCTION_DEFINITION_RAMSECTION

/**
 * @brief Dflash 函数
 *
 * 该函数执行 Dflash 的相关操作，包括读取 Dflash 内容、擦除扇区、写入数据等。
 */
void Dflash_Fun(void)
{
	Dflash_Read();//DFLASH内容全部提取
	/*在长时间的闪存操作(例如:擦除)之前设置回调函数，让应用程序代码在闪存操作中执行其他任务。在这种情况下，我们使用它来启用中断为*/
	/*Flash命令完成事件*/
	pCallBack = (flash_callback_t)CCIF_Callback;
	flashSSDConfig.CallBack = pCallBack;
	for(uint8_t i = 0; i < BIN_COUNTNUM; i++)
	{
		meeprom.gU16_EEPROM_read_Bin[i] = readData[i + 1];
		meeprom.gU16_EEPROM_Diag_read_Bin[i] = readData[i + 4];
		meeprom.gU16_EEPROM_read_Leve5_Bin[i] = readData[i + 7];
	}

	if((meeprom.gU16_EEPROM_wirte_Bin[0] != meeprom.gU16_EEPROM_read_Bin[0]) || (meeprom.gU16_EEPROM_Diag_wirte_Bin[0] != meeprom.gU16_EEPROM_Diag_read_Bin[0]) || (meeprom.gU16_EEPROM_wirte_Leve5_Bin[0] != meeprom.gU16_EEPROM_read_Leve5_Bin[0])\
		||(meeprom.gU16_EEPROM_wirte_Bin[1] != meeprom.gU16_EEPROM_read_Bin[1]) || (meeprom.gU16_EEPROM_Diag_wirte_Bin[1] != meeprom.gU16_EEPROM_Diag_read_Bin[1]) || (meeprom.gU16_EEPROM_wirte_Leve5_Bin[1] != meeprom.gU16_EEPROM_read_Leve5_Bin[1])\
		||(meeprom.gU16_EEPROM_wirte_Bin[2] != meeprom.gU16_EEPROM_read_Bin[2]) || (meeprom.gU16_EEPROM_Diag_wirte_Bin[2] != meeprom.gU16_EEPROM_Diag_read_Bin[2]) || (meeprom.gU16_EEPROM_wirte_Leve5_Bin[2] != meeprom.gU16_EEPROM_read_Leve5_Bin[2])\
	)
	{
		/* Erase a sector in DFlash */
		address = flashSSDConfig.DFlashBase;
		size = FEATURE_FLS_DF_BLOCK_SECTOR_SIZE;
		FLASH_DRV_EraseSector(&flashSSDConfig, address, size);

		/*把读出的数据写入到dlfah里*/
		address = flashSSDConfig.DFlashBase;
		size = DF_BUFFER_SIZE;
		FLASH_DRV_Program(&flashSSDConfig, address, size, sourceBuffer);
	}
	if(0)
	{
		if(read_BIN_Sta())//如果是第一次对内存进行操作则进入
		{
			Reepromflag[0] = 0; // 清空标志位
			if(Reepromflag[0] != 1)
			{
				epromflag[0] = 1; // 设置标志位为1
				sourceBuffer[0] = epromflag[0];// 将epormflag数组的值写入Dlash的第一个缓存
				for(uint8_t i = 1; i < (BIN_COUNTNUM + 1); i++)
				{
					sourceBuffer[i] = meeprom.gU16_EEPROM_wirte_Bin[(i - 1)];
					sourceBuffer[i+3] = meeprom.gU16_EEPROM_Diag_wirte_Bin[(i - 1)];
					sourceBuffer[i+6] = meeprom.gU16_EEPROM_wirte_Leve5_Bin[(i - 1)];
				}
				FLASH_DRV_Program(&flashSSDConfig, address, size, sourceBuffer);
			}
		}
	}
}

void DTC_code_handle(void)
{
	if(Get_mode_KL30Sts() == KL30_7_0todonw)
	{
		meeprom.gU16_EEPROM_kl30_wirte_uvp = 1;
		//meeprom.gU16_EEPROM_kl30_wirte_ovp = 0;
	}
	if(Get_mode_KL30Sts() == KL30_7_0to18_5V) 
	{
		//meeprom.gU16_EEPROM_kl30_wirte_uvp = 0;
		//meeprom.gU16_EEPROM_kl30_wirte_ovp = 0;
	}
	if(Get_mode_KL30Sts() == KL30_18_5V_up)
	{
		//meeprom.gU16_EEPROM_kl30_wirte_uvp = 0;
		meeprom.gU16_EEPROM_kl30_wirte_ovp = 1;
	}
	//if( (MPQ7210_ERR_t.cc2_open_flag == 1) && ()
	//meeprom.gU16_EEPROM_CC3_wirte_uvp
}

status_t MspEERomFun(void)
{
	// 从EEPROM�?读取偏移量为0的一�?字节，存储在Reepromflag数组�?
	MspEERomRead(0, Reepromflag, 1);
	// 从EEPROM�?读取3�?字节，存储在meeprom.gU16_EEPROM_read_Bin数组�?
	MspEERomRead(1, meeprom.gU16_EEPROM_read_Bin, BIN_COUNTNUM);
	MspEERomRead(4, meeprom.gU16_EEPROM_Diag_read_Bin, BIN_COUNTNUM);
	MspEERomRead(7, meeprom.gU16_EEPROM_read_Leve5_Bin, BIN_COUNTNUM);
    //meeprom.gU16_EEPROM_Old_read_Bin = meeprom.gU16_EEPROM_read_Bin;
	if(read_BIN_Sta() == 1)//如果�?�?一次�?�EEPROM写bin值则进入函数
	{
		Reepromflag[0] = 0;//清空标志�?
		if(Reepromflag[0] != 1)
		{
		   epromflag[0] = 1;
		   MspEERomWrite(0, epromflag, 1);
		   MspEERomWrite(1, meeprom.gU16_EEPROM_wirte_Bin, BIN_COUNTNUM);//BIN_COUNTNUM*BINLEVEL
		   MspEERomWrite(4, meeprom.gU16_EEPROM_Diag_wirte_Bin, BIN_COUNTNUM);
		   MspEERomWrite(7, meeprom.gU16_EEPROM_wirte_Leve5_Bin, BIN_COUNTNUM);
		   MspEERomRead(0, Reepromflag, 1);
		   MspEERomRead(1,  meeprom.gU16_EEPROM_read_Bin, BIN_COUNTNUM);
		   MspEERomRead(4, meeprom.gU16_EEPROM_Diag_read_Bin, BIN_COUNTNUM);
		   MspEERomRead(7, meeprom.gU16_EEPROM_read_Leve5_Bin, BIN_COUNTNUM);
		   //meeprom.gU16_EEPROM_New_read_Bin = meeprom.gU16_EEPROM_read_Bin;
		}
	}
	return STATUS_SUCCESS;
}



