/******************************************************************************
*
*   COPYRIGHT       : Ternary 
*   FILENAME        : $Source: _Tasks.c $
*   COMPILER        : IAR IDE  9.40.1
*   PROCESSOR       : YTM32B1ME0
*
*   DATE OF CREATION: 10.03.2024
*   LAST REVISION   : $Date  : 10.03.2024 $
*                     $Author:        $

******************************************************************************/


 
 /* ========= File define =================================================== */
#define _Tasks_c


/* ========== Includes ====================================================== */
#include "_Tasks.h"
#include "stdio.h"
#include "LLD_config.h"
#include "app_bin.h"
#include "app_signal_check.h"
#include "al_light_function.h"
#include "APP_Demo.h"
#include "al_light_function.h"
#include "bootloader_debug.h"
#include "Diagnostic_fault.h"
/*
#include "Mcal.h"
#include "EcuM.h"
#include "BswM.h"
#include "CanIf.h"
#include "Com.h"
#include "PduR.h"
#include "ComM.h"
#include "CanSM.h"
#include "CanNm.h"
#include "Fls.h"
#include "Fee.h"
#include "NvM.h"
#include "CanTp.h"
#include "Dcm.h"
#include "Dcm_Cbk.h"
#include "Dem.h"
#include "Rte_E2EXf.h"
#include "MPQ7210_driver.h"
#include "TLE9262_test.h"
#include "_Rte_Handler.h"
#include "_Boot_Interface.h"
#include "_Coding_Handler.h"
#include "_Rtos.h"
#include "_AD_Handler.h"
#include "_signal_filter.h"
#include "_app_lamp_input.h"
#include "_app_lamp_output.h"
#include "_bat_calc.h"
#include "_temp_calc.h"
#include "_rbin_calc.h"
*/


/* ========== Local Defines, Enumerations, Type Definitions ================= */

/* ========== Local Function Prototypes ===================================== */

/* ========== Local Macros ================================================== */

/* ========== Local Variables =============================================== */

//ComM_ModeType can_BusMode = COMM_NO_COMMUNICATION;

/* ========== Local Functions =============================================== */


/* ========== Global Functions ============================================== */


/* ************************************************************************** */
/*!
 * @fn         void _5msTask(void)
 * @brief      5ms Task
 * @details    none
 */
/* ************************************************************************** */
void _5msTask(void)
{
#ifdef TEST_DEBUG
      APP_Demo_MainFun();
#endif
      if(LB_HB_OFF_TIME == 1)
	  {
		  Get_LB_HB_OFF_TIME ++; //LB_HB_OFF_TIME++;
	  }
	  if(Get_LB_HB_OFF_TIME >= 1)
      {
		  FBhblb = 0;
		  B13_EN_LED1_LB_DISABLE;//HB - OFF
		  B12_EN_LED2_HB_DISABLE;//LB - OFF
          LB_HB_OFF_TIME = 0;
          Get_LB_HB_OFF_TIME = 0;
      }
}


/* ************************************************************************** */
/*!
 * @fn         void _10ms_A_Task(void)
 * @brief      10ms A Task
 * @details    none
 */
/* ************************************************************************** */
void _10ms_Task(void)
{
	ADManage_Tesk();
	LightFunctionProcess();
	diagnosic_timer();
}


/* ************************************************************************** */
/*!
 * @fn         void _20ms_A_Task(void)
 * @brief      20ms A Task
 * @details    none
 */
/* ************************************************************************** */
void _20ms_A_Task(void)  
{
	Sig_StatusDectProcess();
}


/* ************************************************************************** */
/*!
 * @fn         void _20ms_B_Task(void)
 * @brief      20ms B Task
 * @details    none
 */
/* ************************************************************************** */
void _20ms_B_Task(void)
{
	perCfgVRegDiag();
	if(dig_en_flag)
	{
		Fault_Trigger_Check();
	}
}


/* ************************************************************************** */
/*!
 * @fn         void _50msTask(void)
 * @brief      50ms Task
 * @details    none
 */
/* ************************************************************************** */
void _50msTask(void)
{

}

/* ************************************************************************** */
/*!
 * @fn         void _100msTask(void)
 * @brief      100ms Task
 * @details    none
 */
/* ************************************************************************** */
void _100msTask(void)
{

}

/* ************************************************************************** */
/*!
 * @fn         void _250msTask(void)
 * @brief      250ms Task
 * @details    none
 */
/* ************************************************************************** */
void _250msTask(void)
{

	/*static uint8_t f_test_time=0;
		if(f_test_time == 0 )
		{
			f_test_time = 1;
			Open_IC_CC4_EN2_ENABLE;
		}
		else{
			f_test_time = 0;
			Open_IC_CC4_EN2_DISABLE;
		}*/
}

/* ************************************************************************** */
/*!
 * @fn         void _500msTask(void)
 * @brief      500ms Task
 * @details    none
 */
/* ************************************************************************** */
void _500msTask(void)
{
	Vehicle_Diagnostic_fun();
	/*static uint8_t f_test_time2=0;
			if(f_test_time2 == 0 )
			{
				f_test_time2 = 1;
				Open_IC_CC1_EN1_ENABLE;
			}
			else{
				f_test_time2 = 0;
				Open_IC_CC1_EN1_DISABLE;
			}*/
}

/* ************************************************************************** */
/*!
 * @fn         void _1000msTask(void)
 * @brief      1000ms Task
 * @details    none
 */
/* ************************************************************************** */
void _1000msTask(void)
{

  //_Sys_Test();

}





