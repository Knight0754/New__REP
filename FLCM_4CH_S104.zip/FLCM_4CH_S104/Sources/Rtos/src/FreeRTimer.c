/*============================================================================*/
/*  Copyright (C) 2009-2018, iSOFT INFRASTRUCTURE SOFTWARE CO.,LTD.
 *
 *  All rights reserved. This software is iSOFT property. Duplication
 *  or disclosure without iSOFT written authorization is prohibited.
 *
 *  file       < FreeRTimer.c>
 *  brief      < FreeRTimer module file >
 *
 *  < Compiler:S32DS for ARM 2018.R1     MCU:S32K144/S32K146 >
 *
 *  author     < yongxing.jia >
 *  date       < 2018-12-12 >
 */
/*============================================================================*/
/******************************* references ************************************/
#include "FreeRTimer.h"

/****************************** implementations ********************************/
uint32_t msCounter = 0;
void Run_msCounter(void)
{
	msCounter++;
}

Std_ReturnType FreeRtimer_GetCounterValue(uint16 id, TickType* tick)
{
	*tick = msCounter;
	return E_OK;
}

uint32_t Frt_ReadOutMS(void)
{
	uint32_t  CurMs;
    (void)FreeRtimer_GetCounterValue(0, &CurMs);

	return(CurMs);
}

uint32_t Frt_CalculateElapsedMS(uint32_t OldCurMs)
{
	uint32_t  ElapsedMs = 0;

	if(OldCurMs <= msCounter)
	{
	    ElapsedMs = msCounter - OldCurMs;
	}
	else
	{
		ElapsedMs = (0xFFFFFFFF - OldCurMs) + msCounter;
	}

    return(ElapsedMs);
}
uint32_t MPQ7210_ResetTimer(uint32_t * timerP)
{
  *timerP  = Frt_ReadOutMS();

  return *timerP;
}


void MPQ7210_GetSpanTimer(uint32_t timer , uint32_t * timerP)
{
	*timerP = Frt_CalculateElapsedMS(timer);
}
