
/******************************************************************************
*
*   COPYRIGHT       : Ternary 
*   FILENAME        : $Source: _Rtos.h $
*   COMPILER        : IAR IDE  9.40.1
*   PROCESSOR       : YTM32B1ME0
*
*   DATE OF CREATION: 10.03.2024
*   LAST REVISION   : $Date  : 10.03.2024 $
*                     $Author:        $

*
******************************************************************************/

 /* ========= File define =================================================== */
#ifndef _Rtos_h
#define _Rtos_h


/* ========== Includes ====================================================== */

#include "stdint.h"

/* ========== export Define ================================================= */
#ifdef _Rtos_c
  #define export extern
#else
  #define export extern 
#endif 
/* ========== Local Defines, Enumerations, Type Definitions ================= */
#define SYS_TICK 5                                         // Sys tick 5ms
#define SECONDS 1000/SYS_TICK



typedef enum
{
 DUMMY_TASK, /* non-delayable tasks */
 TASK_5_MS,
 TASK_10_MS,
 TASK_20_MS_A,
 TASK_20_MS_B,
 TASK_50_MS,
 TASK_100_MS,
 TASK_250_MS,
 TASK_500_MS,
 TASK_1000_MS,
 NUM_OF_TASKS
}TASK_ID;

typedef const struct tTASK
{
  uint32_t rate_mask, compare_value;
  const struct tTASK *next;
  TASK_ID task_id;
}TASK;

/* ========== Local Function Prototypes ===================================== */

/* ========== Local Macros ================================================== */

/* ========== Local Variables =============================================== */


export    uint32_t _rtos_slice;
export    uint32_t _sys_tick;
export            uint16_t _sch_procedure_period;
export const      TASK     task_1_def;
export            TASK    *task_table_head;

/* ========== Local Functions =============================================== */

/* ========== Global Functions ============================================== */

export void _Rtos_Init(void);
export void _Rtos_Task(void);
export void _Check_Tasks( TASK *current_task);
export void _Exec_Routines(TASK_ID task_id);
export void _Sys_Test(void);

#undef export
#endif
