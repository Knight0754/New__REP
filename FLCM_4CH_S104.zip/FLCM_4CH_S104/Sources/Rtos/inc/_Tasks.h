/******************************************************************************
*
*   COPYRIGHT       : Ternary 
*   FILENAME        : $Source: _Tasks.h $
*   COMPILER        : IAR IDE  9.40.1
*   PROCESSOR       : YTM32B1ME0
*
*   DATE OF CREATION: 10.03.2024
*   LAST REVISION   : $Date  : 10.03.2024 $
*                     $Author:        $

*
******************************************************************************/


 
 /* ========= File define =================================================== */
#ifndef _Tasks_h
#define _Tasks_h

/* ========== Includes ====================================================== */
#include "stdint.h"



/* ========== export Define ================================================= */
#ifdef _Tasks_c
  #define export
#else
  #define export extern 
#endif

/* ========== Local Defines, Enumerations, Type Definitions ================= */

/* ========== Local Function Prototypes ===================================== */

/* ========== Local Macros ================================================== */

/* ========== Local Variables =============================================== */

export volatile uint8_t _urgent_task_flag;


/* ========== Local Functions =============================================== */

/* ========== Global Functions ============================================== */
export void _Timer_HighProTask(void);
export void _Timer_LowProTask(void);
export void _5msTask(void);
export void _10ms_Task(void);
export void _20ms_A_Task(void);
export void _20ms_B_Task(void);
export void _50msTask(void);
export void _100msTask(void);
export void _250msTask(void);
export void _500msTask(void);
export void _1000msTask(void);

#undef export
#endif
