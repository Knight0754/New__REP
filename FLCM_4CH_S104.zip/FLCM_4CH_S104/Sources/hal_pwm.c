/*
 * hal_pwm.c
 *
 *  Created on: 2023��12��20��
 *      Author: gz06488
 */

#include "hal_pwm.h"
#include "ftm_common.h"
#include "ftm_hw_access.h"
#include "clockMan1.h"
#include "Cpu.h"


/* Variables used to store PWM duty cycle */
ftm_state_t ftm0StateStruct;
ftm_state_t ftm1StateStruct;
void ftmTimer_init(void)
{
    // 初始化第一个FTM
    FTM_DRV_Init(INST_FLEXTIMER_PWM1, &flexTimer_pwm1_InitConfig, &ftm0StateStruct);
    // 初始化第二个FTM
    FTM_DRV_Init(INST_FLEXTIMER_PWM2, &flexTimer_pwm2_InitConfig, &ftm1StateStruct);
}

